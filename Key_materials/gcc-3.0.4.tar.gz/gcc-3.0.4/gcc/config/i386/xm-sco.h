/* Configuration for GCC for Intel i386 running SCO.  */

/* Big buffers improve performance.  */

#define IO_BUFFER_SIZE (0x8000 - 1024)
