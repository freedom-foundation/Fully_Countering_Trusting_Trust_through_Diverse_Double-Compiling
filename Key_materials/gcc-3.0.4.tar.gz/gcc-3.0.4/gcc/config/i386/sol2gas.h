/* Definitions of target machine for GNU compiler, for SPARC running
   Solaris 2 with GNU as up to 2.9.5.0.12.
   
   Copyright (C) 1999 Free Software Foundation, Inc.
*/

#ifndef GAS_REJECTS_MINUS_S
#define GAS_REJECTS_MINUS_S 1
#endif

/* Assume sol2.h will be included afterwards.  */
