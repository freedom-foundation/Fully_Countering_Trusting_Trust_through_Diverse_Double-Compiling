/* Generated automatically by the program `genattrtab'
from the machine description file `md'.  */

#include "config.h"
#include "system.h"
#include "rtl.h"
#include "tm_p.h"
#include "insn-config.h"
#include "recog.h"
#include "regs.h"
#include "real.h"
#include "output.h"
#include "insn-attr.h"
#include "toplev.h"

#define operands recog_data.operand

extern int insn_current_length PARAMS ((rtx));
int
insn_current_length (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

extern int insn_variable_length_p PARAMS ((rtx));
int
insn_variable_length_p (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

extern int insn_default_length PARAMS ((rtx));
int
insn_default_length (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 330:
      if (get_attr_type (insn) == TYPE_MULTI)
        {
	  return 16 /* 0x10 */;
        }
      else
        {
	  return get_attr_modrm (insn) + get_attr_prefix_0f (insn) + get_attr_i387 (insn) + 1 + get_attr_prefix_rep (insn) + get_attr_prefix_data16 (insn) + get_attr_length_immediate (insn) + get_attr_length_address (insn);
        }

    case 314:
    case 312:
    case 310:
    case 308:
    case 306:
    case 304:
    case 302:
    case 300:
    case 298:
    case 296:
    case 294:
    case 292:
    case 288:
    case 286:
    case 284:
    case 282:
    case 280:
    case 278:
      extract_insn_cached (insn);
      if (register_operand (operands[0], SImode))
        {
	  return 2;
        }
      else
        {
	  return get_attr_modrm (insn) + get_attr_prefix_0f (insn) + get_attr_i387 (insn) + 1 + get_attr_prefix_rep (insn) + get_attr_prefix_data16 (insn) + get_attr_length_immediate (insn) + get_attr_length_address (insn);
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return 16 /* 0x10 */;
        }
      else
        {
	  return get_attr_modrm (insn) + get_attr_prefix_0f (insn) + get_attr_i387 (insn) + 1 + get_attr_prefix_rep (insn) + get_attr_prefix_data16 (insn) + get_attr_length_immediate (insn) + get_attr_length_address (insn);
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || (which_alternative == 4))
        {
	  return 16 /* 0x10 */;
        }
      else
        {
	  return get_attr_modrm (insn) + get_attr_prefix_0f (insn) + get_attr_i387 (insn) + 1 + get_attr_prefix_rep (insn) + get_attr_prefix_data16 (insn) + get_attr_length_immediate (insn) + get_attr_length_address (insn);
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 16 /* 0x10 */;
        }
      else
        {
	  return get_attr_modrm (insn) + get_attr_prefix_0f (insn) + get_attr_i387 (insn) + 1 + get_attr_prefix_rep (insn) + get_attr_prefix_data16 (insn) + get_attr_length_immediate (insn) + get_attr_length_address (insn);
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return 16 /* 0x10 */;
        }
      else
        {
	  return get_attr_modrm (insn) + get_attr_prefix_0f (insn) + get_attr_i387 (insn) + 1 + get_attr_prefix_rep (insn) + get_attr_prefix_data16 (insn) + get_attr_length_immediate (insn) + get_attr_length_address (insn);
        }

    case 418:
    case 417:
    case 344:
    case 342:
    case 341:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 127:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
      return 16 /* 0x10 */;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      return 128 /* 0x80 */;

    case 412:
      return 5;

    case 343:
    case 339:
    case 336:
    case 26:
      return 1;

    case 337:
      return 3;

    case 335:
      return 0;

    case 114:
    case 113:
    case 25:
      return 2;

    default:
      return get_attr_modrm (insn) + get_attr_prefix_0f (insn) + get_attr_i387 (insn) + 1 + get_attr_prefix_rep (insn) + get_attr_prefix_data16 (insn) + get_attr_length_immediate (insn) + get_attr_length_address (insn);

    }
}

extern int result_ready_cost PARAMS ((rtx));
int
result_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (constant_call_address_operand (operands[1], VOIDmode))))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    case 411:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && ((which_alternative == 1) && (! (const0_operand (operands[2], SImode))))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 410:
    case 409:
    case 408:
    case 407:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 7;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) || (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 15 /* 0xf */;
        }
      else if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 12 /* 0xc */;
        }
      else if (((ix86_cpu) == (CPU_K6)))
        {
	  return 10 /* 0xa */;
        }
      else
        {
	  return 1;
        }

    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 15 /* 0xf */;
        }
      else if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 12 /* 0xc */;
        }
      else if (((ix86_cpu) == (CPU_K6)))
        {
	  return 10 /* 0xa */;
        }
      else if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    case 390:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 100 /* 0x64 */;
        }
      else if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 70 /* 0x46 */;
        }
      else if ((((ix86_cpu) == (CPU_K6))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 56 /* 0x38 */;
        }
      else
        {
	  return 1;
        }

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_K6))) && (get_attr_type (insn) == TYPE_FDIV)) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV)))
        {
	  return 56 /* 0x38 */;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  return 39 /* 0x27 */;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  return 24 /* 0x18 */;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], TFmode)))
        {
	  return 5;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], TFmode))))
        {
	  return 4;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)) || (get_attr_type (insn) == TYPE_FOP))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], TFmode)))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], TFmode)))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((mult_operator (operands[3], TFmode)) || (get_attr_type (insn) == TYPE_FOP))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_K6))) && (get_attr_type (insn) == TYPE_FDIV)) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV)))
        {
	  return 56 /* 0x38 */;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  return 39 /* 0x27 */;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  return 24 /* 0x18 */;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], XFmode)))
        {
	  return 5;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], XFmode))))
        {
	  return 4;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)) || (get_attr_type (insn) == TYPE_FOP))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], XFmode)))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], XFmode)))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((mult_operator (operands[3], XFmode)) || (get_attr_type (insn) == TYPE_FOP))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_K6))) && (get_attr_type (insn) == TYPE_FDIV)) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV)))
        {
	  return 56 /* 0x38 */;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  return 39 /* 0x27 */;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  return 24 /* 0x18 */;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], DFmode)))
        {
	  return 5;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], DFmode))))
        {
	  return 4;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)) || (get_attr_type (insn) == TYPE_FOP))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], DFmode)))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], DFmode)))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((mult_operator (operands[3], DFmode)) || (get_attr_type (insn) == TYPE_FOP))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_K6))) && (get_attr_type (insn) == TYPE_FDIV)) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV)))
        {
	  return 56 /* 0x38 */;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  return 39 /* 0x27 */;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  return 24 /* 0x18 */;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], SFmode)))
        {
	  return 5;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], SFmode))))
        {
	  return 4;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)) || (get_attr_type (insn) == TYPE_FOP))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], SFmode)))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], SFmode)))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((mult_operator (operands[3], SFmode)) || (get_attr_type (insn) == TYPE_FOP))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 348:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], TFmode)))
        {
	  return 5;
        }
      else if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 4;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)) || (! (mult_operator (operands[3], TFmode))))) || (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 3;
        }
      else if (((ix86_cpu) == (CPU_K6)))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 347:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], XFmode)))
        {
	  return 5;
        }
      else if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 4;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)) || (! (mult_operator (operands[3], XFmode))))) || (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 3;
        }
      else if (((ix86_cpu) == (CPU_K6)))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 346:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], DFmode)))
        {
	  return 5;
        }
      else if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 4;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)) || (! (mult_operator (operands[3], DFmode))))) || (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 3;
        }
      else if (((ix86_cpu) == (CPU_K6)))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 345:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], SFmode)))
        {
	  return 5;
        }
      else if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 4;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)) || (! (mult_operator (operands[3], SFmode))))) || (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 3;
        }
      else if (((ix86_cpu) == (CPU_K6)))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (constant_call_address_operand (operands[0], VOIDmode))))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (memory_operand (operands[0], VOIDmode)))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH)) || (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (get_attr_memory (insn) == MEMORY_BOTH)))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 1) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH))) || (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH)))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 1) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))) || (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 271:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && (which_alternative == 2)) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((((get_attr_pent_pair (insn) == PENT_PAIR_PU) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((((get_attr_pent_pair (insn) == PENT_PAIR_PU) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && (which_alternative == 1)) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((((get_attr_pent_pair (insn) == PENT_PAIR_PU) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) || (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 261:
    case 259:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (memory_operand (operands[1], VOIDmode))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (memory_operand (operands[1], VOIDmode))))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || (which_alternative == 1)) && ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || (which_alternative == 1)) && ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 46 /* 0x2e */;
        }
      else if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 42 /* 0x2a */;
        }
      else if ((((ix86_cpu) == (CPU_K6))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 17 /* 0x11 */;
        }
      else
        {
	  return 1;
        }

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 11 /* 0xb */;
        }
      else if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 5;
        }
      else if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 4;
        }
      else if (((ix86_cpu) == (CPU_K6)))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((! (incdec_operand (operands[2], QImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((! (incdec_operand (operands[2], QImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && (which_alternative == 3)) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((! (incdec_operand (operands[2], HImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((! (incdec_operand (operands[2], HImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && (which_alternative == 2)) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((((get_attr_pent_pair (insn) == PENT_PAIR_PU) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((! (incdec_operand (operands[2], SImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((! (incdec_operand (operands[2], SImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 135:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_ALU) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_K6))) && ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode)))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_ALU) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 134:
    case 133:
    case 132:
    case 131:
      if (((ix86_cpu) == (CPU_K6)))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 153:
    case 130:
    case 129:
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 276:
    case 265:
    case 155:
    case 128:
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_ATHLON))) && ((which_alternative == 0) && (get_attr_memory (insn) == MEMORY_LOAD)))
        {
	  return 10 /* 0xa */;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_ATHLON))) && (which_alternative == 0)) || (((((ix86_cpu) == (CPU_K6))) && (which_alternative == 0)) || ((((ix86_cpu) == (CPU_PENTIUM))) && (which_alternative == 0))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) || ((((ix86_cpu) == (CPU_K6))) || (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_ATHLON))) && (which_alternative == 0)) || (((((ix86_cpu) == (CPU_K6))) && (which_alternative == 0)) || ((((ix86_cpu) == (CPU_PENTIUM))) && (which_alternative == 0))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_ATHLON))) && ((which_alternative == 1) && (get_attr_memory (insn) == MEMORY_LOAD)))
        {
	  return 10 /* 0xa */;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_ATHLON))) || ((((ix86_cpu) == (CPU_K6))) || (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 1) && (get_attr_memory (insn) == MEMORY_BOTH))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_ATHLON))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (get_attr_memory (insn) == MEMORY_LOAD)))
        {
	  return 10 /* 0xa */;
        }
      else if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_ATHLON))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))) || (((((ix86_cpu) == (CPU_K6))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  return 3;
        }
      else if (((((ix86_cpu) == (CPU_ATHLON))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))) || (((((ix86_cpu) == (CPU_K6))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))) || ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((which_alternative == 1) && (memory_operand (operands[1], VOIDmode))))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    case 35:
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_K6))) && (get_attr_type (insn) == TYPE_LEA))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 262:
    case 260:
    case 258:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUMPRO))) && (memory_operand (operands[1], VOIDmode))) || ((((ix86_cpu) == (CPU_PENTIUM))) && (memory_operand (operands[1], VOIDmode))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_memory (insn) == MEMORY_STORE))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 317:
    case 316:
    case 45:
    case 38:
    case 32:
    case 31:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (memory_operand (operands[1], VOIDmode)))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      if ((((ix86_cpu) == (CPU_ATHLON))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH))))
        {
	  return 3;
        }
      else if ((((ix86_cpu) == (CPU_K6))) || (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 1;
        }

    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_memory (insn) == MEMORY_LOAD))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 542:
    case 539:
    case 418:
    case 417:
    case 412:
    case 404:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
      return 1;

    default:
      if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  return 3;
        }
      else
        {
	  return 1;
        }

    }
}

extern int athlon_load_unit_ready_cost PARAMS ((rtx));
int
athlon_load_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int athlon_fp_store_unit_ready_cost PARAMS ((rtx));
int
athlon_fp_store_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int athlon_fp_muladd_unit_ready_cost PARAMS ((rtx));
int
athlon_fp_muladd_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int athlon_fp_add_unit_ready_cost PARAMS ((rtx));
int
athlon_fp_add_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int athlon_fp_mul_unit_ready_cost PARAMS ((rtx));
int
athlon_fp_mul_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int athlon_fp_unit_ready_cost PARAMS ((rtx));
int
athlon_fp_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 410:
    case 409:
    case 408:
    case 407:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 7;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FDIV) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 24 /* 0x18 */;
        }
      else if (((mult_operator (operands[3], TFmode)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((get_attr_type (insn) == TYPE_FOP) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 4;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FDIV) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 24 /* 0x18 */;
        }
      else if (((mult_operator (operands[3], XFmode)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((get_attr_type (insn) == TYPE_FOP) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 4;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FDIV) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 24 /* 0x18 */;
        }
      else if (((mult_operator (operands[3], DFmode)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((get_attr_type (insn) == TYPE_FOP) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 4;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FDIV) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 24 /* 0x18 */;
        }
      else if (((mult_operator (operands[3], SFmode)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((get_attr_type (insn) == TYPE_FOP) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 4;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 348:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], TFmode)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((! (mult_operator (operands[3], TFmode))) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 4;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 347:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], XFmode)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((! (mult_operator (operands[3], XFmode))) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 4;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 346:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], DFmode)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((! (mult_operator (operands[3], DFmode))) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 4;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 345:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], SFmode)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((! (mult_operator (operands[3], SFmode))) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 4;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)) && ((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 10 /* 0xa */;
        }
      else if ((which_alternative == 0) && (((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)) && ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 2;
        }
      else if ((which_alternative == 0) && (((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE))) && ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 2;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
      if (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 2;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 2;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) && ((get_attr_memory (insn) == MEMORY_LOAD) && ((which_alternative == 1) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 10 /* 0xa */;
        }
      else if (((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) && ((((get_attr_memory (insn) == MEMORY_LOAD) && ((which_alternative == 0) && (((ix86_cpu) == (CPU_ATHLON))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && ((which_alternative == 1) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && ((which_alternative == 0) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 2;
        }
      else if (((which_alternative != 1) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE)))) && ((((get_attr_memory (insn) == MEMORY_LOAD) && ((which_alternative == 0) && (((ix86_cpu) == (CPU_ATHLON))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && ((which_alternative == 1) && (((ix86_cpu) == (CPU_ATHLON)))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && ((which_alternative == 0) && (((ix86_cpu) == (CPU_ATHLON)))))))
        {
	  return 2;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (((which_alternative == 3) || ((which_alternative == 4) || ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))) && ((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 10 /* 0xa */;
        }
      else if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (((which_alternative == 3) || ((which_alternative == 4) || ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))) && ((((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (((ix86_cpu) == (CPU_ATHLON))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (((ix86_cpu) == (CPU_ATHLON))))))))
        {
	  return 2;
        }
      else if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((((which_alternative != 3) && (which_alternative != 4)) && (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE))))) && ((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 10 /* 0xa */;
        }
      else if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (((which_alternative != 3) && ((which_alternative != 4) && (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE)))))) && ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 2;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((((which_alternative == 3) || (which_alternative == 4)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))) || (((which_alternative != 3) && (which_alternative != 4)) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))))
        {
	  return 2;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 2;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      if (((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 3;
        }
      else
        {
	  return 100 /* 0x64 */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 100 /* 0x64 */;

    }
}

extern int athlon_muldiv_unit_ready_cost PARAMS ((rtx));
int
athlon_muldiv_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 5;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 42 /* 0x2a */;

    }
}

extern unsigned int athlon_muldiv_unit_blockage_range PARAMS ((rtx));
unsigned int
athlon_muldiv_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65578 /* min 1, max 42 */;

    }
}

extern int athlon_ieu_unit_ready_cost PARAMS ((rtx));
int
athlon_ieu_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 1) && (! (const0_operand (operands[2], SImode)))) && (((ix86_cpu) == (CPU_ATHLON)))) || ((((which_alternative == 1) && (const0_operand (operands[2], SImode))) && (((ix86_cpu) == (CPU_ATHLON)))) || ((which_alternative == 0) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 15 /* 0xf */;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 330:
      if ((get_attr_type (insn) == TYPE_IBR) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && (((ix86_cpu) == (CPU_ATHLON)))) || ((which_alternative == 0) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 271:
      extract_constrain_insn_cached (insn);
      if (((get_attr_type (insn) == TYPE_ISHIFT) && (((ix86_cpu) == (CPU_ATHLON)))) || (((which_alternative == 2) && (((ix86_cpu) == (CPU_ATHLON)))) || ((get_attr_type (insn) == TYPE_ALU) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if (((get_attr_type (insn) == TYPE_ISHIFT) && (((ix86_cpu) == (CPU_ATHLON)))) || ((get_attr_type (insn) == TYPE_ALU) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if (((get_attr_type (insn) == TYPE_ISHIFT) && (((ix86_cpu) == (CPU_ATHLON)))) || (((which_alternative == 1) && (((ix86_cpu) == (CPU_ATHLON)))) || ((get_attr_type (insn) == TYPE_ALU) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative != 0) && (which_alternative != 1)) && (((ix86_cpu) == (CPU_ATHLON)))) || (((which_alternative == 0) || (which_alternative == 1)) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 5;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if (((incdec_operand (operands[2], QImode)) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (incdec_operand (operands[2], QImode))) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative != 3) && (incdec_operand (operands[2], QImode))) && (((ix86_cpu) == (CPU_ATHLON)))) || (((which_alternative == 3) && (((ix86_cpu) == (CPU_ATHLON)))) || (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if (((incdec_operand (operands[2], HImode)) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (incdec_operand (operands[2], HImode))) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative != 2) && (incdec_operand (operands[2], HImode))) && (((ix86_cpu) == (CPU_ATHLON)))) || (((which_alternative == 2) && (((ix86_cpu) == (CPU_ATHLON)))) || (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if (((incdec_operand (operands[2], SImode)) && (((ix86_cpu) == (CPU_ATHLON)))) || ((! (incdec_operand (operands[2], SImode))) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 135:
      extract_constrain_insn_cached (insn);
      if (((get_attr_type (insn) == TYPE_INCDEC) && (((ix86_cpu) == (CPU_ATHLON)))) || ((((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode))) && (((ix86_cpu) == (CPU_ATHLON)))) || ((get_attr_type (insn) == TYPE_ALU) && (((ix86_cpu) == (CPU_ATHLON))))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 54:
    case 52:
      if (((get_attr_type (insn) == TYPE_IMOVX) && (((ix86_cpu) == (CPU_ATHLON)))) || ((get_attr_type (insn) == TYPE_IMOV) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if (((((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))) && (((ix86_cpu) == (CPU_ATHLON)))) || ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if (((((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))) && (((ix86_cpu) == (CPU_ATHLON)))) || ((get_attr_type (insn) == TYPE_IMOV) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 35:
      if (((get_attr_type (insn) == TYPE_LEA) && (((ix86_cpu) == (CPU_ATHLON)))) || ((get_attr_type (insn) == TYPE_IMOV) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 416:
    case 415:
    case 414:
    case 413:
    case 406:
    case 405:
    case 404:
    case 390:
    case 340:
    case 338:
    case 334:
    case 333:
    case 332:
    case 331:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
    case 317:
    case 316:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 211:
    case 210:
    case 209:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 197:
    case 196:
    case 195:
    case 194:
    case 193:
    case 191:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 134:
    case 133:
    case 132:
    case 131:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 82:
    case 81:
    case 79:
    case 78:
    case 77:
    case 56:
    case 55:
    case 53:
    case 51:
    case 50:
    case 49:
    case 48:
    case 47:
    case 45:
    case 44:
    case 43:
    case 42:
    case 41:
    case 40:
    case 38:
    case 37:
    case 36:
    case 34:
    case 33:
    case 32:
    case 31:
    case 30:
    case 29:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 5:
    case 4:
    case 2:
    case 1:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case 83:
    case 80:
    case 6:
    case 3:
    case 0:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) && (((ix86_cpu) == (CPU_ATHLON)))) || ((which_alternative == 1) && (((ix86_cpu) == (CPU_ATHLON)))))
        {
	  return 1;
        }
      else
        {
	  return 42 /* 0x2a */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 42 /* 0x2a */;

    }
}

extern unsigned int athlon_ieu_unit_blockage_range PARAMS ((rtx));
unsigned int
athlon_ieu_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65551 /* min 1, max 15 */;

    }
}

extern int athlon_directdec_unit_ready_cost PARAMS ((rtx));
int
athlon_directdec_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int athlon_vectordec_unit_ready_cost PARAMS ((rtx));
int
athlon_vectordec_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern unsigned int athlon_vectordec_unit_blockage_range PARAMS ((rtx));
unsigned int
athlon_vectordec_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 330:
      if ((! (get_attr_type (insn) == TYPE_MULTI)) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) && ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE)))) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 1) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE)))) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative != 3) && (which_alternative != 4)) && (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE))))) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (which_alternative != 4)) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode)))) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 0) && (which_alternative != 1)) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if ((! (memory_operand (operands[1], VOIDmode))) && (((ix86_cpu) == (CPU_ATHLON))))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 418:
    case 417:
    case 412:
    case 410:
    case 409:
    case 408:
    case 407:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 334:
    case 333:
    case 332:
    case 331:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 265:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 182:
    case 181:
    case 180:
    case 179:
    case 178:
    case 177:
    case 176:
    case 175:
    case 174:
    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
    case 154:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 45:
    case 38:
    case 36:
    case 32:
    case 31:
    case 28:
    case 27:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
      return 65537 /* min 1, max 1 */;

    default:
      if (((ix86_cpu) == (CPU_ATHLON)))
        {
	  return 1 /* min 0, max 1 */;
        }
      else
        {
	  return 65537 /* min 1, max 1 */;
        }

    }
}

extern int k6_fpu_unit_ready_cost PARAMS ((rtx));
int
k6_fpu_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], TFmode)) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_type (insn) == TYPE_FOP) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], XFmode)) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_type (insn) == TYPE_FOP) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], DFmode)) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_type (insn) == TYPE_FOP) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], SFmode)) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_type (insn) == TYPE_FOP) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 348:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], TFmode)) && (((ix86_cpu) == (CPU_K6)))) || ((! (mult_operator (operands[3], TFmode))) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 347:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], XFmode)) && (((ix86_cpu) == (CPU_K6)))) || ((! (mult_operator (operands[3], XFmode))) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 346:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], DFmode)) && (((ix86_cpu) == (CPU_K6)))) || ((! (mult_operator (operands[3], DFmode))) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 345:
      extract_insn_cached (insn);
      if (((mult_operator (operands[3], SFmode)) && (((ix86_cpu) == (CPU_K6)))) || ((! (mult_operator (operands[3], SFmode))) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      if (((ix86_cpu) == (CPU_K6)))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 56 /* 0x38 */;

    }
}

extern unsigned int k6_fpu_unit_blockage_range PARAMS ((rtx));
unsigned int
k6_fpu_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 131128 /* min 2, max 56 */;

    }
}

extern int k6_store_unit_ready_cost PARAMS ((rtx));
int
k6_store_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && (! (const0_operand (operands[2], SImode)))) && ((((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))) || ((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 2;
        }
      else if (((which_alternative != 1) || (const0_operand (operands[2], SImode))) && (((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && ((((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))) || ((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 2;
        }
      else if ((which_alternative == 0) && (((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) && ((((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))) || ((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 2;
        }
      else if ((which_alternative != 3) && (((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 271:
    case 140:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) && ((((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))) || ((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 2;
        }
      else if ((which_alternative != 2) && (((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 135:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode))) && ((((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))) || ((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 2;
        }
      else if (((which_alternative != 2) && (! (pic_symbolic_operand (operands[2], SImode)))) && (((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 134:
    case 133:
    case 132:
    case 131:
      if (((ix86_cpu) == (CPU_K6)))
        {
	  return 2;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 1) && (memory_operand (operands[1], VOIDmode))) && (((ix86_cpu) == (CPU_K6)))) || (((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode)))) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 35:
      if ((get_attr_type (insn) == TYPE_LEA) && ((((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))) || ((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 2;
        }
      else if ((! (get_attr_type (insn) == TYPE_LEA)) && (((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6))))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      if (((memory_operand (operands[1], VOIDmode)) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 317:
    case 316:
    case 45:
    case 38:
    case 32:
    case 31:
      extract_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (((memory_operand (operands[1], VOIDmode)) && (((ix86_cpu) == (CPU_K6)))) || ((! (memory_operand (operands[1], VOIDmode))) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 542:
    case 539:
    case 418:
    case 417:
    case 416:
    case 415:
    case 414:
    case 413:
    case 412:
    case 410:
    case 409:
    case 408:
    case 407:
    case 404:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 338:
    case 337:
    case 336:
    case 335:
    case 334:
    case 333:
    case 332:
    case 331:
    case 329:
    case 328:
    case 327:
    case 326:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 319:
    case 318:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      return 10 /* 0xa */;

    default:
      if (((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    }
}

extern unsigned int k6_store_unit_blockage_range PARAMS ((rtx));
unsigned int
k6_store_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65546 /* min 1, max 10 */;

    }
}

extern int k6_load_unit_ready_cost PARAMS ((rtx));
int
k6_load_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if ((! (constant_call_address_operand (operands[1], VOIDmode))) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if ((! (constant_call_address_operand (operands[0], VOIDmode))) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
      extract_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && (memory_operand (operands[1], VOIDmode))) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 317:
    case 316:
    case 45:
    case 38:
    case 32:
    case 31:
      extract_insn_cached (insn);
      if (((memory_operand (operands[0], VOIDmode)) && (((ix86_cpu) == (CPU_K6)))) || ((! (memory_operand (operands[0], VOIDmode))) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 44:
    case 43:
    case 37:
    case 34:
    case 33:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if ((memory_operand (operands[1], VOIDmode)) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      if ((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 542:
    case 539:
    case 418:
    case 417:
    case 412:
    case 410:
    case 409:
    case 408:
    case 407:
    case 404:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 134:
    case 133:
    case 132:
    case 131:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
      return 10 /* 0xa */;

    default:
      if (((get_attr_memory (insn) == MEMORY_BOTH) && (((ix86_cpu) == (CPU_K6)))) || ((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 1;
        }
      else
        {
	  return 10 /* 0xa */;
        }

    }
}

extern unsigned int k6_load_unit_blockage_range PARAMS ((rtx));
unsigned int
k6_load_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65546 /* min 1, max 10 */;

    }
}

extern int k6_branch_unit_ready_cost PARAMS ((rtx));
int
k6_branch_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int k6_alu_unit_ready_cost PARAMS ((rtx));
int
k6_alu_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 1) && (const0_operand (operands[2], SImode))) && ((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6))))) || ((((which_alternative == 1) && (! (const0_operand (operands[2], SImode)))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((which_alternative == 0) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6))))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 271:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 2) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || (((get_attr_type (insn) == TYPE_ALU) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((get_attr_type (insn) == TYPE_ISHIFT) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6))))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if (((get_attr_type (insn) == TYPE_ALU) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((get_attr_type (insn) == TYPE_ISHIFT) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || (((get_attr_type (insn) == TYPE_ALU) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((get_attr_type (insn) == TYPE_ISHIFT) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6))))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 2) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || (((which_alternative == 0) || (which_alternative == 1)) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      if (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 2;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if (((incdec_operand (operands[2], QImode)) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((! (incdec_operand (operands[2], QImode))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 3) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((((which_alternative != 3) && (incdec_operand (operands[2], QImode))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6))))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if (((incdec_operand (operands[2], HImode)) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((! (incdec_operand (operands[2], HImode))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 2) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((((which_alternative != 2) && (incdec_operand (operands[2], HImode))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6))))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if (((incdec_operand (operands[2], SImode)) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((! (incdec_operand (operands[2], SImode))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 135:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || (((get_attr_type (insn) == TYPE_INCDEC) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((get_attr_type (insn) == TYPE_ALU) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6))))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 404:
    case 317:
    case 316:
    case 134:
    case 133:
    case 132:
    case 131:
      if (((ix86_cpu) == (CPU_K6)))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)) && ((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 54:
    case 52:
      if (((get_attr_type (insn) == TYPE_IMOV) && ((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6))))) || ((get_attr_type (insn) == TYPE_IMOVX) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if (((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))) && ((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6))))) || ((((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if (((get_attr_type (insn) == TYPE_IMOV) && ((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6))))) || ((((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 56:
    case 55:
    case 48:
    case 47:
    case 42:
    case 41:
    case 40:
    case 36:
      if ((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 35:
      if (((get_attr_type (insn) == TYPE_IMOV) && ((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6))))) || ((get_attr_type (insn) == TYPE_LEA) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 340:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 211:
    case 210:
    case 209:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 197:
    case 196:
    case 195:
    case 194:
    case 193:
    case 191:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 82:
    case 81:
    case 79:
    case 78:
    case 77:
    case 53:
    case 51:
    case 50:
    case 49:
    case 43:
    case 34:
    case 33:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 5:
    case 4:
    case 2:
    case 1:
      if (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 277:
    case 83:
    case 80:
    case 6:
    case 3:
    case 0:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))) || ((which_alternative == 1) && (((get_attr_memory (insn) == MEMORY_NONE) && (((ix86_cpu) == (CPU_K6)))) || ((! (get_attr_memory (insn) == MEMORY_NONE)) && (((ix86_cpu) == (CPU_K6)))))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 17 /* 0x11 */;

    }
}

extern unsigned int k6_alu_unit_blockage_range PARAMS ((rtx));
unsigned int
k6_alu_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65553 /* min 1, max 17 */;

    }
}

extern int k6_alux_unit_ready_cost PARAMS ((rtx));
int
k6_alux_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && ((which_alternative == 0) && (general_operand (operands[0], QImode))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && ((get_attr_type (insn) == TYPE_ISHIFT) || ((get_attr_type (insn) == TYPE_ALU) && (general_operand (operands[0], QImode)))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
      if (((ix86_cpu) == (CPU_K6)))
        {
	  return 17 /* 0x11 */;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      if (((ix86_cpu) == (CPU_K6)))
        {
	  return 2;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && ((which_alternative != 3) && (general_operand (operands[0], QImode))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && ((which_alternative != 2) && (general_operand (operands[0], QImode))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 135:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_INCDEC)) && (general_operand (operands[0], QImode))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 277:
    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && ((which_alternative != 0) || (general_operand (operands[0], QImode))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 54:
    case 52:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && ((get_attr_type (insn) == TYPE_IMOVX) && (general_operand (operands[0], QImode))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && ((((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))) && (general_operand (operands[0], QImode))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && ((((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))) && (general_operand (operands[0], QImode))))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 390:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      if (((ix86_cpu) == (CPU_K6)))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case 404:
    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 192:
    case 191:
    case 190:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
    case 139:
    case 138:
    case 137:
    case 136:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 81:
    case 78:
    case 53:
    case 51:
    case 50:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) && (general_operand (operands[0], QImode)))
        {
	  return 1;
        }
      else
        {
	  return 17 /* 0x11 */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 17 /* 0x11 */;

    }
}

extern unsigned int k6_alux_unit_blockage_range PARAMS ((rtx));
unsigned int
k6_alux_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65553 /* min 1, max 17 */;

    }
}

extern int ppro_p34_unit_ready_cost PARAMS ((rtx));
int
ppro_p34_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int ppro_p2_unit_ready_cost PARAMS ((rtx));
int
ppro_p2_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 3;

    }
}

extern int ppro_p01_unit_ready_cost PARAMS ((rtx));
int
ppro_p01_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int ppro_p0_unit_ready_cost PARAMS ((rtx));
int
ppro_p0_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && (! (const0_operand (operands[2], SImode)))) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 410:
    case 409:
    case 408:
    case 407:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 2;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], TFmode)) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 5;
        }
      else if ((get_attr_type (insn) == TYPE_FOP) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 3;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], XFmode)) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 5;
        }
      else if ((get_attr_type (insn) == TYPE_FOP) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 3;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], DFmode)) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 5;
        }
      else if ((get_attr_type (insn) == TYPE_FOP) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 3;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], SFmode)) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 5;
        }
      else if ((get_attr_type (insn) == TYPE_FOP) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 3;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 348:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], TFmode)) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 5;
        }
      else if ((! (mult_operator (operands[3], TFmode))) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 3;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 347:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], XFmode)) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 5;
        }
      else if ((! (mult_operator (operands[3], XFmode))) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 3;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 346:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], DFmode)) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 5;
        }
      else if ((! (mult_operator (operands[3], DFmode))) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 3;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 345:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], SFmode)) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 5;
        }
      else if ((! (mult_operator (operands[3], SFmode))) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 3;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 330:
      if ((get_attr_type (insn) == TYPE_IBR) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 271:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 2) && (((ix86_cpu) == (CPU_PENTIUMPRO)))) || ((get_attr_type (insn) == TYPE_ISHIFT) && (((ix86_cpu) == (CPU_PENTIUMPRO)))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if ((get_attr_type (insn) == TYPE_ISHIFT) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && (((ix86_cpu) == (CPU_PENTIUMPRO)))) || ((get_attr_type (insn) == TYPE_ISHIFT) && (((ix86_cpu) == (CPU_PENTIUMPRO)))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 3;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 17 /* 0x11 */;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 4;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 135:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode))) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 35:
      if ((get_attr_type (insn) == TYPE_LEA) && (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case 390:
    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
    case 134:
    case 133:
    case 132:
    case 131:
    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 1;
        }
      else
        {
	  return 56 /* 0x38 */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 56 /* 0x38 */;

    }
}

extern unsigned int ppro_p0_unit_blockage_range PARAMS ((rtx));
unsigned int
ppro_p0_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65553 /* min 1, max 17 */;

    }
}

extern int pent_v_unit_ready_cost PARAMS ((rtx));
int
pent_v_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 1;

    }
}

extern int pent_uv_unit_ready_cost PARAMS ((rtx));
int
pent_uv_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if ((constant_call_address_operand (operands[1], VOIDmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 411:
      extract_constrain_insn_cached (insn);
      if ((get_attr_memory (insn) == MEMORY_BOTH) && ((which_alternative == 1) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((which_alternative == 0) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((which_alternative == 1) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && ((which_alternative == 0) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && ((which_alternative == 1) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((which_alternative == 0) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((which_alternative == 1) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if ((constant_call_address_operand (operands[0], VOIDmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 330:
      if (((get_attr_memory (insn) == MEMORY_BOTH) && ((get_attr_type (insn) == TYPE_IBR) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_STORE) && ((get_attr_type (insn) == TYPE_IBR) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && ((get_attr_type (insn) == TYPE_IBR) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((get_attr_type (insn) == TYPE_IBR) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
      extract_insn_cached (insn);
      if (((memory_operand (operands[0], VOIDmode)) && (((ix86_cpu) == (CPU_PENTIUM)))) || ((! (memory_operand (operands[0], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_memory (insn) == MEMORY_LOAD) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_memory (insn) == MEMORY_LOAD) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      if ((get_attr_memory (insn) == MEMORY_BOTH) && ((! (get_attr_type (insn) == TYPE_ISHIFT)) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && (((get_attr_type (insn) == TYPE_ISHIFT) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_type (insn) == TYPE_ALU) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((! (get_attr_type (insn) == TYPE_ISHIFT)) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && (((get_attr_type (insn) == TYPE_ISHIFT) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_type (insn) == TYPE_ALU) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && ((! (get_attr_type (insn) == TYPE_ISHIFT)) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((((get_attr_type (insn) == TYPE_ISHIFT) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_type (insn) == TYPE_ALU) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || ((! (get_attr_type (insn) == TYPE_ISHIFT)) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM)))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || ((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 185:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative == 0) || (which_alternative == 2)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (((which_alternative == 0) || (which_alternative == 2)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 184:
    case 183:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_LOAD) && ((which_alternative != 1) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && ((which_alternative != 1) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if ((get_attr_memory (insn) == MEMORY_BOTH) && ((incdec_operand (operands[2], QImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((! (incdec_operand (operands[2], QImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((incdec_operand (operands[2], QImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && ((! (incdec_operand (operands[2], QImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && ((incdec_operand (operands[2], QImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (incdec_operand (operands[2], QImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((incdec_operand (operands[2], QImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if ((get_attr_memory (insn) == MEMORY_BOTH) && (((which_alternative == 3) || (incdec_operand (operands[2], QImode))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && (((which_alternative == 3) || (incdec_operand (operands[2], QImode))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative == 3) || (incdec_operand (operands[2], QImode))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((which_alternative == 3) || (incdec_operand (operands[2], QImode))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((get_attr_memory (insn) == MEMORY_BOTH) && ((incdec_operand (operands[2], HImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((incdec_operand (operands[2], HImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && ((incdec_operand (operands[2], HImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((incdec_operand (operands[2], HImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if ((get_attr_memory (insn) == MEMORY_BOTH) && (((which_alternative == 2) || (incdec_operand (operands[2], HImode))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && (((which_alternative == 2) || (incdec_operand (operands[2], HImode))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative == 2) || (incdec_operand (operands[2], HImode))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((which_alternative == 2) || (incdec_operand (operands[2], HImode))) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if ((get_attr_memory (insn) == MEMORY_BOTH) && ((incdec_operand (operands[2], SImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((! (incdec_operand (operands[2], SImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((incdec_operand (operands[2], SImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && ((! (incdec_operand (operands[2], SImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && ((incdec_operand (operands[2], SImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (incdec_operand (operands[2], SImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((incdec_operand (operands[2], SImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 135:
      if ((get_attr_memory (insn) == MEMORY_BOTH) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((get_attr_type (insn) == TYPE_ALU) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && ((get_attr_type (insn) == TYPE_ALU) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((get_attr_type (insn) == TYPE_ALU) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((! (get_attr_type (insn) == TYPE_ALU)) && ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 404:
    case 134:
    case 133:
    case 132:
    case 131:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 153:
    case 130:
    case 129:
      if (((get_attr_memory (insn) == MEMORY_STORE) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_memory (insn) == MEMORY_LOAD) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 155:
    case 128:
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_PENTIUM)))) || ((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && ((which_alternative == 1) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && ((which_alternative == 1) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((which_alternative == 1) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_BOTH) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_STORE) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2))) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode)))) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_BOTH) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_STORE) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 56:
    case 55:
    case 48:
    case 42:
      if (((get_attr_memory (insn) == MEMORY_BOTH) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_STORE) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 54:
    case 52:
    case 39:
      if (((get_attr_memory (insn) == MEMORY_BOTH) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_STORE) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 35:
      if (((get_attr_memory (insn) == MEMORY_BOTH) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_STORE) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 262:
    case 260:
    case 258:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_PENTIUM)))) || (((! (memory_operand (operands[1], VOIDmode))) && (! (get_attr_memory (insn) == MEMORY_STORE))) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 45:
    case 38:
    case 32:
    case 31:
      extract_insn_cached (insn);
      if ((! (memory_operand (operands[0], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if ((! (memory_operand (operands[1], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 188:
    case 187:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      if (((get_attr_memory (insn) == MEMORY_LOAD) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 3;

    }
}

extern unsigned int pent_uv_unit_blockage_range PARAMS ((rtx));
unsigned int
pent_uv_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65539 /* min 1, max 3 */;

    }
}

extern int pent_u_unit_ready_cost PARAMS ((rtx));
int
pent_u_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_memory (insn) == MEMORY_LOAD) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_memory (insn) == MEMORY_LOAD) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      if ((get_attr_memory (insn) == MEMORY_BOTH) && ((! (get_attr_type (insn) == TYPE_ISHIFT)) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && (((get_attr_type (insn) == TYPE_ISHIFT) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((! (get_attr_type (insn) == TYPE_ISHIFT)) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && (((get_attr_type (insn) == TYPE_ISHIFT) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && ((! (get_attr_type (insn) == TYPE_ISHIFT)) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((((get_attr_type (insn) == TYPE_ISHIFT) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM)))))) || ((! (get_attr_type (insn) == TYPE_ISHIFT)) && ((! (get_attr_type (insn) == TYPE_ALU)) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM)))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 192:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || ((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 218:
    case 217:
    case 216:
    case 207:
    case 206:
    case 205:
    case 193:
    case 161:
    case 160:
    case 159:
      if (((get_attr_memory (insn) == MEMORY_STORE) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((get_attr_memory (insn) == MEMORY_LOAD) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 145:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((get_attr_memory (insn) == MEMORY_BOTH) && ((incdec_operand (operands[2], HImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && ((incdec_operand (operands[2], HImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && ((incdec_operand (operands[2], HImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM)))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((incdec_operand (operands[2], HImode)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if ((get_attr_memory (insn) == MEMORY_BOTH) && (((which_alternative == 2) || (incdec_operand (operands[2], HImode))) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if ((get_attr_memory (insn) == MEMORY_STORE) && (((which_alternative == 2) || (incdec_operand (operands[2], HImode))) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 2;
        }
      else if (((get_attr_memory (insn) == MEMORY_LOAD) && (((which_alternative == 2) || (incdec_operand (operands[2], HImode))) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM)))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((which_alternative == 2) || (incdec_operand (operands[2], HImode))) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 155:
    case 128:
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_PENTIUM)))) || ((get_attr_memory (insn) == MEMORY_LOAD) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 2;
        }
      else if (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 80:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && ((which_alternative == 1) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && ((which_alternative == 1) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((which_alternative == 1) && (((ix86_cpu) == (CPU_PENTIUM)))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_BOTH) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))) && (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_STORE) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))) && (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))) && (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))) && (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 260:
    case 79:
    case 43:
      extract_insn_cached (insn);
      if (((get_attr_memory (insn) == MEMORY_STORE) && (((ix86_cpu) == (CPU_PENTIUM)))) || (((! (memory_operand (operands[1], VOIDmode))) && (! (get_attr_memory (insn) == MEMORY_STORE))) && (((ix86_cpu) == (CPU_PENTIUM)))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 42:
      if (((get_attr_memory (insn) == MEMORY_BOTH) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_STORE) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 39:
      if (((get_attr_memory (insn) == MEMORY_BOTH) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_STORE) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((get_attr_memory (insn) == MEMORY_LOAD) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))) || (((! (get_attr_memory (insn) == MEMORY_BOTH)) && ((! (get_attr_memory (insn) == MEMORY_STORE)) && (! (get_attr_memory (insn) == MEMORY_LOAD)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_PU) && (((ix86_cpu) == (CPU_PENTIUM))))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 45:
    case 38:
      extract_insn_cached (insn);
      if ((! (memory_operand (operands[0], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 44:
    case 37:
      extract_insn_cached (insn);
      if ((! (memory_operand (operands[1], VOIDmode))) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case 5:
    case 4:
    case 3:
      if (((get_attr_memory (insn) == MEMORY_LOAD) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((ix86_cpu) == (CPU_PENTIUM))))))
        {
	  return 1;
        }
      else
        {
	  return 3;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 3;

    }
}

extern unsigned int pent_u_unit_blockage_range PARAMS ((rtx));
unsigned int
pent_u_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65539 /* min 1, max 3 */;

    }
}

extern int fpu_unit_ready_cost PARAMS ((rtx));
int
fpu_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 410:
    case 409:
    case 408:
    case 407:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 1;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
      if ((((ix86_cpu) == (CPU_PENTIUM))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  if (((ix86_cpu) == (CPU_PENTIUM)))
	    {
	      return 70 /* 0x46 */;
	    }
	  else
	    {
	      return 56 /* 0x38 */;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], TFmode))) || (get_attr_type (insn) == TYPE_FDIV))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], TFmode))) || (get_attr_type (insn) == TYPE_FDIV))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
	    {
	      return 56 /* 0x38 */;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
	    {
	      return 39 /* 0x27 */;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], TFmode)))
	    {
	      return 5;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], TFmode))))
	    {
	      return 3;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], XFmode))) || (get_attr_type (insn) == TYPE_FDIV))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], XFmode))) || (get_attr_type (insn) == TYPE_FDIV))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
	    {
	      return 56 /* 0x38 */;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
	    {
	      return 39 /* 0x27 */;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], XFmode)))
	    {
	      return 5;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], XFmode))))
	    {
	      return 3;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], DFmode))) || (get_attr_type (insn) == TYPE_FDIV))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], DFmode))) || (get_attr_type (insn) == TYPE_FDIV))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
	    {
	      return 56 /* 0x38 */;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
	    {
	      return 39 /* 0x27 */;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], DFmode)))
	    {
	      return 5;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], DFmode))))
	    {
	      return 3;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], SFmode))) || (get_attr_type (insn) == TYPE_FDIV))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], SFmode))) || (get_attr_type (insn) == TYPE_FDIV))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
	    {
	      return 56 /* 0x38 */;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
	    {
	      return 39 /* 0x27 */;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], SFmode)))
	    {
	      return 5;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], SFmode))))
	    {
	      return 3;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 348:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], TFmode)))
	    {
	      return 5;
	    }
	  else if (((ix86_cpu) == (CPU_PENTIUM)))
	    {
	      return 3;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 347:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], XFmode)))
	    {
	      return 5;
	    }
	  else if (((ix86_cpu) == (CPU_PENTIUM)))
	    {
	      return 3;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 346:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], DFmode)))
	    {
	      return 5;
	    }
	  else if (((ix86_cpu) == (CPU_PENTIUM)))
	    {
	      return 3;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 345:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], SFmode)))
	    {
	      return 5;
	    }
	  else if (((ix86_cpu) == (CPU_PENTIUM)))
	    {
	      return 3;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  return 4;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)) || ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))) || ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (which_alternative == 0)))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 3;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
      extract_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && (((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)) || ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD)))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUM))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && (((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)) || ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (which_alternative == 0)))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && ((((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))) || ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD)))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 3;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)) || ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))) || ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 3;
	    }
	  else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 76:
    case 75:
    case 66:
    case 61:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 1;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if (((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)) || ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))))
        {
	  if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      if ((((ix86_cpu) == (CPU_PENTIUM))) || (((ix86_cpu) == (CPU_PENTIUMPRO))))
        {
	  return 1;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 70 /* 0x46 */;

    }
}

extern unsigned int fpu_unit_blockage_range PARAMS ((rtx));
unsigned int
fpu_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65604 /* min 1, max 68 */;

    }
}

extern int pent_mul_unit_ready_cost PARAMS ((rtx));
int
pent_mul_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FDIV) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 39 /* 0x27 */;
        }
      else if ((mult_operator (operands[3], TFmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FDIV) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 39 /* 0x27 */;
        }
      else if ((mult_operator (operands[3], XFmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FDIV) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 39 /* 0x27 */;
        }
      else if ((mult_operator (operands[3], DFmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FDIV) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 39 /* 0x27 */;
        }
      else if ((mult_operator (operands[3], SFmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 348:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], TFmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 347:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], XFmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 346:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], DFmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 345:
      extract_insn_cached (insn);
      if ((mult_operator (operands[3], SFmode)) && (((ix86_cpu) == (CPU_PENTIUM))))
        {
	  return 2;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 11 /* 0xb */;
        }
      else
        {
	  return 70 /* 0x46 */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 70 /* 0x46 */;

    }
}

extern unsigned int pent_mul_unit_blockage_range PARAMS ((rtx));
unsigned int
pent_mul_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 131142 /* min 2, max 70 */;

    }
}

extern int pent_np_unit_ready_cost PARAMS ((rtx));
int
pent_np_unit_ready_cost (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((which_alternative == 0) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))
	    {
	      return 3;
	    }
	  else if ((which_alternative == 0) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 12 /* 0xc */;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], TFmode)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], XFmode)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], DFmode)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((get_attr_type (insn) == TYPE_FOP) || (mult_operator (operands[3], SFmode)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode)))))
        {
	  if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH)) || (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (get_attr_memory (insn) == MEMORY_BOTH)))
	    {
	      return 3;
	    }
	  else if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode))))))
        {
	  if (((which_alternative == 1) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH))) || (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH)))
	    {
	      return 3;
	    }
	  else if (((which_alternative == 1) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))) || (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))
	    {
	      return 3;
	    }
	  else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 261:
    case 259:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return 3;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 0) || (which_alternative == 1)))))
        {
	  if (((which_alternative == 0) || (which_alternative == 1)) && ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))
	    {
	      return 3;
	    }
	  else if (((which_alternative == 0) || (which_alternative == 1)) && ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 185:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative != 0) && (which_alternative != 2)) || ((which_alternative == 0) || (which_alternative == 2))))
        {
	  return 1;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 46 /* 0x2e */;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 11 /* 0xb */;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((! (incdec_operand (operands[2], QImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))
	    {
	      return 3;
	    }
	  else if ((! (incdec_operand (operands[2], QImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))
	    {
	      return 3;
	    }
	  else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((! (incdec_operand (operands[2], HImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))
	    {
	      return 3;
	    }
	  else if ((! (incdec_operand (operands[2], HImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))
	    {
	      return 3;
	    }
	  else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((! (incdec_operand (operands[2], SImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))))
	    {
	      return 3;
	    }
	  else if ((! (incdec_operand (operands[2], SImode))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 135:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((get_attr_type (insn) == TYPE_ALU) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && (get_attr_memory (insn) == MEMORY_BOTH))))
	    {
	      return 3;
	    }
	  else if ((get_attr_type (insn) == TYPE_ALU) && (((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_pent_pair (insn) == PENT_PAIR_NP)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 153:
    case 130:
    case 129:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
	    {
	      return 3;
	    }
	  else if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 276:
    case 265:
    case 155:
    case 128:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (get_attr_memory (insn) == MEMORY_BOTH)
	    {
	      return 3;
	    }
	  else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
	    {
	      return 3;
	    }
	  else if (which_alternative == 0)
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (which_alternative == 0)
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
	    {
	      return 3;
	    }
	  else
	    {
	      return 2;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((which_alternative == 1) && (get_attr_memory (insn) == MEMORY_BOTH))
	    {
	      return 3;
	    }
	  else if ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
	    {
	      return 3;
	    }
	  else if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))))
        {
	  if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative != 1) || (memory_operand (operands[1], VOIDmode))) || ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode))))))
        {
	  return 1;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))))))
        {
	  return 1;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 54:
    case 52:
    case 39:
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV))))
        {
	  return 1;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 35:
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA)))))
        {
	  return 1;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 262:
    case 260:
    case 258:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return 3;
	    }
	  else if (get_attr_memory (insn) == MEMORY_STORE)
	    {
	      return 2;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case 410:
    case 409:
    case 408:
    case 407:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 348:
    case 347:
    case 346:
    case 345:
    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 2;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 1;
        }
      else
        {
	  return 46 /* 0x2e */;
        }

    }
}

extern unsigned int pent_np_unit_blockage_range PARAMS ((rtx));
unsigned int
pent_np_unit_blockage_range (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (! (constant_call_address_operand (operands[1], VOIDmode)))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], TFmode))))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], XFmode))))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], DFmode))))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], SFmode))))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (! (constant_call_address_operand (operands[0], VOIDmode)))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 330:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (! (get_attr_type (insn) == TYPE_IBR))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode)))))
        {
	  if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode))))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode))))))
        {
	  if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode)))))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 0) || (which_alternative == 1)))))
        {
	  if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1)))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 185:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative != 0) && (which_alternative != 2)) || ((which_alternative == 0) || (which_alternative == 2))))
        {
	  if ((which_alternative != 0) && (which_alternative != 2))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 184:
    case 183:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (which_alternative == 1)
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
    case 146:
    case 140:
    case 135:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (which_alternative != 0)
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (which_alternative == 0)
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if ((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2)))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))))
        {
	  if ((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2)))
	    {
	      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
	        {
		  return 65582 /* min 1, max 46 */;
	        }
	      else
	        {
		  return 46 /* min 0, max 46 */;
	        }
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative != 1) || (memory_operand (operands[1], VOIDmode))) || ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode))))))
        {
	  if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))))))
        {
	  if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 54:
    case 52:
    case 39:
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV))))
        {
	  if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV)))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 35:
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA)))))
        {
	  if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA))))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 404:
    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
    case 262:
    case 260:
    case 258:
    case 211:
    case 209:
    case 197:
    case 195:
    case 155:
    case 134:
    case 133:
    case 132:
    case 131:
    case 128:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 46 /* min 0, max 46 */;
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 45:
    case 38:
    case 32:
    case 31:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (memory_operand (operands[0], VOIDmode))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 410:
    case 409:
    case 408:
    case 407:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 348:
    case 347:
    case 346:
    case 345:
    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  return 46 /* min 0, max 46 */;
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case 411:
    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 188:
    case 187:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
    case 139:
    case 138:
    case 137:
    case 136:
    case 130:
    case 129:
    case 56:
    case 55:
    case 48:
    case 42:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
	    {
	      return 65582 /* min 1, max 46 */;
	    }
	  else
	    {
	      return 46 /* min 0, max 46 */;
	    }
        }
      else
        {
	  return 65582 /* min 1, max 46 */;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 65582 /* min 1, max 46 */;

    }
}

extern int function_units_used PARAMS ((rtx));
int
function_units_used (insn)
     rtx insn;
{
  register enum attr_athlon_fpunits attr_athlon_fpunits = get_attr_athlon_fpunits (insn);
  register enum attr_athlon_decode attr_athlon_decode = get_attr_athlon_decode (insn);
  register enum attr_memory attr_memory = get_attr_memory (insn);
  register enum attr_mode attr_mode = get_attr_mode (insn);
  register enum attr_pent_pair attr_pent_pair = get_attr_pent_pair (insn);
  register enum attr_type attr_type = get_attr_type (insn);
  register unsigned long accum = 0;

  accum |= (((((ix86_cpu) == (CPU_PENTIUM))) && (((((((((attr_type == TYPE_IMUL) || (attr_type == TYPE_STR)) || (attr_type == TYPE_IDIV)) || ((attr_type == TYPE_FMOV) && (((attr_memory == MEMORY_LOAD) || (attr_memory == MEMORY_STORE)) && (attr_mode == MODE_XF)))) || ((attr_type == TYPE_FMOV) && ((immediate_operand (operands[1], VOIDmode)) || (attr_memory == MEMORY_STORE)))) || (attr_type == TYPE_CLD)) || (attr_pent_pair == PENT_PAIR_NP)) || (! (attr_pent_pair == PENT_PAIR_NP))) || ((attr_type == TYPE_FMOV) || ((attr_type == TYPE_FOP) || ((attr_type == TYPE_FOP1) || ((attr_type == TYPE_FSGN) || ((attr_type == TYPE_FMUL) || ((attr_type == TYPE_FPSPC) || ((attr_type == TYPE_FCMOV) || (attr_type == TYPE_FCMP)))))))))) ? (1) : (0));
  accum |= (((((ix86_cpu) == (CPU_PENTIUM))) && ((((attr_type == TYPE_IMUL) || (attr_type == TYPE_FMUL)) || (attr_type == TYPE_FDIV)) || (attr_type == TYPE_FPSPC))) ? (2) : (0));
  accum |= ((((((ix86_cpu) == (CPU_PENTIUM))) && (((((((attr_type == TYPE_FMOV) && (((((attr_memory == MEMORY_LOAD) || (attr_memory == MEMORY_STORE)) && (attr_mode == MODE_XF)) || ((immediate_operand (operands[1], VOIDmode)) || (attr_memory == MEMORY_STORE))) || ((attr_memory == MEMORY_NONE) || (attr_memory == MEMORY_LOAD)))) || ((attr_type == TYPE_FCMP) || ((attr_type == TYPE_FXCH) || (attr_type == TYPE_FSGN)))) || ((attr_type == TYPE_FOP) || (attr_type == TYPE_FOP1))) || (attr_type == TYPE_FMUL)) || (attr_type == TYPE_FDIV)) || (attr_type == TYPE_FPSPC))) || ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (((((attr_type == TYPE_FOP) || ((attr_type == TYPE_FOP1) || ((attr_type == TYPE_FSGN) || ((attr_type == TYPE_FMOV) || ((attr_type == TYPE_FCMP) || (attr_type == TYPE_FCMOV)))))) || (attr_type == TYPE_FMUL)) || ((attr_type == TYPE_FDIV) || (attr_type == TYPE_FPSPC))) || (attr_type == TYPE_IMUL)))) ? (4) : (0));
  accum |= (((((ix86_cpu) == (CPU_PENTIUM))) && (attr_pent_pair == PENT_PAIR_PU)) ? (8) : (0));
  accum |= (((((ix86_cpu) == (CPU_PENTIUM))) && (! (attr_pent_pair == PENT_PAIR_NP))) ? (16) : (0));
  accum |= (((((ix86_cpu) == (CPU_PENTIUM))) && (attr_pent_pair == PENT_PAIR_PV)) ? (32) : (0));
  accum |= (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((((((((((attr_type == TYPE_ISHIFT) || ((attr_type == TYPE_LEA) || ((attr_type == TYPE_IBR) || (attr_type == TYPE_CLD)))) || (attr_type == TYPE_IMUL)) || (attr_type == TYPE_IDIV)) || ((attr_type == TYPE_FOP) || ((attr_type == TYPE_FOP1) || (attr_type == TYPE_FSGN)))) || (attr_type == TYPE_FCMOV)) || (attr_type == TYPE_FCMP)) || (attr_type == TYPE_FMOV)) || (attr_type == TYPE_FMUL)) || ((attr_type == TYPE_FDIV) || (attr_type == TYPE_FPSPC)))) ? (64) : (0));
  accum |= ((((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! ((attr_type == TYPE_IMOV) || (attr_type == TYPE_FMOV)))) || (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((attr_type == TYPE_IMOV) || (attr_type == TYPE_FMOV))) && (attr_memory == MEMORY_NONE))) ? (128) : (0));
  accum |= (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((attr_type == TYPE_POP) || ((attr_memory == MEMORY_LOAD) || (attr_memory == MEMORY_BOTH)))) ? (256) : (0));
  accum |= (((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((attr_type == TYPE_PUSH) || ((attr_memory == MEMORY_STORE) || (attr_memory == MEMORY_BOTH)))) ? (512) : (0));
  accum |= (((((ix86_cpu) == (CPU_K6))) && (((((attr_type == TYPE_ISHIFT) || ((attr_type == TYPE_ALU1) || ((attr_type == TYPE_NEGNOT) || (attr_type == TYPE_CLD)))) || (((attr_type == TYPE_ALU) || ((attr_type == TYPE_ALU1) || ((attr_type == TYPE_NEGNOT) || ((attr_type == TYPE_ICMP) || ((attr_type == TYPE_TEST) || ((attr_type == TYPE_IMOVX) || (attr_type == TYPE_INCDEC))))))) && (general_operand (operands[0], QImode)))) || (attr_type == TYPE_IMUL)) || (attr_type == TYPE_IDIV))) ? (1024) : (0));
  accum |= (((((ix86_cpu) == (CPU_K6))) && (((((attr_type == TYPE_ISHIFT) || ((attr_type == TYPE_ALU1) || ((attr_type == TYPE_NEGNOT) || ((attr_type == TYPE_ALU) || ((attr_type == TYPE_ICMP) || ((attr_type == TYPE_TEST) || ((attr_type == TYPE_IMOVX) || ((attr_type == TYPE_INCDEC) || ((attr_type == TYPE_SETCC) || (attr_type == TYPE_LEA)))))))))) || ((attr_type == TYPE_IMOV) && (attr_memory == MEMORY_NONE))) || (attr_type == TYPE_IMUL)) || (attr_type == TYPE_IDIV))) ? (2048) : (0));
  accum |= (((((ix86_cpu) == (CPU_K6))) && ((attr_type == TYPE_CALL) || ((attr_type == TYPE_CALLV) || (attr_type == TYPE_IBR)))) ? (4096) : (0));
  accum |= (((((ix86_cpu) == (CPU_K6))) && (((attr_type == TYPE_POP) || ((attr_memory == MEMORY_LOAD) || (attr_memory == MEMORY_BOTH))) || ((attr_type == TYPE_STR) && ((attr_memory == MEMORY_LOAD) || (attr_memory == MEMORY_BOTH))))) ? (8192) : (0));
  accum |= (((((ix86_cpu) == (CPU_K6))) && (((attr_type == TYPE_LEA) || (attr_type == TYPE_STR)) || ((attr_type == TYPE_PUSH) || ((attr_memory == MEMORY_STORE) || (attr_memory == MEMORY_BOTH))))) ? (16384) : (0));
  accum |= (((((ix86_cpu) == (CPU_K6))) && ((((attr_type == TYPE_FOP) || ((attr_type == TYPE_FOP1) || ((attr_type == TYPE_FMOV) || (attr_type == TYPE_FCMP)))) || (attr_type == TYPE_FMUL)) || ((attr_type == TYPE_FDIV) || (attr_type == TYPE_FPSPC)))) ? (32768) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && ((attr_athlon_decode == ATHLON_DECODE_VECTOR) || (attr_athlon_decode == ATHLON_DECODE_DIRECT))) ? (65536) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && (attr_athlon_decode == ATHLON_DECODE_DIRECT)) ? (131072) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && (((((attr_type == TYPE_ALU1) || ((attr_type == TYPE_NEGNOT) || ((attr_type == TYPE_ALU) || ((attr_type == TYPE_ICMP) || ((attr_type == TYPE_TEST) || ((attr_type == TYPE_IMOV) || ((attr_type == TYPE_IMOVX) || ((attr_type == TYPE_LEA) || ((attr_type == TYPE_INCDEC) || ((attr_type == TYPE_ISHIFT) || ((attr_type == TYPE_IBR) || ((attr_type == TYPE_CALL) || ((attr_type == TYPE_CALLV) || ((attr_type == TYPE_ICMOV) || ((attr_type == TYPE_CLD) || ((attr_type == TYPE_POP) || ((attr_type == TYPE_SETCC) || (attr_type == TYPE_PUSH)))))))))))))))))) || (attr_type == TYPE_STR)) || (attr_type == TYPE_IMUL)) || (attr_type == TYPE_IDIV))) ? (262144) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && ((attr_type == TYPE_IMUL) || (attr_type == TYPE_IDIV))) ? (524288) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && ((((((((attr_type == TYPE_FPSPC) || (attr_type == TYPE_FDIV)) || ((attr_type == TYPE_FOP) || ((attr_type == TYPE_FOP1) || (attr_type == TYPE_FMUL)))) || ((attr_type == TYPE_FMOV) && ((attr_memory == MEMORY_LOAD) && (attr_mode == MODE_XF)))) || ((attr_type == TYPE_FMOV) || (attr_type == TYPE_FSGN))) || ((attr_type == TYPE_FCMP) && (attr_athlon_decode == ATHLON_DECODE_DIRECT))) || ((attr_type == TYPE_FCMP) && (attr_athlon_decode == ATHLON_DECODE_VECTOR))) || (attr_type == TYPE_FCMOV))) ? (1048576) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && (attr_athlon_fpunits == ATHLON_FPUNITS_MUL)) ? (2097152) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && (attr_athlon_fpunits == ATHLON_FPUNITS_ADD)) ? (4194304) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && ((attr_athlon_fpunits == ATHLON_FPUNITS_MULADD) || ((attr_athlon_fpunits == ATHLON_FPUNITS_MUL) || (attr_athlon_fpunits == ATHLON_FPUNITS_ADD)))) ? (8388608) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && ((attr_memory == MEMORY_LOAD) || (attr_memory == MEMORY_BOTH))) ? (33554432) : (0));
  accum |= (((((ix86_cpu) == (CPU_ATHLON))) && (attr_athlon_fpunits == ATHLON_FPUNITS_STORE)) ? (16777216) : (0));

  if (accum && accum == (accum & -accum))
    {
      int i;
      for (i = 0; accum >>= 1; ++i) continue;
      accum = i;
    }
  else
    accum = ~accum;
  return accum;
}

extern enum attr_athlon_fpunits get_attr_athlon_fpunits PARAMS ((rtx));
enum attr_athlon_fpunits
get_attr_athlon_fpunits (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  return ATHLON_FPUNITS_ADD;
        }
      else if ((mult_operator (operands[3], TFmode)) || (get_attr_type (insn) == TYPE_FDIV))
        {
	  return ATHLON_FPUNITS_MUL;
        }
      else
        {
	  return ATHLON_FPUNITS_NONE;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  return ATHLON_FPUNITS_ADD;
        }
      else if ((mult_operator (operands[3], XFmode)) || (get_attr_type (insn) == TYPE_FDIV))
        {
	  return ATHLON_FPUNITS_MUL;
        }
      else
        {
	  return ATHLON_FPUNITS_NONE;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  return ATHLON_FPUNITS_ADD;
        }
      else if ((mult_operator (operands[3], DFmode)) || (get_attr_type (insn) == TYPE_FDIV))
        {
	  return ATHLON_FPUNITS_MUL;
        }
      else
        {
	  return ATHLON_FPUNITS_NONE;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  return ATHLON_FPUNITS_ADD;
        }
      else if ((mult_operator (operands[3], SFmode)) || (get_attr_type (insn) == TYPE_FDIV))
        {
	  return ATHLON_FPUNITS_MUL;
        }
      else
        {
	  return ATHLON_FPUNITS_NONE;
        }

    case 348:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], TFmode)))
        {
	  return ATHLON_FPUNITS_ADD;
        }
      else
        {
	  return ATHLON_FPUNITS_MUL;
        }

    case 347:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], XFmode)))
        {
	  return ATHLON_FPUNITS_ADD;
        }
      else
        {
	  return ATHLON_FPUNITS_MUL;
        }

    case 346:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], DFmode)))
        {
	  return ATHLON_FPUNITS_ADD;
        }
      else
        {
	  return ATHLON_FPUNITS_MUL;
        }

    case 345:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], SFmode)))
        {
	  return ATHLON_FPUNITS_ADD;
        }
      else
        {
	  return ATHLON_FPUNITS_MUL;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_STORE) || (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  return ATHLON_FPUNITS_STORE;
        }
      else if ((which_alternative == 0) && (get_attr_memory (insn) == MEMORY_LOAD))
        {
	  return ATHLON_FPUNITS_ANY;
        }
      else if ((which_alternative == 0) && ((register_operand (operands[1], SImode)) || (immediate_operand (operands[1], VOIDmode))))
        {
	  return ATHLON_FPUNITS_STORE;
        }
      else if (which_alternative == 0)
        {
	  return ATHLON_FPUNITS_MULADD;
        }
      else
        {
	  return ATHLON_FPUNITS_NONE;
        }

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_insn_cached (insn);
      if ((get_attr_memory (insn) == MEMORY_STORE) || (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  return ATHLON_FPUNITS_STORE;
        }
      else if (get_attr_memory (insn) == MEMORY_LOAD)
        {
	  return ATHLON_FPUNITS_ANY;
        }
      else if ((register_operand (operands[1], SImode)) || (immediate_operand (operands[1], VOIDmode)))
        {
	  return ATHLON_FPUNITS_STORE;
        }
      else
        {
	  return ATHLON_FPUNITS_MULADD;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_STORE) || (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  return ATHLON_FPUNITS_STORE;
        }
      else if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (get_attr_memory (insn) == MEMORY_LOAD))
        {
	  return ATHLON_FPUNITS_ANY;
        }
      else if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((register_operand (operands[1], SImode)) || (immediate_operand (operands[1], VOIDmode))))
        {
	  return ATHLON_FPUNITS_STORE;
        }
      else if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return ATHLON_FPUNITS_MULADD;
        }
      else
        {
	  return ATHLON_FPUNITS_NONE;
        }

    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      return ATHLON_FPUNITS_ADD;

    case 410:
    case 409:
    case 408:
    case 407:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
      return ATHLON_FPUNITS_MUL;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return ATHLON_FPUNITS_NONE;

    }
}

extern enum attr_athlon_decode get_attr_athlon_decode PARAMS ((rtx));
enum attr_athlon_decode
get_attr_athlon_decode (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 330:
      if (get_attr_type (insn) == TYPE_MULTI)
        {
	  return ATHLON_DECODE_VECTOR;
        }
      else
        {
	  return ATHLON_DECODE_DIRECT;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 0) || ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  return ATHLON_DECODE_VECTOR;
        }
      else
        {
	  return ATHLON_DECODE_DIRECT;
        }

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return ATHLON_DECODE_VECTOR;
        }
      else
        {
	  return ATHLON_DECODE_DIRECT;
        }

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  return ATHLON_DECODE_VECTOR;
        }
      else
        {
	  return ATHLON_DECODE_DIRECT;
        }

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || ((which_alternative == 4) || (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
        {
	  return ATHLON_DECODE_VECTOR;
        }
      else
        {
	  return ATHLON_DECODE_DIRECT;
        }

    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || (which_alternative == 4))
        {
	  return ATHLON_DECODE_VECTOR;
        }
      else
        {
	  return ATHLON_DECODE_DIRECT;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
        {
	  return ATHLON_DECODE_VECTOR;
        }
      else
        {
	  return ATHLON_DECODE_DIRECT;
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return ATHLON_DECODE_VECTOR;
        }
      else
        {
	  return ATHLON_DECODE_DIRECT;
        }

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  return ATHLON_DECODE_VECTOR;
        }
      else
        {
	  return ATHLON_DECODE_DIRECT;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 418:
    case 417:
    case 412:
    case 410:
    case 409:
    case 408:
    case 407:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 344:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 334:
    case 333:
    case 332:
    case 331:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 182:
    case 181:
    case 180:
    case 179:
    case 178:
    case 177:
    case 176:
    case 175:
    case 174:
    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
    case 154:
    case 127:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 45:
    case 38:
    case 32:
    case 31:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
    case 26:
    case 27:
    case 28:
    case 36:
    case 114:
    case 265:
    case 343:
      return ATHLON_DECODE_VECTOR;

    default:
      return ATHLON_DECODE_DIRECT;

    }
}

extern enum attr_fp_int_src get_attr_fp_int_src PARAMS ((rtx));
enum attr_fp_int_src
get_attr_fp_int_src (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 115:
    case 116:
    case 117:
    case 118:
    case 119:
    case 120:
    case 121:
    case 122:
    case 123:
    case 124:
    case 125:
    case 126:
    case 350:
    case 351:
    case 353:
    case 354:
    case 359:
    case 360:
    case 361:
    case 362:
      return FP_INT_SRC_TRUE;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return FP_INT_SRC_FALSE;

    }
}

extern enum attr_imm_disp get_attr_imm_disp PARAMS ((rtx));
enum attr_imm_disp
get_attr_imm_disp (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 1) && (const0_operand (operands[2], SImode))) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode)))) || ((which_alternative == 0) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode)))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 330:
      if (get_attr_type (insn) == TYPE_MULTI)
        {
	  return IMM_DISP_UNKNOWN;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      extract_insn_cached (insn);
      if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || (which_alternative == 1)) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], QImode))) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], HImode))) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], SImode))) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 135:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 340:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 130:
    case 129:
    case 128:
      extract_insn_cached (insn);
      if ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[2], VOIDmode)))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return IMM_DISP_UNKNOWN;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || (which_alternative == 4))
        {
	  return IMM_DISP_UNKNOWN;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return IMM_DISP_UNKNOWN;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return IMM_DISP_UNKNOWN;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 54:
    case 52:
    case 39:
    case 35:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_IMOV) && ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 56:
    case 55:
    case 48:
    case 47:
    case 42:
    case 41:
    case 40:
    case 36:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      extract_insn_cached (insn);
      if ((memory_displacement_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode)))
        {
	  return IMM_DISP_TRUE;
        }
      else
        {
	  return IMM_DISP_FALSE;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 418:
    case 417:
    case 412:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
      return IMM_DISP_UNKNOWN;

    default:
      return IMM_DISP_FALSE;

    }
}

extern int get_attr_i387 PARAMS ((rtx));
int
get_attr_i387 (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FOP) || ((mult_operator (operands[3], TFmode)) || (get_attr_type (insn) == TYPE_FDIV)))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FOP) || ((mult_operator (operands[3], XFmode)) || (get_attr_type (insn) == TYPE_FDIV)))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FOP) || ((mult_operator (operands[3], DFmode)) || (get_attr_type (insn) == TYPE_FDIV)))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_FOP) || ((mult_operator (operands[3], SFmode)) || (get_attr_type (insn) == TYPE_FDIV)))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 410:
    case 409:
    case 408:
    case 407:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 348:
    case 347:
    case 346:
    case 345:
    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
    case 76:
    case 75:
    case 66:
    case 61:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
    case 25:
    case 113:
    case 114:
      return 1;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

extern int get_attr_length_address PARAMS ((rtx));
int
get_attr_length_address (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
    case 334:
    case 333:
    case 332:
    case 331:
      extract_constrain_insn_cached (insn);
      if (constant_call_address_operand (operands[1], VOIDmode))
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_address_default (insn);
        }

    case 330:
      extract_constrain_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_MULTI)
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_address_default (insn);
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_address_default (insn);
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || (which_alternative == 4))
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_address_default (insn);
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_address_default (insn);
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_address_default (insn);
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 418:
    case 417:
    case 412:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 390:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 76:
    case 75:
    case 70:
    case 69:
    case 68:
    case 67:
    case 66:
    case 63:
    case 62:
    case 61:
    case 57:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
      return 0;

    default:
      extract_constrain_insn_cached (insn);
      return ix86_attr_length_address_default (insn);

    }
}

extern int get_attr_length_immediate PARAMS ((rtx));
int
get_attr_length_immediate (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if (constant_call_address_operand (operands[1], VOIDmode))
        {
	  return 4;
        }
      else
        {
	  return 0;
        }

    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (! (const0_operand (operands[2], SImode))))
        {
	  return 0;
        }
      else if (which_alternative == 0)
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }
      else
        {
	  return ix86_attr_length_immediate_default(insn,0);
        }

    case 370:
    case 369:
    case 368:
    case 367:
    case 366:
    case 365:
    case 364:
    case 363:
    case 362:
    case 361:
    case 360:
    case 359:
    case 358:
    case 357:
    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
    case 351:
    case 350:
    case 349:
      extract_constrain_insn_cached (insn);
      if (get_attr_i387 (insn) == 1)
        {
	  return 0;
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if (constant_call_address_operand (operands[0], VOIDmode))
        {
	  return 4;
        }
      else
        {
	  return 0;
        }

    case 330:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_IBR) || (get_attr_type (insn) == TYPE_MULTI))
        {
	  return 0;
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }

    case 271:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  return 0;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT))
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT))
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  return 0;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT))
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }
      else
        {
	  return 0;
        }

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_constrain_insn_cached (insn);
      if (incdec_operand (operands[2], QImode))
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if ((incdec_operand (operands[2], QImode)) || (which_alternative == 3))
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_constrain_insn_cached (insn);
      if (incdec_operand (operands[2], HImode))
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if ((incdec_operand (operands[2], HImode)) || (which_alternative == 2))
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }

    case 139:
    case 138:
    case 137:
    case 136:
      extract_constrain_insn_cached (insn);
      if (incdec_operand (operands[2], SImode))
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }

    case 135:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_INCDEC) || ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode))))
        {
	  return 0;
        }
      else if (get_attr_type (insn) == TYPE_ALU)
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_immediate_default(insn,0);
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }

    case 54:
    case 52:
      extract_constrain_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_IMOVX)
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }
      else if (get_attr_type (insn) == TYPE_IMOV)
        {
	  return ix86_attr_length_immediate_default(insn,0);
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }
      else if (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))
        {
	  return ix86_attr_length_immediate_default(insn,0);
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if (((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4))))))
        {
	  return ix86_attr_length_immediate_default(insn,1);
        }
      else if (get_attr_type (insn) == TYPE_IMOV)
        {
	  return ix86_attr_length_immediate_default(insn,0);
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 188:
    case 187:
    case 185:
    case 184:
    case 183:
    case 56:
    case 55:
    case 48:
    case 47:
    case 42:
    case 41:
    case 40:
    case 36:
      extract_constrain_insn_cached (insn);
      return ix86_attr_length_immediate_default(insn,0);

    case 35:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_LEA) || (get_attr_type (insn) == TYPE_MMX))
        {
	  return 0;
        }
      else if (get_attr_type (insn) == TYPE_IMOV)
        {
	  return ix86_attr_length_immediate_default(insn,0);
        }
      else
        {
	  return /* Update immediate_length and other attributes! */ abort(),1;
        }

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 223:
    case 222:
    case 221:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 211:
    case 210:
    case 209:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 197:
    case 196:
    case 195:
    case 194:
    case 193:
    case 191:
    case 173:
    case 166:
    case 165:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 83:
    case 82:
    case 81:
    case 80:
    case 79:
    case 78:
    case 77:
    case 53:
    case 51:
    case 50:
    case 45:
    case 44:
    case 38:
    case 37:
    case 32:
    case 31:
    case 30:
    case 29:
    case 12:
    case 11:
    case 9:
    case 8:
    case 7:
    case 5:
    case 4:
    case 2:
    case 1:
      extract_constrain_insn_cached (insn);
      return ix86_attr_length_immediate_default(insn,1);

    case 0:
    case 3:
    case 6:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 34:
    case 186:
    case 198:
    case 199:
      return 1;

    case 337:
      return 2;

    case 340:
      return 4;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

extern enum attr_memory get_attr_memory PARAMS ((rtx));
enum attr_memory
get_attr_memory (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if (constant_call_address_operand (operands[1], VOIDmode))
        {
	  return MEMORY_NONE;
        }
      else
        {
	  return MEMORY_LOAD;
        }

    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (! (const0_operand (operands[2], SImode))))
        {
	  return MEMORY_NONE;
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (((which_alternative != 1) || (! (const0_operand (operands[2], SImode)))) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 406:
    case 405:
      extract_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || ((memory_operand (operands[2], VOIDmode)) || (memory_operand (operands[3], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if (constant_call_address_operand (operands[0], VOIDmode))
        {
	  return MEMORY_NONE;
        }
      else
        {
	  return MEMORY_LOAD;
        }

    case 330:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_MULTI)
        {
	  return MEMORY_UNKNOWN;
        }
      else if (get_attr_type (insn) == TYPE_IBR)
        {
	  if (memory_operand (operands[0], VOIDmode))
	    {
	      return MEMORY_LOAD;
	    }
	  else
	    {
	      return MEMORY_NONE;
	    }
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (memory_operand (operands[2], VOIDmode)))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
      extract_insn_cached (insn);
      if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || ((which_alternative == 1) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  return MEMORY_NONE;
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (memory_operand (operands[2], VOIDmode)))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (((which_alternative == 0) || (which_alternative == 1)) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 3)
        {
	  return MEMORY_NONE;
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (memory_operand (operands[2], VOIDmode)))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 271:
    case 140:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  return MEMORY_NONE;
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (memory_operand (operands[2], VOIDmode)))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 135:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode)))
        {
	  return MEMORY_NONE;
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (memory_operand (operands[2], VOIDmode)))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return MEMORY_UNKNOWN;
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if (memory_operand (operands[1], VOIDmode))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 1) && (memory_operand (operands[1], VOIDmode))) || ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode))))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if (memory_operand (operands[1], VOIDmode))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || (which_alternative == 4))
        {
	  return MEMORY_UNKNOWN;
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 370:
    case 369:
    case 368:
    case 367:
    case 366:
    case 365:
    case 364:
    case 363:
    case 362:
    case 361:
    case 360:
    case 359:
    case 358:
    case 357:
    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
    case 351:
    case 350:
    case 349:
    case 348:
    case 347:
    case 346:
    case 345:
    case 340:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
    case 265:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
    case 139:
    case 138:
    case 137:
    case 136:
    case 130:
    case 129:
    case 128:
    case 76:
    case 75:
    case 66:
    case 61:
      extract_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (memory_operand (operands[2], VOIDmode)))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (((((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2)) && ((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2)))) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MEMORY_UNKNOWN;
        }
      else
        {
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return MEMORY_BOTH;
	    }
	  else
	    {
	      return MEMORY_STORE;
	    }
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return MEMORY_UNKNOWN;
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (((which_alternative != 2) && (which_alternative != 3)) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 54:
    case 52:
      extract_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_IMOVX))) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (((((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (((! (get_attr_type (insn) == TYPE_IMOV)) && (((((which_alternative == 0) || (which_alternative == 1)) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_HIMODE_MATH) == (0)))) || (((which_alternative == 2) || ((which_alternative == 3) || (which_alternative == 4))) && (aligned_operand (operands[1], HImode)))) || ((! ((TARGET_MOVX) != (0))) || ((which_alternative != 0) && ((which_alternative != 1) && ((which_alternative != 3) && (which_alternative != 4))))))) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 35:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_LEA)
        {
	  return MEMORY_NONE;
        }
      else if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if ((memory_operand (operands[1], VOIDmode)) || (((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_MMX))) && (memory_operand (operands[2], VOIDmode))))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case 317:
    case 316:
    case 45:
    case 38:
    case 32:
    case 31:
      extract_insn_cached (insn);
      if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_BOTH;
        }
      else
        {
	  return MEMORY_LOAD;
        }

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  return MEMORY_BOTH;
        }
      else
        {
	  return MEMORY_STORE;
        }

    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      extract_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) || (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 418:
    case 417:
    case 412:
    case 403:
    case 402:
    case 401:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
    case 539:
    case 542:
      return MEMORY_UNKNOWN;

    case 391:
    case 392:
    case 393:
    case 394:
    case 395:
      return MEMORY_BOTH;

    case 396:
    case 397:
    case 398:
    case 399:
    case 400:
      return MEMORY_STORE;

    case 410:
    case 409:
    case 408:
    case 407:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 134:
    case 133:
    case 132:
    case 131:
    case 404:
      return MEMORY_NONE;

    default:
      extract_insn_cached (insn);
      if ((memory_operand (operands[0], VOIDmode)) && (memory_operand (operands[1], VOIDmode)))
        {
	  return MEMORY_BOTH;
        }
      else if (memory_operand (operands[0], VOIDmode))
        {
	  return MEMORY_STORE;
        }
      else if (memory_operand (operands[1], VOIDmode))
        {
	  return MEMORY_LOAD;
        }
      else
        {
	  return MEMORY_NONE;
        }

    }
}

extern int get_attr_modrm PARAMS ((rtx));
int
get_attr_modrm (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 370:
    case 369:
    case 368:
    case 367:
    case 366:
    case 365:
    case 364:
    case 363:
    case 362:
    case 361:
    case 360:
    case 359:
    case 358:
    case 357:
    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
    case 351:
    case 350:
    case 349:
      if (get_attr_i387 (insn) == 1)
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 185:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else if ((which_alternative == 1) || (which_alternative == 2))
        {
	  return 1;
        }
      else
        {
	  return 1;
        }

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if ((incdec_operand (operands[2], QImode)) && ((register_operand (operands[1], SImode)) || (register_operand (operands[1], HImode))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (incdec_operand (operands[2], QImode))) && ((register_operand (operands[1], SImode)) || (register_operand (operands[1], HImode))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((incdec_operand (operands[2], HImode)) && ((register_operand (operands[1], SImode)) || (register_operand (operands[1], HImode))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (incdec_operand (operands[2], HImode))) && ((register_operand (operands[1], SImode)) || (register_operand (operands[1], HImode))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if ((incdec_operand (operands[2], SImode)) && ((register_operand (operands[1], SImode)) || (register_operand (operands[1], HImode))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 135:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_INCDEC) && ((register_operand (operands[1], SImode)) || (register_operand (operands[1], HImode))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 88:
    case 87:
      extract_constrain_insn_cached (insn);
      if ((! (((ix86_cpu) == (CPU_K6)))) && (which_alternative == 0))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 2) || ((register_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))) && ((register_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 48:
    case 42:
      extract_insn_cached (insn);
      if ((register_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode)))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else if ((which_alternative == 1) || (which_alternative == 2))
        {
	  if ((get_attr_type (insn) == TYPE_IMOV) && ((register_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else if (which_alternative == 3)
        {
	  return 0;
        }
      else
        {
	  if ((get_attr_type (insn) == TYPE_IMOV) && ((register_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }
        }

    case 35:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else if (which_alternative == 1)
        {
	  if ((get_attr_type (insn) == TYPE_IMOV) && ((register_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }
        }
      else if (which_alternative == 2)
        {
	  return 0;
        }
      else
        {
	  if ((get_attr_type (insn) == TYPE_IMOV) && ((register_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }
        }

    case 45:
    case 38:
    case 32:
    case 31:
      extract_insn_cached (insn);
      if (! (memory_operand (operands[0], VOIDmode)))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (! (memory_operand (operands[1], VOIDmode)))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 51:
    case 50:
    case 49:
    case 43:
    case 34:
    case 33:
    case 26:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      return 1;

    case 183:
    case 184:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else if (which_alternative == 1)
        {
	  return 1;
        }
      else
        {
	  return 1;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
    case 277:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 410:
    case 409:
    case 408:
    case 407:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 348:
    case 347:
    case 346:
    case 345:
    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
    case 114:
    case 113:
    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
    case 76:
    case 75:
    case 66:
    case 61:
    case 28:
    case 27:
    case 25:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
    case 36:
    case 40:
    case 41:
    case 47:
    case 336:
    case 337:
    case 339:
    case 343:
      return 0;

    default:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_IMOV) && ((register_operand (operands[0], VOIDmode)) && (immediate_operand (operands[1], VOIDmode))))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    }
}

extern enum attr_mode get_attr_mode PARAMS ((rtx));
enum attr_mode
get_attr_mode (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 185:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return MODE_QI;
        }
      else
        {
	  return MODE_SI;
        }

    case 219:
    case 208:
    case 196:
    case 194:
    case 147:
    case 146:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return MODE_QI;
        }
      else
        {
	  return MODE_SI;
        }

    case 192:
    case 140:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return MODE_HI;
        }
      else
        {
	  return MODE_SI;
        }

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return MODE_XF;
        }
      else
        {
	  return MODE_SI;
        }

    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return MODE_DF;
        }
      else
        {
	  return MODE_SI;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return MODE_SF;
        }
      else
        {
	  return MODE_SI;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || ((which_alternative == 4) || (which_alternative == 5)))
        {
	  return MODE_SI;
        }
      else if (which_alternative == 6)
        {
	  return MODE_QI;
        }
      else if ((((TARGET_MOVX) != (0)) && (which_alternative == 2)) || (((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && (((TARGET_PARTIAL_REG_DEPENDENCY) != (0)) || (((TARGET_PARTIAL_REG_STALL) != (0)) && ((TARGET_QIMODE_MATH) == (0)))))))
        {
	  return MODE_SI;
        }
      else
        {
	  return MODE_QI;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if ((((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))) || ((((which_alternative == 2) || ((which_alternative == 3) || (which_alternative == 4))) && (aligned_operand (operands[1], HImode))) || (((which_alternative == 0) || (which_alternative == 1)) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_HIMODE_MATH) == (0))))))
        {
	  return MODE_SI;
        }
      else
        {
	  return MODE_HI;
        }

    case 52:
    case 54:
      if (get_attr_type (insn) == TYPE_IMOVX)
        {
	  return MODE_SI;
        }
      else
        {
	  return MODE_QI;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MODE_SF;
        }
      else
        {
	  return MODE_SI;
        }

    case 62:
    case 63:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MODE_DF;
        }
      else
        {
	  return MODE_SI;
        }

    case 68:
    case 67:
    case 69:
    case 70:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MODE_XF;
        }
      else
        {
	  return MODE_SI;
        }

    case 95:
    case 96:
    case 97:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MODE_SF;
        }
      else
        {
	  return MODE_XF;
        }

    case 98:
    case 99:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MODE_DF;
        }
      else
        {
	  return MODE_XF;
        }

    case 268:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MODE_HI;
        }
      else
        {
	  return MODE_SI;
        }

    case 271:
    case 261:
    case 272:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MODE_QI;
        }
      else
        {
	  return MODE_SI;
        }

    case 18:
    case 19:
    case 20:
    case 21:
    case 75:
    case 76:
    case 121:
    case 122:
    case 123:
    case 124:
    case 125:
    case 126:
    case 238:
    case 239:
    case 240:
    case 241:
    case 242:
    case 243:
    case 252:
    case 253:
    case 255:
    case 256:
    case 347:
    case 348:
    case 357:
    case 358:
    case 374:
    case 375:
    case 376:
    case 377:
    case 378:
    case 379:
    case 383:
    case 384:
    case 388:
    case 389:
    case 409:
    case 410:
      return MODE_XF;

    case 16:
    case 17:
    case 66:
    case 106:
    case 107:
    case 108:
    case 109:
    case 118:
    case 119:
    case 120:
    case 236:
    case 237:
    case 249:
    case 250:
    case 251:
    case 254:
    case 346:
    case 352:
    case 367:
    case 368:
    case 369:
    case 370:
    case 372:
    case 373:
    case 380:
    case 382:
    case 385:
    case 387:
    case 408:
      return MODE_DF;

    case 14:
    case 15:
    case 61:
    case 100:
    case 101:
    case 102:
    case 103:
    case 104:
    case 105:
    case 115:
    case 116:
    case 117:
    case 235:
    case 248:
    case 345:
    case 349:
    case 355:
    case 356:
    case 363:
    case 364:
    case 365:
    case 366:
    case 371:
    case 381:
    case 386:
    case 407:
      return MODE_SF;

    case 13:
    case 22:
    case 23:
    case 27:
    case 28:
      return MODE_UNKNOWNFP;

    case 0:
    case 1:
    case 2:
    case 25:
    case 26:
    case 29:
    case 30:
    case 31:
    case 32:
    case 33:
    case 34:
    case 35:
    case 36:
    case 41:
    case 50:
    case 51:
    case 53:
    case 77:
    case 78:
    case 82:
    case 83:
    case 84:
    case 85:
    case 87:
    case 89:
    case 128:
    case 129:
    case 131:
    case 132:
    case 133:
    case 134:
    case 135:
    case 136:
    case 137:
    case 138:
    case 139:
    case 144:
    case 155:
    case 156:
    case 157:
    case 158:
    case 165:
    case 170:
    case 171:
    case 172:
    case 173:
    case 178:
    case 179:
    case 180:
    case 181:
    case 183:
    case 190:
    case 191:
    case 202:
    case 203:
    case 204:
    case 213:
    case 214:
    case 215:
    case 225:
    case 226:
    case 257:
    case 258:
    case 265:
    case 266:
    case 267:
    case 276:
    case 277:
    case 279:
    case 281:
    case 293:
    case 295:
    case 305:
    case 311:
    case 340:
    case 350:
    case 351:
    case 353:
    case 354:
    case 359:
    case 360:
    case 361:
    case 362:
    case 391:
    case 394:
    case 395:
    case 396:
    case 399:
    case 404:
    case 405:
    case 411:
      return MODE_SI;

    case 3:
    case 4:
    case 5:
    case 37:
    case 38:
    case 40:
    case 42:
    case 43:
    case 44:
    case 45:
    case 79:
    case 80:
    case 81:
    case 88:
    case 113:
    case 114:
    case 141:
    case 142:
    case 143:
    case 145:
    case 159:
    case 160:
    case 161:
    case 166:
    case 182:
    case 184:
    case 193:
    case 205:
    case 206:
    case 207:
    case 216:
    case 217:
    case 218:
    case 227:
    case 228:
    case 259:
    case 260:
    case 269:
    case 270:
    case 283:
    case 285:
    case 297:
    case 299:
    case 307:
    case 313:
    case 392:
    case 397:
    case 406:
      return MODE_HI;

    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
    case 47:
    case 48:
    case 49:
    case 55:
    case 56:
    case 130:
    case 148:
    case 149:
    case 150:
    case 151:
    case 152:
    case 153:
    case 162:
    case 163:
    case 164:
    case 167:
    case 168:
    case 169:
    case 174:
    case 175:
    case 186:
    case 187:
    case 188:
    case 195:
    case 197:
    case 198:
    case 199:
    case 200:
    case 201:
    case 209:
    case 210:
    case 211:
    case 212:
    case 220:
    case 221:
    case 222:
    case 223:
    case 229:
    case 230:
    case 262:
    case 273:
    case 287:
    case 289:
    case 301:
    case 303:
    case 309:
    case 315:
    case 316:
    case 317:
    case 393:
    case 398:
    case 400:
    case 401:
    case 402:
    case 403:
      return MODE_QI;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return MODE_UNKNOWN;

    }
}

extern enum attr_ppro_uops get_attr_ppro_uops PARAMS ((rtx));
enum attr_ppro_uops
get_attr_ppro_uops (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (const0_operand (operands[2], SImode)))
        {
	  if ((get_attr_memory (insn) == MEMORY_STORE) || (get_attr_memory (insn) == MEMORY_BOTH))
	    {
	      return PPRO_UOPS_FEW;
	    }
	  else
	    {
	      return PPRO_UOPS_ONE;
	    }
        }
      else if (! (get_attr_memory (insn) == MEMORY_NONE))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
      extract_insn_cached (insn);
      if (memory_operand (operands[0], VOIDmode))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return PPRO_UOPS_MANY;
        }
      else if (! (get_attr_memory (insn) == MEMORY_NONE))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || (which_alternative == 4))
        {
	  return PPRO_UOPS_MANY;
        }
      else if (! (get_attr_memory (insn) == MEMORY_NONE))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2))
        {
	  if ((get_attr_memory (insn) == MEMORY_STORE) || (get_attr_memory (insn) == MEMORY_BOTH))
	    {
	      return PPRO_UOPS_FEW;
	    }
	  else
	    {
	      return PPRO_UOPS_ONE;
	    }
        }
      else if (! (get_attr_memory (insn) == MEMORY_NONE))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return PPRO_UOPS_MANY;
        }
      else
        {
	  return PPRO_UOPS_FEW;
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return PPRO_UOPS_MANY;
        }
      else if (! (get_attr_memory (insn) == MEMORY_NONE))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))
        {
	  if ((get_attr_memory (insn) == MEMORY_STORE) || (get_attr_memory (insn) == MEMORY_BOTH))
	    {
	      return PPRO_UOPS_FEW;
	    }
	  else
	    {
	      return PPRO_UOPS_ONE;
	    }
        }
      else if (! (get_attr_memory (insn) == MEMORY_NONE))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    case 56:
    case 55:
    case 48:
    case 42:
      if ((get_attr_memory (insn) == MEMORY_STORE) || (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    case 54:
    case 52:
    case 39:
    case 35:
      if (get_attr_type (insn) == TYPE_IMOV)
        {
	  if ((get_attr_memory (insn) == MEMORY_STORE) || (get_attr_memory (insn) == MEMORY_BOTH))
	    {
	      return PPRO_UOPS_FEW;
	    }
	  else
	    {
	      return PPRO_UOPS_ONE;
	    }
        }
      else if (! (get_attr_memory (insn) == MEMORY_NONE))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 418:
    case 417:
    case 416:
    case 415:
    case 414:
    case 413:
    case 412:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 342:
    case 341:
    case 337:
    case 336:
    case 335:
    case 334:
    case 333:
    case 332:
    case 331:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 127:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
    case 330:
    case 350:
    case 351:
    case 353:
    case 354:
    case 359:
    case 360:
    case 361:
    case 362:
      return PPRO_UOPS_MANY;

    case 542:
    case 539:
    case 410:
    case 409:
    case 408:
    case 407:
    case 406:
    case 405:
    case 390:
    case 317:
    case 316:
    case 45:
    case 44:
    case 38:
    case 37:
    case 32:
    case 31:
    case 30:
    case 29:
    case 25:
    case 36:
    case 40:
    case 41:
    case 47:
    case 113:
    case 114:
    case 128:
    case 155:
    case 170:
    case 172:
    case 173:
    case 174:
    case 175:
    case 178:
    case 181:
    case 182:
    case 235:
    case 236:
    case 237:
    case 238:
    case 239:
    case 240:
    case 241:
    case 242:
    case 243:
    case 265:
    case 276:
    case 343:
    case 344:
      return PPRO_UOPS_FEW;

    case 404:
    case 134:
    case 133:
    case 132:
    case 131:
    case 26:
    case 339:
      return PPRO_UOPS_ONE;

    default:
      if (! (get_attr_memory (insn) == MEMORY_NONE))
        {
	  return PPRO_UOPS_FEW;
        }
      else
        {
	  return PPRO_UOPS_ONE;
        }

    }
}

extern enum attr_pent_pair get_attr_pent_pair PARAMS ((rtx));
enum attr_pent_pair
get_attr_pent_pair (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if (constant_call_address_operand (operands[1], VOIDmode))
        {
	  return PENT_PAIR_PV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if (constant_call_address_operand (operands[0], VOIDmode))
        {
	  return PENT_PAIR_PV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 330:
      if (get_attr_type (insn) == TYPE_IBR)
        {
	  return PENT_PAIR_PV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if (const_int_operand (operands[2], VOIDmode))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 271:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) || (which_alternative == 2))
        {
	  return PENT_PAIR_UV;
        }
      else if ((get_attr_type (insn) == TYPE_ISHIFT) && (const_int_operand (operands[2], VOIDmode)))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 270:
    case 269:
      extract_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) || ((get_attr_type (insn) == TYPE_ISHIFT) && (const_int_operand (operands[2], VOIDmode))))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 268:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if ((which_alternative != 0) || (get_attr_type (insn) == TYPE_ALU))
        {
	  if (which_alternative == 0)
	    {
	      return PENT_PAIR_PU;
	    }
	  else
	    {
	      return PENT_PAIR_UV;
	    }
        }
      else if ((get_attr_type (insn) == TYPE_ISHIFT) && (const_int_operand (operands[2], VOIDmode)))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 273:
    case 272:
    case 267:
      extract_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if (get_attr_type (insn) == TYPE_ALU)
        {
	  return PENT_PAIR_UV;
        }
      else if ((get_attr_type (insn) == TYPE_ISHIFT) && (const_int_operand (operands[2], VOIDmode)))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 266:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if ((which_alternative != 0) || (get_attr_type (insn) == TYPE_ALU))
        {
	  return PENT_PAIR_UV;
        }
      else if ((get_attr_type (insn) == TYPE_ISHIFT) && (const_int_operand (operands[2], VOIDmode)))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 192:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 190:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) || ((which_alternative == 3) || (incdec_operand (operands[2], QImode))))
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) || ((which_alternative == 2) || (incdec_operand (operands[2], HImode))))
        {
	  if ((which_alternative == 0) || (which_alternative == 1))
	    {
	      return PENT_PAIR_PU;
	    }
	  else
	    {
	      return PENT_PAIR_UV;
	    }
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 135:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) || (((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode))) || (get_attr_type (insn) == TYPE_INCDEC)))
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 83:
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 80:
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2))
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode))))
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 54:
    case 52:
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if (get_attr_type (insn) == TYPE_IMOV)
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))
        {
	  if (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))
	    {
	      return PENT_PAIR_PU;
	    }
	  else
	    {
	      return PENT_PAIR_UV;
	    }
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if (get_attr_type (insn) == TYPE_IMOV)
        {
	  if ((((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))) || (get_attr_mode (insn) == MODE_HI))
	    {
	      return PENT_PAIR_PU;
	    }
	  else
	    {
	      return PENT_PAIR_UV;
	    }
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 45:
    case 38:
      extract_insn_cached (insn);
      if (! (memory_operand (operands[0], VOIDmode)))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 44:
    case 37:
      extract_insn_cached (insn);
      if (! (memory_operand (operands[1], VOIDmode)))
        {
	  return PENT_PAIR_PU;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 35:
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else if ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 32:
    case 31:
      extract_insn_cached (insn);
      if (! (memory_operand (operands[0], VOIDmode)))
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 30:
    case 29:
      extract_insn_cached (insn);
      if (! (memory_operand (operands[1], VOIDmode)))
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 218:
    case 217:
    case 216:
    case 207:
    case 206:
    case 205:
    case 193:
    case 161:
    case 160:
    case 159:
    case 145:
    case 143:
    case 142:
    case 141:
    case 42:
    case 5:
    case 4:
    case 3:
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else
        {
	  return PENT_PAIR_PU;
        }

    case 411:
    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 191:
    case 188:
    case 187:
    case 164:
    case 163:
    case 162:
    case 158:
    case 157:
    case 156:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 144:
    case 139:
    case 138:
    case 137:
    case 136:
    case 130:
    case 129:
    case 56:
    case 55:
    case 48:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 2:
    case 1:
    case 0:
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  return PENT_PAIR_NP;
        }
      else
        {
	  return PENT_PAIR_UV;
        }

    case 183:
    case 184:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return PENT_PAIR_UV;
        }
      else if (which_alternative == 1)
        {
	  return PENT_PAIR_NP;
        }
      else
        {
	  return PENT_PAIR_UV;
        }

    case 185:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return PENT_PAIR_UV;
        }
      else if (which_alternative == 1)
        {
	  return PENT_PAIR_NP;
        }
      else if (which_alternative == 2)
        {
	  return PENT_PAIR_UV;
        }
      else
        {
	  return PENT_PAIR_NP;
        }

    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
      return PENT_PAIR_PV;

    case 260:
    case 79:
    case 43:
    case 128:
    case 155:
      return PENT_PAIR_PU;

    case 404:
    case 262:
    case 258:
    case 211:
    case 209:
    case 197:
    case 195:
    case 134:
    case 133:
    case 132:
    case 131:
    case 82:
    case 77:
    case 49:
    case 34:
    case 33:
      return PENT_PAIR_UV;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return PENT_PAIR_NP;

    }
}

extern enum attr_pent_prefix get_attr_pent_prefix PARAMS ((rtx));
enum attr_pent_prefix
get_attr_pent_prefix (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 319:
    case 318:
      if (get_attr_prefix_0f (insn) == 1)
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 190:
    case 165:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 0) && (which_alternative != 1))
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 87:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_K6))) || (which_alternative != 0))
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 268:
    case 83:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) || (which_alternative == 3))
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 54:
    case 52:
      if (get_attr_type (insn) == TYPE_IMOVX)
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if ((((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))) || (get_attr_mode (insn) == MODE_HI))
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 35:
      if (get_attr_type (insn) == TYPE_MMX)
        {
	  return PENT_PREFIX_TRUE;
        }
      else
        {
	  return PENT_PREFIX_FALSE;
        }

    case 543:
    case 542:
    case 541:
    case 540:
    case 539:
    case 538:
    case 537:
    case 536:
    case 535:
    case 534:
    case 533:
    case 532:
    case 531:
    case 530:
    case 529:
    case 528:
    case 527:
    case 526:
    case 525:
    case 524:
    case 523:
    case 522:
    case 521:
    case 520:
    case 519:
    case 518:
    case 517:
    case 516:
    case 515:
    case 514:
    case 513:
    case 512:
    case 511:
    case 510:
    case 509:
    case 508:
    case 507:
    case 506:
    case 505:
    case 504:
    case 503:
    case 502:
    case 501:
    case 500:
    case 499:
    case 498:
    case 497:
    case 496:
    case 495:
    case 494:
    case 493:
    case 492:
    case 491:
    case 490:
    case 489:
    case 488:
    case 487:
    case 486:
    case 485:
    case 484:
    case 483:
    case 482:
    case 481:
    case 480:
    case 479:
    case 478:
    case 477:
    case 476:
    case 475:
    case 474:
    case 473:
    case 472:
    case 471:
    case 470:
    case 469:
    case 468:
    case 467:
    case 466:
    case 465:
    case 464:
    case 463:
    case 462:
    case 461:
    case 460:
    case 459:
    case 458:
    case 457:
    case 456:
    case 455:
    case 454:
    case 453:
    case 452:
    case 451:
    case 450:
    case 449:
    case 448:
    case 447:
    case 446:
    case 445:
    case 444:
    case 443:
    case 442:
    case 441:
    case 440:
    case 439:
    case 438:
    case 437:
    case 436:
    case 435:
    case 434:
    case 433:
    case 432:
    case 431:
    case 430:
    case 429:
    case 428:
    case 427:
    case 426:
    case 425:
    case 424:
    case 423:
    case 422:
    case 421:
    case 420:
    case 419:
    case 406:
    case 405:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 397:
    case 395:
    case 394:
    case 392:
    case 344:
    case 317:
    case 316:
    case 313:
    case 307:
    case 299:
    case 297:
    case 285:
    case 283:
    case 276:
    case 270:
    case 269:
    case 265:
    case 260:
    case 259:
    case 228:
    case 227:
    case 218:
    case 217:
    case 216:
    case 207:
    case 206:
    case 205:
    case 193:
    case 192:
    case 184:
    case 182:
    case 166:
    case 161:
    case 160:
    case 159:
    case 145:
    case 143:
    case 142:
    case 141:
    case 114:
    case 113:
    case 89:
    case 88:
    case 84:
    case 81:
    case 80:
    case 79:
    case 78:
    case 53:
    case 51:
    case 50:
    case 45:
    case 44:
    case 43:
    case 42:
    case 40:
    case 38:
    case 37:
    case 5:
    case 4:
    case 3:
      return PENT_PREFIX_TRUE;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return PENT_PREFIX_FALSE;

    }
}

extern int get_attr_prefix_0f PARAMS ((rtx));
int
get_attr_prefix_0f (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 277:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 0;
        }
      else
        {
	  return 0;
        }

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 0) && (which_alternative != 1))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 166:
    case 165:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) || (which_alternative == 3))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 54:
    case 52:
      if (get_attr_type (insn) == TYPE_IMOVX)
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if (((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4))))))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 35:
      if (get_attr_type (insn) == TYPE_MMX)
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 87:
    case 88:
      extract_constrain_insn_cached (insn);
      if ((! (((ix86_cpu) == (CPU_K6)))) && (which_alternative == 0))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 318:
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (-128)) && (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) < (124)))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 319:
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (-128)) && (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) < (124)))
        {
	  return 0;
        }
      else
        {
	  return 1;
        }

    case 543:
    case 542:
    case 541:
    case 540:
    case 539:
    case 538:
    case 537:
    case 536:
    case 535:
    case 534:
    case 533:
    case 532:
    case 531:
    case 530:
    case 529:
    case 528:
    case 527:
    case 526:
    case 525:
    case 524:
    case 523:
    case 522:
    case 521:
    case 520:
    case 519:
    case 518:
    case 517:
    case 516:
    case 515:
    case 514:
    case 513:
    case 512:
    case 511:
    case 510:
    case 509:
    case 508:
    case 507:
    case 506:
    case 505:
    case 504:
    case 503:
    case 502:
    case 501:
    case 500:
    case 499:
    case 498:
    case 497:
    case 496:
    case 495:
    case 494:
    case 493:
    case 492:
    case 491:
    case 490:
    case 489:
    case 488:
    case 487:
    case 486:
    case 485:
    case 484:
    case 483:
    case 482:
    case 481:
    case 480:
    case 479:
    case 478:
    case 477:
    case 476:
    case 475:
    case 474:
    case 473:
    case 472:
    case 471:
    case 470:
    case 469:
    case 468:
    case 467:
    case 466:
    case 465:
    case 464:
    case 463:
    case 462:
    case 461:
    case 460:
    case 459:
    case 458:
    case 457:
    case 456:
    case 455:
    case 454:
    case 453:
    case 452:
    case 451:
    case 450:
    case 449:
    case 448:
    case 447:
    case 446:
    case 445:
    case 444:
    case 443:
    case 442:
    case 441:
    case 440:
    case 439:
    case 438:
    case 437:
    case 436:
    case 435:
    case 434:
    case 433:
    case 432:
    case 431:
    case 430:
    case 429:
    case 428:
    case 427:
    case 426:
    case 425:
    case 424:
    case 423:
    case 422:
    case 421:
    case 420:
    case 419:
    case 406:
    case 405:
    case 317:
    case 316:
    case 89:
    case 84:
    case 81:
    case 78:
    case 53:
    case 51:
    case 50:
    case 265:
    case 276:
    case 344:
      return 1;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

extern int get_attr_prefix_rep PARAMS ((rtx));
int
get_attr_prefix_rep (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 394:
    case 395:
    case 399:
    case 400:
    case 401:
    case 402:
    case 403:
      return 1;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

extern int get_attr_prefix_data16 PARAMS ((rtx));
int
get_attr_prefix_data16 (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 268:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 192:
    case 140:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case 406:
    case 397:
    case 392:
    case 313:
    case 307:
    case 299:
    case 297:
    case 285:
    case 283:
    case 270:
    case 269:
    case 260:
    case 259:
    case 228:
    case 227:
    case 218:
    case 217:
    case 216:
    case 207:
    case 206:
    case 205:
    case 193:
    case 184:
    case 182:
    case 166:
    case 161:
    case 160:
    case 159:
    case 145:
    case 143:
    case 142:
    case 141:
    case 114:
    case 113:
    case 88:
    case 81:
    case 80:
    case 79:
    case 45:
    case 44:
    case 43:
    case 42:
    case 40:
    case 38:
    case 37:
    case 5:
    case 4:
    case 3:
      return 1;

    case 39:
      if (get_attr_mode (insn) == MODE_HI)
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      return 0;

    }
}

extern enum attr_type get_attr_type PARAMS ((rtx));
enum attr_type
get_attr_type (insn)
     rtx insn;
{
  switch (recog_memoized (insn))
    {
    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return TYPE_ALU;
        }
      else
        {
	  return TYPE_IMOVX;
        }

    case 135:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode)))
        {
	  return TYPE_LEA;
        }
      else if (incdec_operand (operands[2], SImode))
        {
	  return TYPE_INCDEC;
        }
      else
        {
	  return TYPE_ALU;
        }

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return TYPE_FMOV;
        }
      else if (which_alternative == 3)
        {
	  return TYPE_MULTI;
        }
      else
        {
	  return TYPE_MULTI;
        }

    case 60:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  return TYPE_FMOV;
        }
      else
        {
	  return TYPE_IMOV;
        }

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  return TYPE_OTHER;
        }
      else if (which_alternative == 2)
        {
	  return TYPE_MMX;
        }
      else
        {
	  return TYPE_MMX;
        }

    case 46:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0))))
        {
	  return TYPE_IMOV;
        }
      else if ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))
        {
	  return TYPE_IMOVX;
        }
      else
        {
	  return TYPE_IMOV;
        }

    case 39:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 0) || (which_alternative == 1)) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_HIMODE_MATH) == (0)))) || (((which_alternative == 2) || ((which_alternative == 3) || (which_alternative == 4))) && (aligned_operand (operands[1], HImode))))
        {
	  return TYPE_IMOV;
        }
      else if (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))
        {
	  return TYPE_IMOVX;
        }
      else
        {
	  return TYPE_IMOV;
        }

    case 0:
    case 3:
    case 6:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return TYPE_TEST;
        }
      else
        {
	  return TYPE_ICMP;
        }

    case 35:
      extract_constrain_insn_cached (insn);
      if ((mmx_reg_operand (operands[0], SImode)) || (mmx_reg_operand (operands[1], SImode)))
        {
	  return TYPE_MMX;
        }
      else if (((flag_pic) != (0)) && (symbolic_operand (operands[1], SImode)))
        {
	  return TYPE_LEA;
        }
      else
        {
	  return TYPE_IMOV;
        }

    case 52:
      extract_constrain_insn_cached (insn);
      if ((register_operand (operands[0], QImode)) && ((! (q_regs_operand (operands[0], QImode))) || ((TARGET_MOVX) != (0))))
        {
	  return TYPE_IMOVX;
        }
      else
        {
	  return TYPE_IMOV;
        }

    case 54:
      extract_constrain_insn_cached (insn);
      if ((register_operand (operands[0], QImode)) && ((! (q_regs_operand (operands[0], QImode))) || ((TARGET_MOVX) != (0))))
        {
	  return TYPE_IMOVX;
        }
      else
        {
	  return TYPE_IMOV;
        }

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return TYPE_MULTI;
        }
      else
        {
	  return TYPE_PUSH;
        }

    case 80:
    case 83:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return TYPE_IMOVX;
        }
      else
        {
	  return TYPE_ALU1;
        }

    case 100:
    case 102:
    case 104:
    case 106:
    case 108:
    case 115:
    case 116:
    case 117:
    case 118:
    case 119:
    case 120:
    case 121:
    case 122:
    case 123:
    case 124:
    case 125:
    case 126:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return TYPE_FMOV;
        }
      else
        {
	  return TYPE_MULTI;
        }

    case 136:
    case 137:
    case 138:
    case 139:
      extract_insn_cached (insn);
      if (incdec_operand (operands[2], SImode))
        {
	  return TYPE_INCDEC;
        }
      else
        {
	  return TYPE_ALU;
        }

    case 140:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  return TYPE_LEA;
        }
      else
        {
	  if (incdec_operand (operands[2], HImode))
	    {
	      return TYPE_INCDEC;
	    }
	  else
	    {
	      return TYPE_ALU;
	    }
        }

    case 146:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 3)
        {
	  return TYPE_LEA;
        }
      else
        {
	  if (incdec_operand (operands[2], QImode))
	    {
	      return TYPE_INCDEC;
	    }
	  else
	    {
	      return TYPE_ALU;
	    }
        }

    case 141:
    case 142:
    case 143:
    case 144:
    case 145:
    case 150:
      extract_insn_cached (insn);
      if (incdec_operand (operands[2], HImode))
        {
	  return TYPE_INCDEC;
        }
      else
        {
	  return TYPE_ALU;
        }

    case 147:
    case 148:
    case 149:
    case 151:
    case 152:
      extract_insn_cached (insn);
      if (incdec_operand (operands[2], QImode))
        {
	  return TYPE_INCDEC;
        }
      else
        {
	  return TYPE_ALU;
        }

    case 266:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  return TYPE_LEA;
        }
      else if ((((TARGET_DOUBLE_WITH_ADD) != (0)) && (register_operand (operands[0], VOIDmode))) && (const1_operand (operands[2], VOIDmode)))
        {
	  return TYPE_ALU;
        }
      else
        {
	  return TYPE_ISHIFT;
        }

    case 267:
      extract_constrain_insn_cached (insn);
      if ((((TARGET_DOUBLE_WITH_ADD) != (0)) && (register_operand (operands[0], VOIDmode))) && (const1_operand (operands[2], VOIDmode)))
        {
	  return TYPE_ALU;
        }
      else
        {
	  return TYPE_ISHIFT;
        }

    case 268:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  return TYPE_LEA;
        }
      else if ((((TARGET_DOUBLE_WITH_ADD) != (0)) && (register_operand (operands[0], VOIDmode))) && (const1_operand (operands[2], VOIDmode)))
        {
	  return TYPE_ALU;
        }
      else
        {
	  return TYPE_ISHIFT;
        }

    case 269:
      extract_constrain_insn_cached (insn);
      if ((((TARGET_DOUBLE_WITH_ADD) != (0)) && (register_operand (operands[0], VOIDmode))) && (const1_operand (operands[2], VOIDmode)))
        {
	  return TYPE_ALU;
        }
      else
        {
	  return TYPE_ISHIFT;
        }

    case 270:
      extract_constrain_insn_cached (insn);
      if ((((TARGET_DOUBLE_WITH_ADD) != (0)) && (register_operand (operands[0], VOIDmode))) && (const1_operand (operands[2], VOIDmode)))
        {
	  return TYPE_ALU;
        }
      else
        {
	  return TYPE_ISHIFT;
        }

    case 271:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  return TYPE_LEA;
        }
      else if ((((TARGET_DOUBLE_WITH_ADD) != (0)) && (register_operand (operands[0], VOIDmode))) && (const1_operand (operands[2], VOIDmode)))
        {
	  return TYPE_ALU;
        }
      else
        {
	  return TYPE_ISHIFT;
        }

    case 272:
      extract_constrain_insn_cached (insn);
      if ((((TARGET_DOUBLE_WITH_ADD) != (0)) && (register_operand (operands[0], VOIDmode))) && (const1_operand (operands[2], VOIDmode)))
        {
	  return TYPE_ALU;
        }
      else
        {
	  return TYPE_ISHIFT;
        }

    case 273:
      extract_constrain_insn_cached (insn);
      if ((((TARGET_DOUBLE_WITH_ADD) != (0)) && (register_operand (operands[0], VOIDmode))) && (const1_operand (operands[2], VOIDmode)))
        {
	  return TYPE_ALU;
        }
      else
        {
	  return TYPE_ISHIFT;
        }

    case 277:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return TYPE_IMOVX;
        }
      else
        {
	  return TYPE_ISHIFT;
        }

    case 330:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) >= (-128)) && (((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) < (124))))
        {
	  return TYPE_IBR;
        }
      else
        {
	  return TYPE_MULTI;
        }

    case 345:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], SFmode))
        {
	  return TYPE_FMUL;
        }
      else
        {
	  return TYPE_FOP;
        }

    case 346:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], DFmode))
        {
	  return TYPE_FMUL;
        }
      else
        {
	  return TYPE_FOP;
        }

    case 347:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], XFmode))
        {
	  return TYPE_FMUL;
        }
      else
        {
	  return TYPE_FOP;
        }

    case 348:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], TFmode))
        {
	  return TYPE_FMUL;
        }
      else
        {
	  return TYPE_FOP;
        }

    case 349:
    case 350:
    case 351:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], SFmode))
        {
	  return TYPE_FMUL;
        }
      else if (div_operator (operands[3], SFmode))
        {
	  return TYPE_FDIV;
        }
      else
        {
	  return TYPE_FOP;
        }

    case 352:
    case 353:
    case 354:
    case 355:
    case 356:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], DFmode))
        {
	  return TYPE_FMUL;
        }
      else if (div_operator (operands[3], DFmode))
        {
	  return TYPE_FDIV;
        }
      else
        {
	  return TYPE_FOP;
        }

    case 357:
    case 359:
    case 361:
    case 363:
    case 365:
    case 367:
    case 369:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], XFmode))
        {
	  return TYPE_FMUL;
        }
      else if (div_operator (operands[3], XFmode))
        {
	  return TYPE_FDIV;
        }
      else
        {
	  return TYPE_FOP;
        }

    case 358:
    case 360:
    case 362:
    case 364:
    case 366:
    case 368:
    case 370:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], TFmode))
        {
	  return TYPE_FMUL;
        }
      else if (div_operator (operands[3], TFmode))
        {
	  return TYPE_FDIV;
        }
      else
        {
	  return TYPE_FOP;
        }

    case 411:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return TYPE_ALU;
        }
      else if (const0_operand (operands[2], SImode))
        {
	  return TYPE_IMOV;
        }
      else
        {
	  return TYPE_LEA;
        }

    case 421:
    case 422:
    case 423:
    case 427:
    case 428:
    case 429:
    case 483:
    case 484:
    case 485:
    case 486:
    case 487:
    case 488:
    case 489:
    case 490:
    case 491:
    case 492:
    case 493:
    case 494:
    case 495:
    case 496:
    case 497:
    case 498:
    case 499:
    case 500:
    case 501:
    case 502:
    case 503:
    case 504:
    case 505:
    case 512:
    case 513:
    case 514:
    case 515:
    case 516:
    case 517:
    case 522:
    case 523:
    case 524:
    case 525:
    case 526:
    case 527:
    case 528:
    case 529:
    case 530:
    case 531:
    case 532:
    case 533:
    case 534:
    case 535:
    case 536:
    case 537:
    case 538:
    case 539:
    case 540:
    case 541:
      return TYPE_MMX;

    case 390:
      return TYPE_CLD;

    case 391:
    case 392:
    case 393:
    case 394:
    case 395:
    case 396:
    case 397:
    case 398:
    case 399:
    case 400:
    case 401:
    case 402:
    case 403:
      return TYPE_STR;

    case 61:
    case 66:
    case 75:
    case 76:
      return TYPE_FXCH;

    case 14:
    case 15:
    case 16:
    case 18:
    case 19:
    case 22:
    case 27:
    case 28:
      return TYPE_FCMP;

    case 407:
    case 408:
    case 409:
    case 410:
      return TYPE_FCMOV;

    case 371:
    case 372:
    case 373:
    case 374:
    case 375:
    case 376:
    case 377:
    case 378:
    case 379:
    case 380:
    case 381:
    case 382:
    case 383:
    case 384:
    case 385:
    case 386:
    case 387:
    case 388:
    case 389:
      return TYPE_FPSPC;

    case 235:
    case 236:
    case 237:
    case 238:
    case 239:
    case 240:
    case 241:
    case 242:
    case 243:
    case 248:
    case 249:
    case 250:
    case 251:
    case 252:
    case 253:
    case 254:
    case 255:
    case 256:
      return TYPE_FSGN;

    case 95:
    case 96:
    case 97:
    case 98:
    case 99:
    case 101:
    case 103:
    case 105:
    case 107:
    case 109:
      return TYPE_FMOV;

    case 405:
    case 406:
      return TYPE_ICMOV;

    case 413:
    case 414:
    case 415:
    case 416:
      return TYPE_CALLV;

    case 331:
    case 332:
    case 333:
    case 334:
      return TYPE_CALL;

    case 31:
    case 32:
    case 38:
    case 45:
      return TYPE_POP;

    case 29:
    case 30:
    case 37:
    case 44:
      return TYPE_PUSH;

    case 316:
    case 317:
      return TYPE_SETCC;

    case 318:
    case 319:
    case 326:
    case 327:
    case 328:
    case 329:
    case 338:
      return TYPE_IBR;

    case 174:
    case 175:
    case 178:
    case 181:
    case 182:
      return TYPE_IDIV;

    case 165:
    case 166:
    case 167:
    case 168:
    case 169:
    case 170:
    case 171:
    case 172:
    case 173:
      return TYPE_IMUL;

    case 265:
    case 276:
    case 278:
    case 279:
    case 280:
    case 281:
    case 282:
    case 283:
    case 284:
    case 285:
    case 286:
    case 287:
    case 288:
    case 289:
    case 292:
    case 293:
    case 294:
    case 295:
    case 296:
    case 297:
    case 298:
    case 299:
    case 300:
    case 301:
    case 302:
    case 303:
    case 304:
    case 305:
    case 306:
    case 307:
    case 308:
    case 309:
    case 310:
    case 311:
    case 312:
    case 313:
    case 314:
    case 315:
      return TYPE_ISHIFT;

    case 131:
    case 132:
    case 133:
    case 134:
      return TYPE_LEA;

    case 50:
    case 51:
    case 53:
    case 78:
    case 81:
    case 84:
    case 87:
    case 88:
    case 89:
      return TYPE_IMOVX;

    case 36:
    case 40:
    case 41:
    case 42:
    case 47:
    case 48:
    case 55:
    case 56:
      return TYPE_IMOV;

    case 10:
    case 183:
    case 184:
    case 185:
    case 186:
    case 187:
    case 188:
      return TYPE_TEST;

    case 1:
    case 2:
    case 4:
    case 5:
    case 7:
    case 8:
    case 9:
    case 11:
    case 12:
      return TYPE_ICMP;

    case 128:
    case 129:
    case 130:
    case 153:
    case 155:
    case 156:
    case 157:
    case 158:
    case 159:
    case 160:
    case 161:
    case 162:
    case 163:
    case 164:
    case 191:
    case 193:
    case 194:
    case 196:
    case 198:
    case 199:
    case 200:
    case 201:
    case 202:
    case 203:
    case 204:
    case 205:
    case 206:
    case 207:
    case 208:
    case 210:
    case 212:
    case 213:
    case 214:
    case 215:
    case 216:
    case 217:
    case 218:
    case 219:
    case 220:
    case 221:
    case 222:
    case 223:
    case 340:
    case 404:
      return TYPE_ALU;

    case 225:
    case 226:
    case 227:
    case 228:
    case 229:
    case 230:
    case 257:
    case 259:
    case 261:
      return TYPE_NEGNOT;

    case 33:
    case 34:
    case 43:
    case 49:
    case 77:
    case 79:
    case 82:
    case 195:
    case 197:
    case 209:
    case 211:
    case 258:
    case 260:
    case 262:
      return TYPE_ALU1;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 13:
    case 17:
    case 20:
    case 21:
    case 23:
    case 62:
    case 63:
    case 67:
    case 68:
    case 69:
    case 70:
    case 110:
    case 111:
    case 112:
    case 176:
    case 177:
    case 179:
    case 180:
    case 263:
    case 264:
    case 274:
    case 275:
    case 290:
    case 291:
    case 341:
    case 412:
      return TYPE_MULTI;

    case 24:
    case 25:
    case 26:
    case 57:
    case 85:
    case 86:
    case 90:
    case 91:
    case 92:
    case 93:
    case 94:
    case 113:
    case 114:
    case 127:
    case 154:
    case 189:
    case 224:
    case 231:
    case 232:
    case 233:
    case 234:
    case 244:
    case 245:
    case 246:
    case 247:
    case 320:
    case 321:
    case 322:
    case 323:
    case 324:
    case 325:
    case 335:
    case 336:
    case 337:
    case 339:
    case 342:
    case 343:
    case 344:
    case 417:
    case 418:
      return TYPE_OTHER;

    default:
      return TYPE_SSE;

    }
}

static int athlon_muldiv_unit_blockage PARAMS ((rtx, rtx));
static int
athlon_muldiv_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 1;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 42 /* 0x2a */;

    default:
      abort ();
    }
}

static int athlon_muldiv_unit_conflict_cost PARAMS ((rtx, rtx));
static int
athlon_muldiv_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 1;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 42 /* 0x2a */;

    default:
      abort ();
    }
}

static int athlon_ieu_unit_blockage PARAMS ((rtx, rtx));
static int
athlon_ieu_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
      casenum = 1;
      break;

    case 330:
      if (get_attr_type (insn) == TYPE_IBR)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 271:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) || ((which_alternative == 2) || (get_attr_type (insn) == TYPE_ISHIFT)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if ((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) || ((which_alternative != 0) || (get_attr_type (insn) == TYPE_ISHIFT)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 2;
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) || ((which_alternative == 3) || (incdec_operand (operands[2], QImode))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) || ((which_alternative == 2) || (incdec_operand (operands[2], HImode))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 135:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) || (((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode))) || (get_attr_type (insn) == TYPE_INCDEC)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 54:
    case 52:
      if ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_IMOVX))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 46:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 39:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_IMOV) || (((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 35:
      if ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 416:
    case 415:
    case 414:
    case 413:
    case 411:
    case 406:
    case 405:
    case 404:
    case 390:
    case 340:
    case 338:
    case 334:
    case 333:
    case 332:
    case 331:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
    case 317:
    case 316:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 277:
    case 276:
    case 265:
    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 211:
    case 210:
    case 209:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 197:
    case 196:
    case 195:
    case 194:
    case 193:
    case 192:
    case 191:
    case 190:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
    case 139:
    case 138:
    case 137:
    case 136:
    case 134:
    case 133:
    case 132:
    case 131:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 83:
    case 82:
    case 81:
    case 80:
    case 79:
    case 78:
    case 77:
    case 56:
    case 55:
    case 53:
    case 51:
    case 50:
    case 49:
    case 48:
    case 47:
    case 45:
    case 44:
    case 43:
    case 42:
    case 41:
    case 40:
    case 38:
    case 37:
    case 36:
    case 34:
    case 33:
    case 32:
    case 31:
    case 30:
    case 29:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 3;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 15 /* 0xf */;

    case 2:
      return 1;

    case 3:
      return 1;

    default:
      abort ();
    }
}

static int athlon_ieu_unit_conflict_cost PARAMS ((rtx, rtx));
static int
athlon_ieu_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
      casenum = 1;
      break;

    case 330:
      if (get_attr_type (insn) == TYPE_IBR)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 271:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) || ((which_alternative == 2) || (get_attr_type (insn) == TYPE_ISHIFT)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if ((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) || ((which_alternative != 0) || (get_attr_type (insn) == TYPE_ISHIFT)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 2;
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) || ((which_alternative == 3) || (incdec_operand (operands[2], QImode))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) || ((which_alternative == 2) || (incdec_operand (operands[2], HImode))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 135:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) || (((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode))) || (get_attr_type (insn) == TYPE_INCDEC)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 59:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 54:
    case 52:
      if ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_IMOVX))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 46:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 39:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_IMOV) || (((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 35:
      if ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 416:
    case 415:
    case 414:
    case 413:
    case 411:
    case 406:
    case 405:
    case 404:
    case 390:
    case 340:
    case 338:
    case 334:
    case 333:
    case 332:
    case 331:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
    case 317:
    case 316:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 277:
    case 276:
    case 265:
    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 211:
    case 210:
    case 209:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 197:
    case 196:
    case 195:
    case 194:
    case 193:
    case 192:
    case 191:
    case 190:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
    case 139:
    case 138:
    case 137:
    case 136:
    case 134:
    case 133:
    case 132:
    case 131:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 83:
    case 82:
    case 81:
    case 80:
    case 79:
    case 78:
    case 77:
    case 56:
    case 55:
    case 53:
    case 51:
    case 50:
    case 49:
    case 48:
    case 47:
    case 45:
    case 44:
    case 43:
    case 42:
    case 41:
    case 40:
    case 38:
    case 37:
    case 36:
    case 34:
    case 33:
    case 32:
    case 31:
    case 30:
    case 29:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 3;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 15 /* 0xf */;

    case 2:
      return 1;

    case 3:
      return 1;

    default:
      abort ();
    }
}

static int athlon_vectordec_unit_blockage PARAMS ((rtx, rtx));
static int
athlon_vectordec_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 330:
      if (get_attr_type (insn) == TYPE_MULTI)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 0) || ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || ((which_alternative == 4) || (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 3) || (which_alternative == 4))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 59:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 58:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || (which_alternative == 1))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 418:
    case 417:
    case 412:
    case 410:
    case 409:
    case 408:
    case 407:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 334:
    case 333:
    case 332:
    case 331:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 265:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 182:
    case 181:
    case 180:
    case 179:
    case 178:
    case 177:
    case 176:
    case 175:
    case 174:
    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
    case 154:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 45:
    case 38:
    case 36:
    case 32:
    case 31:
    case 28:
    case 27:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
      casenum = 0;
      break;

    default:
      casenum = 1;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      switch (recog_memoized (insn))
	{
        case 330:
	  if (! (get_attr_type (insn) == TYPE_MULTI))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }

        case 126:
        case 125:
        case 124:
        case 123:
        case 122:
        case 121:
	  extract_constrain_insn_cached (insn);
	  if ((which_alternative == 0) && ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }

        case 120:
        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
        case 108:
        case 106:
        case 104:
        case 102:
        case 100:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 0)
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }

        case 99:
        case 98:
        case 97:
        case 96:
        case 95:
	  extract_constrain_insn_cached (insn);
	  if ((which_alternative != 1) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE))))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }

        case 74:
        case 73:
        case 72:
        case 71:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 3) && (which_alternative != 4)) && (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) || ((! (get_attr_memory (insn) == MEMORY_LOAD)) && (! (get_attr_memory (insn) == MEMORY_STORE)))))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }

        case 65:
        case 64:
	  extract_constrain_insn_cached (insn);
	  if ((which_alternative != 3) && (which_alternative != 4))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }

        case 59:
	  extract_constrain_insn_cached (insn);
	  if ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode))))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }

        case 58:
	  extract_constrain_insn_cached (insn);
	  if ((which_alternative != 0) && (which_alternative != 1))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }

        case 44:
        case 37:
        case 30:
        case 29:
	  extract_insn_cached (insn);
	  if (! (memory_operand (operands[1], VOIDmode)))
	    {
	      return 0;
	    }
	  else
	    {
	      return 1;
	    }

        case -1:
	  if (GET_CODE (PATTERN (insn)) != ASM_INPUT
	      && asm_noperands (PATTERN (insn)) < 0)
	    fatal_insn_not_found (insn);
        case 418:
        case 417:
        case 412:
        case 410:
        case 409:
        case 408:
        case 407:
        case 403:
        case 402:
        case 401:
        case 400:
        case 399:
        case 398:
        case 397:
        case 396:
        case 395:
        case 394:
        case 393:
        case 392:
        case 391:
        case 390:
        case 389:
        case 388:
        case 387:
        case 386:
        case 385:
        case 384:
        case 383:
        case 382:
        case 381:
        case 380:
        case 344:
        case 343:
        case 342:
        case 341:
        case 339:
        case 337:
        case 336:
        case 335:
        case 334:
        case 333:
        case 332:
        case 331:
        case 325:
        case 324:
        case 323:
        case 322:
        case 321:
        case 320:
        case 291:
        case 290:
        case 275:
        case 274:
        case 265:
        case 264:
        case 263:
        case 247:
        case 246:
        case 245:
        case 244:
        case 234:
        case 233:
        case 232:
        case 231:
        case 224:
        case 189:
        case 182:
        case 181:
        case 180:
        case 179:
        case 178:
        case 177:
        case 176:
        case 175:
        case 174:
        case 173:
        case 172:
        case 171:
        case 170:
        case 169:
        case 168:
        case 167:
        case 166:
        case 165:
        case 154:
        case 127:
        case 114:
        case 113:
        case 112:
        case 111:
        case 110:
        case 94:
        case 93:
        case 92:
        case 91:
        case 90:
        case 86:
        case 85:
        case 70:
        case 69:
        case 68:
        case 67:
        case 63:
        case 62:
        case 57:
        case 45:
        case 38:
        case 36:
        case 32:
        case 31:
        case 28:
        case 27:
        case 26:
        case 25:
        case 24:
        case 23:
        case 21:
        case 20:
        case 17:
        case 13:
	  return 1;

        default:
	  return 0;

      }

    default:
      abort ();
    }
}

static int k6_fpu_unit_blockage PARAMS ((rtx, rtx));
static int
k6_fpu_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 0;
        }
      else if (mult_operator (operands[3], TFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 0;
        }
      else if (mult_operator (operands[3], XFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 0;
        }
      else if (mult_operator (operands[3], DFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 0;
        }
      else if (mult_operator (operands[3], SFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 348:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], TFmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 347:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], XFmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 346:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], DFmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 345:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], SFmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 2;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 2;

    case 1:
      return 2;

    case 2:
      return 56 /* 0x38 */;

    default:
      abort ();
    }
}

static int k6_fpu_unit_conflict_cost PARAMS ((rtx, rtx));
static int
k6_fpu_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 0;
        }
      else if (mult_operator (operands[3], TFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 0;
        }
      else if (mult_operator (operands[3], XFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 0;
        }
      else if (mult_operator (operands[3], DFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 0;
        }
      else if (mult_operator (operands[3], SFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 348:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], TFmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 347:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], XFmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 346:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], DFmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 345:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], SFmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 2;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 2;

    case 1:
      return 2;

    case 2:
      return 56 /* 0x38 */;

    default:
      abort ();
    }
}

static int k6_store_unit_blockage PARAMS ((rtx, rtx));
static int
k6_store_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (! (const0_operand (operands[2], SImode))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
      casenum = 1;
      break;

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 3)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 271:
    case 140:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 135:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 134:
    case 133:
    case 132:
    case 131:
      casenum = 0;
      break;

    case 35:
      if (get_attr_type (insn) == TYPE_LEA)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 2;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 10 /* 0xa */;

    case 2:
      return 1;

    default:
      abort ();
    }
}

static int k6_store_unit_conflict_cost PARAMS ((rtx, rtx));
static int
k6_store_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (! (const0_operand (operands[2], SImode))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
      casenum = 1;
      break;

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 3)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 271:
    case 140:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 135:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 134:
    case 133:
    case 132:
    case 131:
      casenum = 0;
      break;

    case 35:
      if (get_attr_type (insn) == TYPE_LEA)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 2;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 10 /* 0xa */;

    case 2:
      return 1;

    default:
      abort ();
    }
}

static int k6_load_unit_blockage PARAMS ((rtx, rtx));
static int
k6_load_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if (! (constant_call_address_operand (operands[1], VOIDmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if (! (constant_call_address_operand (operands[0], VOIDmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
      extract_insn_cached (insn);
      if (memory_operand (operands[0], VOIDmode))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 59:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (memory_operand (operands[1], VOIDmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 317:
    case 316:
    case 45:
    case 38:
    case 32:
    case 31:
      casenum = 0;
      break;

    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 44:
    case 43:
    case 37:
    case 34:
    case 33:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      if (get_attr_memory (insn) == MEMORY_LOAD)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 542:
    case 539:
    case 418:
    case 417:
    case 412:
    case 410:
    case 409:
    case 408:
    case 407:
    case 404:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 134:
    case 133:
    case 132:
    case 131:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
      casenum = 1;
      break;

    default:
      casenum = 0;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 10 /* 0xa */;

    default:
      abort ();
    }
}

static int k6_load_unit_conflict_cost PARAMS ((rtx, rtx));
static int
k6_load_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if (! (constant_call_address_operand (operands[1], VOIDmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if (! (constant_call_address_operand (operands[0], VOIDmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
      extract_insn_cached (insn);
      if (memory_operand (operands[0], VOIDmode))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 59:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (memory_operand (operands[1], VOIDmode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
    case 317:
    case 316:
    case 45:
    case 38:
    case 32:
    case 31:
      casenum = 0;
      break;

    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 44:
    case 43:
    case 37:
    case 34:
    case 33:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      if (get_attr_memory (insn) == MEMORY_LOAD)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 1;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    case 542:
    case 539:
    case 418:
    case 417:
    case 412:
    case 410:
    case 409:
    case 408:
    case 407:
    case 404:
    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 390:
    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
    case 344:
    case 343:
    case 342:
    case 341:
    case 339:
    case 337:
    case 336:
    case 335:
    case 325:
    case 324:
    case 323:
    case 322:
    case 321:
    case 320:
    case 291:
    case 290:
    case 275:
    case 274:
    case 264:
    case 263:
    case 247:
    case 246:
    case 245:
    case 244:
    case 234:
    case 233:
    case 232:
    case 231:
    case 224:
    case 189:
    case 180:
    case 179:
    case 177:
    case 176:
    case 154:
    case 134:
    case 133:
    case 132:
    case 131:
    case 127:
    case 114:
    case 113:
    case 112:
    case 111:
    case 110:
    case 94:
    case 93:
    case 92:
    case 91:
    case 90:
    case 86:
    case 85:
    case 70:
    case 69:
    case 68:
    case 67:
    case 63:
    case 62:
    case 57:
    case 26:
    case 25:
    case 24:
    case 23:
    case 21:
    case 20:
    case 17:
    case 13:
      casenum = 1;
      break;

    default:
      casenum = 0;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 10 /* 0xa */;

    default:
      abort ();
    }
}

static int k6_alu_unit_blockage PARAMS ((rtx, rtx));
static int
k6_alu_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 1) || (! (const0_operand (operands[2], SImode))))
        {
	  casenum = 0;
        }
      else if (get_attr_memory (insn) == MEMORY_NONE)
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 271:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ISHIFT) || ((get_attr_type (insn) == TYPE_ALU) || (which_alternative == 2)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if ((get_attr_type (insn) == TYPE_ISHIFT) || (get_attr_type (insn) == TYPE_ALU))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ISHIFT) || ((which_alternative != 0) || (get_attr_type (insn) == TYPE_ALU)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 2;
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) || ((incdec_operand (operands[2], QImode)) || (which_alternative == 3)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) || ((incdec_operand (operands[2], HImode)) || (which_alternative == 2)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 135:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) || ((get_attr_type (insn) == TYPE_INCDEC) || ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode)))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 54:
    case 52:
      if (get_attr_type (insn) == TYPE_IMOVX)
        {
	  casenum = 0;
        }
      else if ((get_attr_type (insn) == TYPE_IMOV) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 46:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))
        {
	  casenum = 0;
        }
      else if ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 39:
      extract_constrain_insn_cached (insn);
      if (((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4))))))
        {
	  casenum = 0;
        }
      else if ((get_attr_type (insn) == TYPE_IMOV) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 56:
    case 55:
    case 48:
    case 47:
    case 42:
    case 41:
    case 40:
    case 36:
      if (get_attr_memory (insn) == MEMORY_NONE)
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 35:
      if (get_attr_type (insn) == TYPE_LEA)
        {
	  casenum = 0;
        }
      else if ((get_attr_type (insn) == TYPE_IMOV) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 404:
    case 340:
    case 317:
    case 316:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 277:
    case 276:
    case 265:
    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 211:
    case 210:
    case 209:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 197:
    case 196:
    case 195:
    case 194:
    case 193:
    case 192:
    case 191:
    case 190:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
    case 139:
    case 138:
    case 137:
    case 136:
    case 134:
    case 133:
    case 132:
    case 131:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 83:
    case 82:
    case 81:
    case 80:
    case 79:
    case 78:
    case 77:
    case 53:
    case 51:
    case 50:
    case 49:
    case 43:
    case 34:
    case 33:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 3;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 1;

    case 2:
      return 2;

    case 3:
      return 17 /* 0x11 */;

    default:
      abort ();
    }
}

static int k6_alu_unit_conflict_cost PARAMS ((rtx, rtx));
static int
k6_alu_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 1) || (! (const0_operand (operands[2], SImode))))
        {
	  casenum = 0;
        }
      else if (get_attr_memory (insn) == MEMORY_NONE)
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 271:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ISHIFT) || ((get_attr_type (insn) == TYPE_ALU) || (which_alternative == 2)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if ((get_attr_type (insn) == TYPE_ISHIFT) || (get_attr_type (insn) == TYPE_ALU))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ISHIFT) || ((which_alternative != 0) || (get_attr_type (insn) == TYPE_ALU)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 2;
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) || ((incdec_operand (operands[2], QImode)) || (which_alternative == 3)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) || ((incdec_operand (operands[2], HImode)) || (which_alternative == 2)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 135:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ALU) || ((get_attr_type (insn) == TYPE_INCDEC) || ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode)))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2))) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 54:
    case 52:
      if (get_attr_type (insn) == TYPE_IMOVX)
        {
	  casenum = 0;
        }
      else if ((get_attr_type (insn) == TYPE_IMOV) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 46:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))
        {
	  casenum = 0;
        }
      else if ((((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2)))))) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 39:
      extract_constrain_insn_cached (insn);
      if (((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4))))))
        {
	  casenum = 0;
        }
      else if ((get_attr_type (insn) == TYPE_IMOV) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 56:
    case 55:
    case 48:
    case 47:
    case 42:
    case 41:
    case 40:
    case 36:
      if (get_attr_memory (insn) == MEMORY_NONE)
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 35:
      if (get_attr_type (insn) == TYPE_LEA)
        {
	  casenum = 0;
        }
      else if ((get_attr_type (insn) == TYPE_IMOV) && (get_attr_memory (insn) == MEMORY_NONE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 404:
    case 340:
    case 317:
    case 316:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 277:
    case 276:
    case 265:
    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 211:
    case 210:
    case 209:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 197:
    case 196:
    case 195:
    case 194:
    case 193:
    case 192:
    case 191:
    case 190:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
    case 139:
    case 138:
    case 137:
    case 136:
    case 134:
    case 133:
    case 132:
    case 131:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 83:
    case 82:
    case 81:
    case 80:
    case 79:
    case 78:
    case 77:
    case 53:
    case 51:
    case 50:
    case 49:
    case 43:
    case 34:
    case 33:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 3;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 1;

    case 2:
      return 2;

    case 3:
      return 17 /* 0x11 */;

    default:
      abort ();
    }
}

static int k6_alux_unit_blockage PARAMS ((rtx, rtx));
static int
k6_alux_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else if (general_operand (operands[0], QImode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_ISHIFT)
        {
	  casenum = 0;
        }
      else if (get_attr_type (insn) == TYPE_ALU)
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 390:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
      casenum = 0;
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 2;
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 3) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 2) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 135:
      extract_insn_cached (insn);
      if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_INCDEC)) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else if (general_operand (operands[0], QImode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 54:
    case 52:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_IMOVX) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 46:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 39:
      extract_constrain_insn_cached (insn);
      if ((((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      casenum = 0;
      break;

    case 404:
    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 192:
    case 191:
    case 190:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
    case 139:
    case 138:
    case 137:
    case 136:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 81:
    case 78:
    case 53:
    case 51:
    case 50:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      extract_insn_cached (insn);
      if (general_operand (operands[0], QImode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 3;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 1;

    case 2:
      return 2;

    case 3:
      return 17 /* 0x11 */;

    default:
      abort ();
    }
}

static int k6_alux_unit_conflict_cost PARAMS ((rtx, rtx));
static int
k6_alux_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else if (general_operand (operands[0], QImode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_ISHIFT)
        {
	  casenum = 0;
        }
      else if (get_attr_type (insn) == TYPE_ALU)
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 390:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
      casenum = 0;
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 2;
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 3) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 2) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 135:
      extract_insn_cached (insn);
      if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_INCDEC)) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else if (general_operand (operands[0], QImode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 54:
    case 52:
      extract_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_IMOVX) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 46:
      extract_constrain_insn_cached (insn);
      if ((((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 39:
      extract_constrain_insn_cached (insn);
      if ((((((which_alternative != 0) && (which_alternative != 1)) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_HIMODE_MATH) == (0))))) && (((which_alternative != 2) && ((which_alternative != 3) && (which_alternative != 4))) || (! (aligned_operand (operands[1], HImode))))) && (((TARGET_MOVX) != (0)) && ((which_alternative == 0) || ((which_alternative == 1) || ((which_alternative == 3) || (which_alternative == 4)))))) && (general_operand (operands[0], QImode)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 262:
    case 261:
    case 260:
    case 259:
    case 258:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      casenum = 0;
      break;

    case 404:
    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 192:
    case 191:
    case 190:
    case 188:
    case 187:
    case 186:
    case 185:
    case 184:
    case 183:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 155:
    case 153:
    case 152:
    case 151:
    case 150:
    case 149:
    case 148:
    case 147:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
    case 139:
    case 138:
    case 137:
    case 136:
    case 130:
    case 129:
    case 128:
    case 89:
    case 88:
    case 87:
    case 84:
    case 81:
    case 78:
    case 53:
    case 51:
    case 50:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      extract_insn_cached (insn);
      if (general_operand (operands[0], QImode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 3;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 1;

    case 2:
      return 2;

    case 3:
      return 17 /* 0x11 */;

    default:
      abort ();
    }
}

static int ppro_p0_unit_blockage PARAMS ((rtx, rtx));
static int
ppro_p0_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (! (const0_operand (operands[2], SImode))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 410:
    case 409:
    case 408:
    case 407:
      casenum = 4;
      break;

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 3;
        }
      else if (mult_operator (operands[3], TFmode))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 3;
        }
      else if (mult_operator (operands[3], XFmode))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 3;
        }
      else if (mult_operator (operands[3], DFmode))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 3;
        }
      else if (mult_operator (operands[3], SFmode))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 348:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], TFmode)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 7;
        }
      break;

    case 347:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], XFmode)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 7;
        }
      break;

    case 346:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], DFmode)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 7;
        }
      break;

    case 345:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], SFmode)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 7;
        }
      break;

    case 330:
      if (get_attr_type (insn) == TYPE_IBR)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 271:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ISHIFT) || (which_alternative == 2))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if (get_attr_type (insn) == TYPE_ISHIFT)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 0) || (get_attr_type (insn) == TYPE_ISHIFT))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
      casenum = 3;
      break;

    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
      casenum = 2;
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 1;
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 3)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 135:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 390:
    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
    case 134:
    case 133:
    case 132:
    case 131:
      casenum = 0;
      break;

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  casenum = 6;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      casenum = 6;
      break;

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  casenum = 6;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 35:
      if (get_attr_type (insn) == TYPE_LEA)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      casenum = 5;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 8;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 1;

    case 2:
      return 17 /* 0x11 */;

    case 3:
      return 1;

    case 4:
      return 1;

    case 5:
      return 1;

    case 6:
      return 1;

    case 7:
      return 1;

    case 8:
      return 1;

    default:
      abort ();
    }
}

static int ppro_p0_unit_conflict_cost PARAMS ((rtx, rtx));
static int
ppro_p0_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (! (const0_operand (operands[2], SImode))))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 410:
    case 409:
    case 408:
    case 407:
      casenum = 4;
      break;

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 3;
        }
      else if (mult_operator (operands[3], TFmode))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 3;
        }
      else if (mult_operator (operands[3], XFmode))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 3;
        }
      else if (mult_operator (operands[3], DFmode))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_FOP)
        {
	  casenum = 3;
        }
      else if (mult_operator (operands[3], SFmode))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 348:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], TFmode)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 7;
        }
      break;

    case 347:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], XFmode)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 7;
        }
      break;

    case 346:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], DFmode)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 7;
        }
      break;

    case 345:
      extract_insn_cached (insn);
      if (! (mult_operator (operands[3], SFmode)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 7;
        }
      break;

    case 330:
      if (get_attr_type (insn) == TYPE_IBR)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 271:
      extract_constrain_insn_cached (insn);
      if ((get_attr_type (insn) == TYPE_ISHIFT) || (which_alternative == 2))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 273:
    case 272:
    case 270:
    case 269:
    case 267:
      if (get_attr_type (insn) == TYPE_ISHIFT)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 268:
    case 266:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 0) || (get_attr_type (insn) == TYPE_ISHIFT))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
      casenum = 3;
      break;

    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
      casenum = 2;
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 1;
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 3)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 135:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 2) || (pic_symbolic_operand (operands[2], SImode)))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 390:
    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
    case 276:
    case 265:
    case 134:
    case 133:
    case 132:
    case 131:
      casenum = 0;
      break;

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  casenum = 6;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      casenum = 6;
      break;

    case 74:
    case 73:
    case 72:
    case 71:
    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2)))
        {
	  casenum = 6;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 35:
      if (get_attr_type (insn) == TYPE_LEA)
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      casenum = 5;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 8;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 1;

    case 1:
      return 1;

    case 2:
      return 17 /* 0x11 */;

    case 3:
      return 1;

    case 4:
      return 1;

    case 5:
      return 1;

    case 6:
      return 1;

    case 7:
      return 1;

    case 8:
      return 1;

    default:
      abort ();
    }
}

static int pent_uv_unit_blockage PARAMS ((rtx, rtx));
static int
pent_uv_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((which_alternative == 0) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], QImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((! (incdec_operand (operands[2], QImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], SImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((! (incdec_operand (operands[2], SImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 135:
      if ((get_attr_type (insn) == TYPE_ALU) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 153:
    case 130:
    case 129:
      if ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 155:
    case 128:
      if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 0;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 262:
    case 260:
    case 258:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 2;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 3;

    case 1:
      return 2;

    case 2:
      return 1;

    default:
      abort ();
    }
}

static int pent_uv_unit_conflict_cost PARAMS ((rtx, rtx));
static int
pent_uv_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((which_alternative == 0) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], QImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((! (incdec_operand (operands[2], QImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], SImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((! (incdec_operand (operands[2], SImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 135:
      if ((get_attr_type (insn) == TYPE_ALU) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 153:
    case 130:
    case 129:
      if ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 155:
    case 128:
      if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 0;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 262:
    case 260:
    case 258:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 2;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 3;

    case 1:
      return 2;

    case 2:
      return 1;

    default:
      abort ();
    }
}

static int pent_u_unit_blockage PARAMS ((rtx, rtx));
static int
pent_u_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 192:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 218:
    case 217:
    case 216:
    case 207:
    case 206:
    case 205:
    case 193:
    case 161:
    case 160:
    case 159:
      if ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 145:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 155:
    case 128:
      if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 0;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 80:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 260:
    case 79:
    case 43:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 2;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 3;

    case 1:
      return 2;

    case 2:
      return 1;

    default:
      abort ();
    }
}

static int pent_u_unit_conflict_cost PARAMS ((rtx, rtx));
static int
pent_u_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 192:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if (((which_alternative == 0) || (which_alternative == 1)) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 218:
    case 217:
    case 216:
    case 207:
    case 206:
    case 205:
    case 193:
    case 161:
    case 160:
    case 159:
      if ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 145:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 0;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 155:
    case 128:
      if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 0;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 80:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 260:
    case 79:
    case 43:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 0;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 2;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 3;

    case 1:
      return 2;

    case 2:
      return 1;

    default:
      abort ();
    }
}

static int fpu_unit_blockage PARAMS ((rtx, rtx));
static int
fpu_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 410:
    case 409:
    case 408:
    case 407:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 10 /* 0xa */;
        }
      break;

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], TFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 6;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], TFmode)))
        {
	  casenum = 9;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], XFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 6;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], XFmode)))
        {
	  casenum = 9;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], DFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 6;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], DFmode)))
        {
	  casenum = 9;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], SFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 6;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], SFmode)))
        {
	  casenum = 9;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 348:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (! (mult_operator (operands[3], TFmode))))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], TFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (mult_operator (operands[3], TFmode))))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], TFmode)))
        {
	  casenum = 9;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 347:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (! (mult_operator (operands[3], XFmode))))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], XFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (mult_operator (operands[3], XFmode))))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], XFmode)))
        {
	  casenum = 9;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 346:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (! (mult_operator (operands[3], DFmode))))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], DFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (mult_operator (operands[3], DFmode))))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], DFmode)))
        {
	  casenum = 9;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 345:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (! (mult_operator (operands[3], SFmode))))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], SFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (mult_operator (operands[3], SFmode))))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], SFmode)))
        {
	  casenum = 9;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 0;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))
        {
	  casenum = 2;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (which_alternative == 0))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD)))
        {
	  casenum = 2;
        }
      else if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))
        {
	  casenum = 2;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (which_alternative == 0))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 0;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD)))
        {
	  casenum = 2;
        }
      else if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 0;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))
        {
	  casenum = 2;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 76:
    case 75:
    case 66:
    case 61:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))
        {
	  casenum = 2;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 11 /* 0xb */;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 3;

    case 1:
      return 2;

    case 2:
      return 1;

    case 3:
      return 1;

    case 4:
      return 1;

    case 5:
      return 1;

    case 6:
      return 37 /* 0x25 */;

    case 7:
      return 68 /* 0x44 */;

    case 8:
      return 1;

    case 9:
      return 2;

    case 10:
      return 56 /* 0x38 */;

    case 11:
      return 1;

    default:
      abort ();
    }
}

static int fpu_unit_conflict_cost PARAMS ((rtx, rtx));
static int
fpu_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 410:
    case 409:
    case 408:
    case 407:
      if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 389:
    case 388:
    case 387:
    case 386:
    case 385:
    case 384:
    case 383:
    case 382:
    case 381:
    case 380:
    case 379:
    case 378:
    case 377:
    case 376:
    case 375:
    case 374:
    case 373:
    case 372:
    case 371:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 10 /* 0xa */;
        }
      break;

    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], TFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 6;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], TFmode)))
        {
	  casenum = 9;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], XFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 6;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], XFmode)))
        {
	  casenum = 9;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], DFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 6;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], DFmode)))
        {
	  casenum = 9;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], SFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 6;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FOP))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], SFmode)))
        {
	  casenum = 9;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (get_attr_type (insn) == TYPE_FDIV))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 348:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (! (mult_operator (operands[3], TFmode))))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], TFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (mult_operator (operands[3], TFmode))))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], TFmode)))
        {
	  casenum = 9;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 347:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (! (mult_operator (operands[3], XFmode))))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], XFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (mult_operator (operands[3], XFmode))))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], XFmode)))
        {
	  casenum = 9;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 346:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (! (mult_operator (operands[3], DFmode))))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], DFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (mult_operator (operands[3], DFmode))))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], DFmode)))
        {
	  casenum = 9;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 345:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (! (mult_operator (operands[3], SFmode))))
        {
	  casenum = 4;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (mult_operator (operands[3], SFmode)))
        {
	  casenum = 5;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (! (mult_operator (operands[3], SFmode))))
        {
	  casenum = 8;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (mult_operator (operands[3], SFmode)))
        {
	  casenum = 9;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 0;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))
        {
	  casenum = 2;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (which_alternative == 0))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
      extract_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD)))
        {
	  casenum = 2;
        }
      else if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))
        {
	  casenum = 2;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && (which_alternative == 0))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 0;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD)))
        {
	  casenum = 2;
        }
      else if (((ix86_cpu) == (CPU_PENTIUMPRO)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 0;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))
        {
	  casenum = 2;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 76:
    case 75:
    case 66:
    case 61:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 65:
    case 64:
    case 60:
      extract_constrain_insn_cached (insn);
      if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 1;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUM))) && (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_NONE) || (get_attr_memory (insn) == MEMORY_LOAD))))
        {
	  casenum = 2;
        }
      else if ((((ix86_cpu) == (CPU_PENTIUMPRO))) && ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 256:
    case 255:
    case 254:
    case 253:
    case 252:
    case 251:
    case 250:
    case 249:
    case 248:
    case 243:
    case 242:
    case 241:
    case 240:
    case 239:
    case 238:
    case 237:
    case 236:
    case 235:
    case 28:
    case 27:
    case 22:
    case 19:
    case 18:
    case 16:
    case 15:
    case 14:
      if (((ix86_cpu) == (CPU_PENTIUM)))
        {
	  casenum = 3;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 11 /* 0xb */;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 3;

    case 1:
      return 2;

    case 2:
      return 1;

    case 3:
      return 1;

    case 4:
      return 1;

    case 5:
      return 1;

    case 6:
      return 37 /* 0x25 */;

    case 7:
      return 68 /* 0x44 */;

    case 8:
      return 1;

    case 9:
      return 2;

    case 10:
      return 56 /* 0x38 */;

    case 11:
      return 1;

    default:
      abort ();
    }
}

static int pent_mul_unit_blockage PARAMS ((rtx, rtx));
static int
pent_mul_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], TFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], XFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], DFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], SFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 348:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], TFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 347:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], XFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 346:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], DFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 345:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], SFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 3;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 11 /* 0xb */;

    case 1:
      return 2;

    case 2:
      return 39 /* 0x27 */;

    case 3:
      return 70 /* 0x46 */;

    default:
      abort ();
    }
}

static int pent_mul_unit_conflict_cost PARAMS ((rtx, rtx));
static int
pent_mul_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 370:
    case 368:
    case 366:
    case 364:
    case 362:
    case 360:
    case 358:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], TFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 369:
    case 367:
    case 365:
    case 363:
    case 361:
    case 359:
    case 357:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], XFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 356:
    case 355:
    case 354:
    case 353:
    case 352:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], DFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 351:
    case 350:
    case 349:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], SFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 2;
        }
      break;

    case 348:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], TFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 347:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], XFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 346:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], DFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 345:
      extract_insn_cached (insn);
      if (mult_operator (operands[3], SFmode))
        {
	  casenum = 1;
        }
      else
        {
	  casenum = 3;
        }
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 0;
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 3;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 11 /* 0xb */;

    case 1:
      return 2;

    case 2:
      return 39 /* 0x27 */;

    case 3:
      return 70 /* 0x46 */;

    default:
      abort ();
    }
}

static int pent_np_unit_blockage PARAMS ((rtx, rtx));
static int
pent_np_unit_blockage (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if (! (constant_call_address_operand (operands[1], VOIDmode)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((which_alternative == 0) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if ((which_alternative == 0) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
      casenum = 1;
      break;

    case 390:
      casenum = 5;
      break;

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if (! (constant_call_address_operand (operands[0], VOIDmode)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 330:
      if (! (get_attr_type (insn) == TYPE_IBR))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 6;
        }
      else if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 7;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode))))
        {
	  casenum = 8;
        }
      else if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((which_alternative == 1) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode)))))
        {
	  casenum = 8;
        }
      else if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
        {
	  casenum = 8;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 276:
    case 265:
      if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 6;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 261:
    case 259:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 6;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || (which_alternative == 1)) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if (((which_alternative == 0) || (which_alternative == 1)) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1)))
        {
	  casenum = 8;
        }
      else if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 185:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 0) && (which_alternative != 2))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 184:
    case 183:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
      casenum = 2;
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 0;
      break;

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], QImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((! (incdec_operand (operands[2], QImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if ((! (incdec_operand (operands[2], QImode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((! (incdec_operand (operands[2], QImode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
        {
	  casenum = 8;
        }
      else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], HImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
        {
	  casenum = 8;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], SImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((! (incdec_operand (operands[2], SImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if ((! (incdec_operand (operands[2], SImode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((! (incdec_operand (operands[2], SImode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 135:
      if ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
        {
	  casenum = 8;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 404:
    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
    case 134:
    case 133:
    case 132:
    case 131:
      casenum = 11 /* 0xb */;
      break;

    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 153:
    case 130:
    case 129:
      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 6;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 155:
    case 128:
      if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 3;
        }
      else if ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
      extract_insn_cached (insn);
      if ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 3;
        }
      else if ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  casenum = 8;
        }
      else if ((which_alternative == 1) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 3;
        }
      else if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 59:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 46:
      extract_constrain_insn_cached (insn);
      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 54:
    case 52:
    case 39:
      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 35:
      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA))))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 262:
    case 260:
    case 258:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 9;
        }
      else if (get_attr_memory (insn) == MEMORY_STORE)
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 45:
    case 38:
    case 32:
    case 31:
      extract_insn_cached (insn);
      if (memory_operand (operands[0], VOIDmode))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 188:
    case 187:
    case 56:
    case 55:
    case 48:
    case 42:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 8;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 11 /* 0xb */;

    case 1:
      return 12 /* 0xc */;

    case 2:
      return 46 /* 0x2e */;

    case 3:
      return 3;

    case 4:
      return 2;

    case 5:
      return 2;

    case 6:
      return 3;

    case 7:
      return 2;

    case 8:
      return 1;

    case 9:
      switch (recog_memoized (insn))
	{
        case 416:
        case 415:
        case 414:
        case 413:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[1], VOIDmode)))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 334:
        case 333:
        case 332:
        case 331:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[0], VOIDmode)))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 330:
	  if (! (get_attr_type (insn) == TYPE_IBR))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 315:
        case 314:
        case 313:
        case 312:
        case 311:
        case 310:
        case 309:
        case 308:
        case 307:
        case 306:
        case 305:
        case 304:
        case 303:
        case 302:
        case 301:
        case 300:
        case 299:
        case 298:
        case 297:
        case 296:
        case 295:
        case 294:
        case 293:
        case 292:
        case 289:
        case 288:
        case 287:
        case 286:
        case 285:
        case 284:
        case 283:
        case 282:
        case 281:
        case 280:
        case 279:
        case 278:
	  extract_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode))))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 277:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode)))))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 192:
        case 190:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 0) || (which_alternative == 1))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1)))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 185:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 0) && (which_alternative != 2)) || ((which_alternative == 0) || (which_alternative == 2)))
	    {
	      if ((which_alternative != 0) && (which_alternative != 2))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 184:
        case 183:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 1)
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 273:
        case 272:
        case 271:
        case 270:
        case 269:
        case 268:
        case 267:
        case 266:
        case 146:
        case 140:
        case 135:
	  if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 83:
        case 80:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 0)
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 60:
	  extract_constrain_insn_cached (insn);
	  if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2)))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 59:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 1) || (memory_operand (operands[1], VOIDmode))) || ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode)))))
	    {
	      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 46:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 54:
        case 52:
        case 39:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV)))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 35:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA))))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 404:
        case 338:
        case 329:
        case 328:
        case 327:
        case 326:
        case 319:
        case 318:
        case 262:
        case 260:
        case 258:
        case 211:
        case 209:
        case 197:
        case 195:
        case 155:
        case 134:
        case 133:
        case 132:
        case 131:
        case 128:
        case 82:
        case 79:
        case 77:
        case 49:
        case 43:
        case 34:
        case 33:
	  return 0;

        case 45:
        case 38:
        case 32:
        case 31:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[0], VOIDmode))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 44:
        case 37:
        case 30:
        case 29:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 411:
        case 340:
        case 223:
        case 222:
        case 221:
        case 220:
        case 219:
        case 218:
        case 217:
        case 216:
        case 215:
        case 214:
        case 213:
        case 212:
        case 210:
        case 208:
        case 207:
        case 206:
        case 205:
        case 204:
        case 203:
        case 202:
        case 201:
        case 200:
        case 199:
        case 198:
        case 196:
        case 194:
        case 193:
        case 191:
        case 188:
        case 187:
        case 164:
        case 163:
        case 162:
        case 161:
        case 160:
        case 159:
        case 158:
        case 157:
        case 156:
        case 153:
        case 152:
        case 151:
        case 150:
        case 149:
        case 148:
        case 147:
        case 145:
        case 144:
        case 143:
        case 142:
        case 141:
        case 139:
        case 138:
        case 137:
        case 136:
        case 130:
        case 129:
        case 56:
        case 55:
        case 48:
        case 42:
        case 12:
        case 11:
        case 10:
        case 9:
        case 8:
        case 7:
        case 6:
        case 5:
        case 4:
        case 3:
        case 2:
        case 1:
        case 0:
	  if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case -1:
	  if (GET_CODE (PATTERN (insn)) != ASM_INPUT
	      && asm_noperands (PATTERN (insn)) < 0)
	    fatal_insn_not_found (insn);
        default:
	  return 3;

      }

    case 10:
      switch (recog_memoized (insn))
	{
        case 416:
        case 415:
        case 414:
        case 413:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[1], VOIDmode)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 334:
        case 333:
        case 332:
        case 331:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[0], VOIDmode)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 330:
	  if (! (get_attr_type (insn) == TYPE_IBR))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 315:
        case 314:
        case 313:
        case 312:
        case 311:
        case 310:
        case 309:
        case 308:
        case 307:
        case 306:
        case 305:
        case 304:
        case 303:
        case 302:
        case 301:
        case 300:
        case 299:
        case 298:
        case 297:
        case 296:
        case 295:
        case 294:
        case 293:
        case 292:
        case 289:
        case 288:
        case 287:
        case 286:
        case 285:
        case 284:
        case 283:
        case 282:
        case 281:
        case 280:
        case 279:
        case 278:
	  extract_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode))))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 277:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode)))))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 192:
        case 190:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 0) || (which_alternative == 1))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 185:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 0) && (which_alternative != 2)) || ((which_alternative == 0) || (which_alternative == 2)))
	    {
	      if ((which_alternative != 0) && (which_alternative != 2))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 184:
        case 183:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 1)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 273:
        case 272:
        case 271:
        case 270:
        case 269:
        case 268:
        case 267:
        case 266:
        case 146:
        case 140:
        case 135:
	  if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 83:
        case 80:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 0)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 60:
	  extract_constrain_insn_cached (insn);
	  if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 59:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 1) || (memory_operand (operands[1], VOIDmode))) || ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode)))))
	    {
	      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 46:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 54:
        case 52:
        case 39:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 35:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA))))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 404:
        case 338:
        case 329:
        case 328:
        case 327:
        case 326:
        case 319:
        case 318:
        case 262:
        case 260:
        case 258:
        case 211:
        case 209:
        case 197:
        case 195:
        case 155:
        case 134:
        case 133:
        case 132:
        case 131:
        case 128:
        case 82:
        case 79:
        case 77:
        case 49:
        case 43:
        case 34:
        case 33:
	  return 0;

        case 45:
        case 38:
        case 32:
        case 31:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[0], VOIDmode))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 44:
        case 37:
        case 30:
        case 29:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 411:
        case 340:
        case 223:
        case 222:
        case 221:
        case 220:
        case 219:
        case 218:
        case 217:
        case 216:
        case 215:
        case 214:
        case 213:
        case 212:
        case 210:
        case 208:
        case 207:
        case 206:
        case 205:
        case 204:
        case 203:
        case 202:
        case 201:
        case 200:
        case 199:
        case 198:
        case 196:
        case 194:
        case 193:
        case 191:
        case 188:
        case 187:
        case 164:
        case 163:
        case 162:
        case 161:
        case 160:
        case 159:
        case 158:
        case 157:
        case 156:
        case 153:
        case 152:
        case 151:
        case 150:
        case 149:
        case 148:
        case 147:
        case 145:
        case 144:
        case 143:
        case 142:
        case 141:
        case 139:
        case 138:
        case 137:
        case 136:
        case 130:
        case 129:
        case 56:
        case 55:
        case 48:
        case 42:
        case 12:
        case 11:
        case 10:
        case 9:
        case 8:
        case 7:
        case 6:
        case 5:
        case 4:
        case 3:
        case 2:
        case 1:
        case 0:
	  if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case -1:
	  if (GET_CODE (PATTERN (insn)) != ASM_INPUT
	      && asm_noperands (PATTERN (insn)) < 0)
	    fatal_insn_not_found (insn);
        default:
	  return 2;

      }

    case 11:
      switch (recog_memoized (insn))
	{
        case 416:
        case 415:
        case 414:
        case 413:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[1], VOIDmode)))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 334:
        case 333:
        case 332:
        case 331:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[0], VOIDmode)))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 330:
	  if (! (get_attr_type (insn) == TYPE_IBR))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 315:
        case 314:
        case 313:
        case 312:
        case 311:
        case 310:
        case 309:
        case 308:
        case 307:
        case 306:
        case 305:
        case 304:
        case 303:
        case 302:
        case 301:
        case 300:
        case 299:
        case 298:
        case 297:
        case 296:
        case 295:
        case 294:
        case 293:
        case 292:
        case 289:
        case 288:
        case 287:
        case 286:
        case 285:
        case 284:
        case 283:
        case 282:
        case 281:
        case 280:
        case 279:
        case 278:
	  extract_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode))))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 277:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode)))))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 192:
        case 190:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 0) || (which_alternative == 1))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1)))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 185:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 0) && (which_alternative != 2)) || ((which_alternative == 0) || (which_alternative == 2)))
	    {
	      if ((which_alternative != 0) && (which_alternative != 2))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 184:
        case 183:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 1)
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 273:
        case 272:
        case 271:
        case 270:
        case 269:
        case 268:
        case 267:
        case 266:
        case 146:
        case 140:
        case 135:
	  if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 83:
        case 80:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 0)
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 60:
	  extract_constrain_insn_cached (insn);
	  if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2)))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 59:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 1) || (memory_operand (operands[1], VOIDmode))) || ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode)))))
	    {
	      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 46:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 54:
        case 52:
        case 39:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV)))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 35:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA))))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 404:
        case 338:
        case 329:
        case 328:
        case 327:
        case 326:
        case 319:
        case 318:
        case 262:
        case 260:
        case 258:
        case 211:
        case 209:
        case 197:
        case 195:
        case 155:
        case 134:
        case 133:
        case 132:
        case 131:
        case 128:
        case 82:
        case 79:
        case 77:
        case 49:
        case 43:
        case 34:
        case 33:
	  return 0;

        case 45:
        case 38:
        case 32:
        case 31:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[0], VOIDmode))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 44:
        case 37:
        case 30:
        case 29:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 411:
        case 340:
        case 223:
        case 222:
        case 221:
        case 220:
        case 219:
        case 218:
        case 217:
        case 216:
        case 215:
        case 214:
        case 213:
        case 212:
        case 210:
        case 208:
        case 207:
        case 206:
        case 205:
        case 204:
        case 203:
        case 202:
        case 201:
        case 200:
        case 199:
        case 198:
        case 196:
        case 194:
        case 193:
        case 191:
        case 188:
        case 187:
        case 164:
        case 163:
        case 162:
        case 161:
        case 160:
        case 159:
        case 158:
        case 157:
        case 156:
        case 153:
        case 152:
        case 151:
        case 150:
        case 149:
        case 148:
        case 147:
        case 145:
        case 144:
        case 143:
        case 142:
        case 141:
        case 139:
        case 138:
        case 137:
        case 136:
        case 130:
        case 129:
        case 56:
        case 55:
        case 48:
        case 42:
        case 12:
        case 11:
        case 10:
        case 9:
        case 8:
        case 7:
        case 6:
        case 5:
        case 4:
        case 3:
        case 2:
        case 1:
        case 0:
	  if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case -1:
	  if (GET_CODE (PATTERN (insn)) != ASM_INPUT
	      && asm_noperands (PATTERN (insn)) < 0)
	    fatal_insn_not_found (insn);
        default:
	  return 1;

      }

    case 12:
      switch (recog_memoized (insn))
	{
        case 370:
        case 368:
        case 366:
        case 364:
        case 362:
        case 360:
        case 358:
	  extract_insn_cached (insn);
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], TFmode))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 369:
        case 367:
        case 365:
        case 363:
        case 361:
        case 359:
        case 357:
	  extract_insn_cached (insn);
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], XFmode))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 356:
        case 355:
        case 354:
        case 353:
        case 352:
	  extract_insn_cached (insn);
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], DFmode))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 351:
        case 350:
        case 349:
	  extract_insn_cached (insn);
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], SFmode))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 126:
        case 125:
        case 124:
        case 123:
        case 122:
        case 121:
        case 120:
        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
        case 108:
        case 106:
        case 104:
        case 102:
        case 100:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative != 0)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 74:
        case 73:
        case 72:
        case 71:
        case 65:
        case 64:
	  extract_constrain_insn_cached (insn);
	  if ((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 60:
	  extract_constrain_insn_cached (insn);
	  if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
	    {
	      if ((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 410:
        case 409:
        case 408:
        case 407:
        case 389:
        case 388:
        case 387:
        case 386:
        case 385:
        case 384:
        case 383:
        case 382:
        case 381:
        case 380:
        case 379:
        case 378:
        case 377:
        case 376:
        case 375:
        case 374:
        case 373:
        case 372:
        case 371:
        case 348:
        case 347:
        case 346:
        case 345:
        case 256:
        case 255:
        case 254:
        case 253:
        case 252:
        case 251:
        case 250:
        case 249:
        case 248:
        case 243:
        case 242:
        case 241:
        case 240:
        case 239:
        case 238:
        case 237:
        case 236:
        case 235:
        case 109:
        case 107:
        case 105:
        case 103:
        case 101:
        case 99:
        case 98:
        case 97:
        case 96:
        case 95:
        case 28:
        case 27:
        case 22:
        case 19:
        case 18:
        case 16:
        case 15:
        case 14:
	  return 0;

        case -1:
	  if (GET_CODE (PATTERN (insn)) != ASM_INPUT
	      && asm_noperands (PATTERN (insn)) < 0)
	    fatal_insn_not_found (insn);
        default:
	  return 2;

      }

    default:
      abort ();
    }
}

static int pent_np_unit_conflict_cost PARAMS ((rtx, rtx));
static int
pent_np_unit_conflict_cost (executing_insn, candidate_insn)
     rtx executing_insn;
     rtx candidate_insn;
{
  rtx insn;
  int casenum;

  insn = executing_insn;
  switch (recog_memoized (insn))
    {
    case 416:
    case 415:
    case 414:
    case 413:
      extract_insn_cached (insn);
      if (! (constant_call_address_operand (operands[1], VOIDmode)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 411:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((which_alternative == 0) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if ((which_alternative == 0) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 403:
    case 402:
    case 401:
    case 400:
    case 399:
    case 398:
    case 397:
    case 396:
    case 395:
    case 394:
    case 393:
    case 392:
    case 391:
      casenum = 1;
      break;

    case 390:
      casenum = 5;
      break;

    case 334:
    case 333:
    case 332:
    case 331:
      extract_insn_cached (insn);
      if (! (constant_call_address_operand (operands[0], VOIDmode)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 330:
      if (! (get_attr_type (insn) == TYPE_IBR))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 315:
    case 314:
    case 313:
    case 312:
    case 311:
    case 310:
    case 309:
    case 308:
    case 307:
    case 306:
    case 305:
    case 304:
    case 303:
    case 302:
    case 301:
    case 300:
    case 299:
    case 298:
    case 297:
    case 296:
    case 295:
    case 294:
    case 293:
    case 292:
    case 289:
    case 288:
    case 287:
    case 286:
    case 285:
    case 284:
    case 283:
    case 282:
    case 281:
    case 280:
    case 279:
    case 278:
      extract_insn_cached (insn);
      if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 6;
        }
      else if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 7;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode))))
        {
	  casenum = 8;
        }
      else if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 277:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((which_alternative == 1) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode)))))
        {
	  casenum = 8;
        }
      else if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 273:
    case 272:
    case 271:
    case 270:
    case 269:
    case 268:
    case 267:
    case 266:
      if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
        {
	  casenum = 8;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if (((get_attr_type (insn) == TYPE_ALU) || (get_attr_type (insn) == TYPE_ISHIFT)) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 276:
    case 265:
      if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 6;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 7;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 261:
    case 259:
    case 257:
    case 230:
    case 229:
    case 228:
    case 227:
    case 226:
    case 225:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 6;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 192:
    case 190:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || (which_alternative == 1)) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if (((which_alternative == 0) || (which_alternative == 1)) && (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1)))
        {
	  casenum = 8;
        }
      else if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 185:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 0) && (which_alternative != 2))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 184:
    case 183:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 182:
    case 181:
    case 178:
    case 175:
    case 174:
      casenum = 2;
      break;

    case 173:
    case 172:
    case 171:
    case 170:
    case 169:
    case 168:
    case 167:
    case 166:
    case 165:
      casenum = 0;
      break;

    case 152:
    case 151:
    case 149:
    case 148:
    case 147:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], QImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((! (incdec_operand (operands[2], QImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if ((! (incdec_operand (operands[2], QImode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((! (incdec_operand (operands[2], QImode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 146:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
        {
	  casenum = 8;
        }
      else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if (((which_alternative != 3) && (! (incdec_operand (operands[2], QImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 150:
    case 145:
    case 144:
    case 143:
    case 142:
    case 141:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], HImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((! (incdec_operand (operands[2], HImode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 140:
      extract_constrain_insn_cached (insn);
      if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
        {
	  casenum = 8;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if (((which_alternative != 2) && (! (incdec_operand (operands[2], HImode)))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 139:
    case 138:
    case 137:
    case 136:
      extract_insn_cached (insn);
      if ((! (incdec_operand (operands[2], SImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((! (incdec_operand (operands[2], SImode))) && ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if ((! (incdec_operand (operands[2], SImode))) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((! (incdec_operand (operands[2], SImode))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 135:
      if ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && (get_attr_memory (insn) == MEMORY_BOTH)))
        {
	  casenum = 6;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_pent_pair (insn) == PENT_PAIR_NP) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))))
        {
	  casenum = 7;
        }
      else if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
        {
	  casenum = 8;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((get_attr_type (insn) == TYPE_ALU) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 404:
    case 338:
    case 329:
    case 328:
    case 327:
    case 326:
    case 319:
    case 318:
    case 134:
    case 133:
    case 132:
    case 131:
      casenum = 11 /* 0xb */;
      break;

    case 340:
    case 223:
    case 222:
    case 221:
    case 220:
    case 219:
    case 218:
    case 217:
    case 216:
    case 215:
    case 214:
    case 213:
    case 212:
    case 210:
    case 208:
    case 207:
    case 206:
    case 205:
    case 204:
    case 203:
    case 202:
    case 201:
    case 200:
    case 199:
    case 198:
    case 196:
    case 194:
    case 193:
    case 191:
    case 164:
    case 163:
    case 162:
    case 161:
    case 160:
    case 159:
    case 158:
    case 157:
    case 156:
    case 153:
    case 130:
    case 129:
      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 6;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 7;
        }
      else if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 155:
    case 128:
      if (get_attr_memory (insn) == MEMORY_BOTH)
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 126:
    case 125:
    case 124:
    case 123:
    case 122:
    case 121:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 3;
        }
      else if ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 109:
    case 107:
    case 105:
    case 103:
    case 101:
      extract_insn_cached (insn);
      if ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 120:
    case 119:
    case 118:
    case 117:
    case 116:
    case 115:
    case 108:
    case 106:
    case 104:
    case 102:
    case 100:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 99:
    case 98:
    case 97:
    case 96:
    case 95:
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 1) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 3;
        }
      else if ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 83:
    case 80:
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  casenum = 8;
        }
      else if ((which_alternative == 1) && (get_attr_memory (insn) == MEMORY_BOTH))
        {
	  casenum = 9;
        }
      else if ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE))
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 74:
    case 73:
    case 72:
    case 71:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((get_attr_memory (insn) == MEMORY_LOAD) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 3;
        }
      else if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 65:
    case 64:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else
        {
	  casenum = 8;
        }
      break;

    case 60:
      extract_constrain_insn_cached (insn);
      if (((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))) && ((immediate_operand (operands[1], VOIDmode)) || (get_attr_memory (insn) == MEMORY_STORE)))
        {
	  casenum = 4;
        }
      else if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 59:
      extract_constrain_insn_cached (insn);
      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 46:
      extract_constrain_insn_cached (insn);
      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 54:
    case 52:
    case 39:
      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV)))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 35:
      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA))))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 262:
    case 260:
    case 258:
    case 211:
    case 209:
    case 197:
    case 195:
    case 82:
    case 79:
    case 77:
    case 49:
    case 43:
    case 34:
    case 33:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 9;
        }
      else if (get_attr_memory (insn) == MEMORY_STORE)
        {
	  casenum = 10 /* 0xa */;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 45:
    case 38:
    case 32:
    case 31:
      extract_insn_cached (insn);
      if (memory_operand (operands[0], VOIDmode))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 44:
    case 37:
    case 30:
    case 29:
      extract_insn_cached (insn);
      if (memory_operand (operands[1], VOIDmode))
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case 188:
    case 187:
    case 56:
    case 55:
    case 48:
    case 42:
    case 12:
    case 11:
    case 10:
    case 9:
    case 8:
    case 7:
    case 6:
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
      if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
        {
	  casenum = 8;
        }
      else
        {
	  casenum = 11 /* 0xb */;
        }
      break;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
    default:
      casenum = 8;
      break;

    }

  insn = candidate_insn;
  switch (casenum)
    {
    case 0:
      return 11 /* 0xb */;

    case 1:
      return 12 /* 0xc */;

    case 2:
      return 46 /* 0x2e */;

    case 3:
      return 3;

    case 4:
      return 2;

    case 5:
      return 2;

    case 6:
      return 3;

    case 7:
      return 2;

    case 8:
      return 1;

    case 9:
      switch (recog_memoized (insn))
	{
        case 416:
        case 415:
        case 414:
        case 413:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[1], VOIDmode)))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 334:
        case 333:
        case 332:
        case 331:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[0], VOIDmode)))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 330:
	  if (! (get_attr_type (insn) == TYPE_IBR))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 315:
        case 314:
        case 313:
        case 312:
        case 311:
        case 310:
        case 309:
        case 308:
        case 307:
        case 306:
        case 305:
        case 304:
        case 303:
        case 302:
        case 301:
        case 300:
        case 299:
        case 298:
        case 297:
        case 296:
        case 295:
        case 294:
        case 293:
        case 292:
        case 289:
        case 288:
        case 287:
        case 286:
        case 285:
        case 284:
        case 283:
        case 282:
        case 281:
        case 280:
        case 279:
        case 278:
	  extract_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode))))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 277:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode)))))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 192:
        case 190:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 0) || (which_alternative == 1))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1)))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 185:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 0) && (which_alternative != 2)) || ((which_alternative == 0) || (which_alternative == 2)))
	    {
	      if ((which_alternative != 0) && (which_alternative != 2))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 184:
        case 183:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 1)
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 273:
        case 272:
        case 271:
        case 270:
        case 269:
        case 268:
        case 267:
        case 266:
        case 146:
        case 140:
        case 135:
	  if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 83:
        case 80:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 0)
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 60:
	  extract_constrain_insn_cached (insn);
	  if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2)))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 59:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 1) || (memory_operand (operands[1], VOIDmode))) || ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode)))))
	    {
	      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 46:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 54:
        case 52:
        case 39:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV)))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 35:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA))))
	        {
		  return 3;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 3;
	    }

        case 404:
        case 338:
        case 329:
        case 328:
        case 327:
        case 326:
        case 319:
        case 318:
        case 262:
        case 260:
        case 258:
        case 211:
        case 209:
        case 197:
        case 195:
        case 155:
        case 134:
        case 133:
        case 132:
        case 131:
        case 128:
        case 82:
        case 79:
        case 77:
        case 49:
        case 43:
        case 34:
        case 33:
	  return 0;

        case 45:
        case 38:
        case 32:
        case 31:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[0], VOIDmode))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 44:
        case 37:
        case 30:
        case 29:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case 411:
        case 340:
        case 223:
        case 222:
        case 221:
        case 220:
        case 219:
        case 218:
        case 217:
        case 216:
        case 215:
        case 214:
        case 213:
        case 212:
        case 210:
        case 208:
        case 207:
        case 206:
        case 205:
        case 204:
        case 203:
        case 202:
        case 201:
        case 200:
        case 199:
        case 198:
        case 196:
        case 194:
        case 193:
        case 191:
        case 188:
        case 187:
        case 164:
        case 163:
        case 162:
        case 161:
        case 160:
        case 159:
        case 158:
        case 157:
        case 156:
        case 153:
        case 152:
        case 151:
        case 150:
        case 149:
        case 148:
        case 147:
        case 145:
        case 144:
        case 143:
        case 142:
        case 141:
        case 139:
        case 138:
        case 137:
        case 136:
        case 130:
        case 129:
        case 56:
        case 55:
        case 48:
        case 42:
        case 12:
        case 11:
        case 10:
        case 9:
        case 8:
        case 7:
        case 6:
        case 5:
        case 4:
        case 3:
        case 2:
        case 1:
        case 0:
	  if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
	    {
	      return 3;
	    }
	  else
	    {
	      return 0;
	    }

        case -1:
	  if (GET_CODE (PATTERN (insn)) != ASM_INPUT
	      && asm_noperands (PATTERN (insn)) < 0)
	    fatal_insn_not_found (insn);
        default:
	  return 3;

      }

    case 10:
      switch (recog_memoized (insn))
	{
        case 416:
        case 415:
        case 414:
        case 413:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[1], VOIDmode)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 334:
        case 333:
        case 332:
        case 331:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[0], VOIDmode)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 330:
	  if (! (get_attr_type (insn) == TYPE_IBR))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 315:
        case 314:
        case 313:
        case 312:
        case 311:
        case 310:
        case 309:
        case 308:
        case 307:
        case 306:
        case 305:
        case 304:
        case 303:
        case 302:
        case 301:
        case 300:
        case 299:
        case 298:
        case 297:
        case 296:
        case 295:
        case 294:
        case 293:
        case 292:
        case 289:
        case 288:
        case 287:
        case 286:
        case 285:
        case 284:
        case 283:
        case 282:
        case 281:
        case 280:
        case 279:
        case 278:
	  extract_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode))))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 277:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode)))))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 192:
        case 190:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 0) || (which_alternative == 1))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 185:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 0) && (which_alternative != 2)) || ((which_alternative == 0) || (which_alternative == 2)))
	    {
	      if ((which_alternative != 0) && (which_alternative != 2))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 184:
        case 183:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 1)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 273:
        case 272:
        case 271:
        case 270:
        case 269:
        case 268:
        case 267:
        case 266:
        case 146:
        case 140:
        case 135:
	  if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 83:
        case 80:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 0)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 60:
	  extract_constrain_insn_cached (insn);
	  if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 59:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 1) || (memory_operand (operands[1], VOIDmode))) || ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode)))))
	    {
	      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 46:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 54:
        case 52:
        case 39:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 35:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA))))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 404:
        case 338:
        case 329:
        case 328:
        case 327:
        case 326:
        case 319:
        case 318:
        case 262:
        case 260:
        case 258:
        case 211:
        case 209:
        case 197:
        case 195:
        case 155:
        case 134:
        case 133:
        case 132:
        case 131:
        case 128:
        case 82:
        case 79:
        case 77:
        case 49:
        case 43:
        case 34:
        case 33:
	  return 0;

        case 45:
        case 38:
        case 32:
        case 31:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[0], VOIDmode))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 44:
        case 37:
        case 30:
        case 29:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 411:
        case 340:
        case 223:
        case 222:
        case 221:
        case 220:
        case 219:
        case 218:
        case 217:
        case 216:
        case 215:
        case 214:
        case 213:
        case 212:
        case 210:
        case 208:
        case 207:
        case 206:
        case 205:
        case 204:
        case 203:
        case 202:
        case 201:
        case 200:
        case 199:
        case 198:
        case 196:
        case 194:
        case 193:
        case 191:
        case 188:
        case 187:
        case 164:
        case 163:
        case 162:
        case 161:
        case 160:
        case 159:
        case 158:
        case 157:
        case 156:
        case 153:
        case 152:
        case 151:
        case 150:
        case 149:
        case 148:
        case 147:
        case 145:
        case 144:
        case 143:
        case 142:
        case 141:
        case 139:
        case 138:
        case 137:
        case 136:
        case 130:
        case 129:
        case 56:
        case 55:
        case 48:
        case 42:
        case 12:
        case 11:
        case 10:
        case 9:
        case 8:
        case 7:
        case 6:
        case 5:
        case 4:
        case 3:
        case 2:
        case 1:
        case 0:
	  if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case -1:
	  if (GET_CODE (PATTERN (insn)) != ASM_INPUT
	      && asm_noperands (PATTERN (insn)) < 0)
	    fatal_insn_not_found (insn);
        default:
	  return 2;

      }

    case 11:
      switch (recog_memoized (insn))
	{
        case 416:
        case 415:
        case 414:
        case 413:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[1], VOIDmode)))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 334:
        case 333:
        case 332:
        case 331:
	  extract_insn_cached (insn);
	  if (! (constant_call_address_operand (operands[0], VOIDmode)))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 330:
	  if (! (get_attr_type (insn) == TYPE_IBR))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 315:
        case 314:
        case 313:
        case 312:
        case 311:
        case 310:
        case 309:
        case 308:
        case 307:
        case 306:
        case 305:
        case 304:
        case 303:
        case 302:
        case 301:
        case 300:
        case 299:
        case 298:
        case 297:
        case 296:
        case 295:
        case 294:
        case 293:
        case 292:
        case 289:
        case 288:
        case 287:
        case 286:
        case 285:
        case 284:
        case 283:
        case 282:
        case 281:
        case 280:
        case 279:
        case 278:
	  extract_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (const_int_operand (operands[2], VOIDmode))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (const_int_operand (operands[2], VOIDmode))))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 277:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 1) && (const_int_operand (operands[2], VOIDmode)))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 1) || (! (const_int_operand (operands[2], VOIDmode)))))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 192:
        case 190:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((which_alternative == 0) || (which_alternative == 1))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((which_alternative != 0) && (which_alternative != 1)))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 185:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 0) && (which_alternative != 2)) || ((which_alternative == 0) || (which_alternative == 2)))
	    {
	      if ((which_alternative != 0) && (which_alternative != 2))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 184:
        case 183:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 1)
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 273:
        case 272:
        case 271:
        case 270:
        case 269:
        case 268:
        case 267:
        case 266:
        case 146:
        case 140:
        case 135:
	  if (get_attr_pent_pair (insn) == PENT_PAIR_NP)
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 83:
        case 80:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative == 0)
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 60:
	  extract_constrain_insn_cached (insn);
	  if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2)))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 59:
	  extract_constrain_insn_cached (insn);
	  if (((which_alternative != 1) || (memory_operand (operands[1], VOIDmode))) || ((which_alternative == 1) && (! (memory_operand (operands[1], VOIDmode)))))
	    {
	      if ((which_alternative != 1) || (memory_operand (operands[1], VOIDmode)))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 46:
	  extract_constrain_insn_cached (insn);
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2))))))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && ((which_alternative != 3) && ((which_alternative != 5) && ((! ((TARGET_MOVX) != (0))) || (which_alternative != 2))))))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative != 3) || ((! ((TARGET_PARTIAL_REG_STALL) == (0))) && (! ((TARGET_QIMODE_MATH) == (0))))) && (((which_alternative == 3) && (((TARGET_PARTIAL_REG_STALL) == (0)) || ((TARGET_QIMODE_MATH) == (0)))) || ((which_alternative == 3) || ((which_alternative == 5) || (((TARGET_MOVX) != (0)) && (which_alternative == 2)))))))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 54:
        case 52:
        case 39:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (get_attr_type (insn) == TYPE_IMOV)))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (! (get_attr_type (insn) == TYPE_IMOV)))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 35:
	  if (((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA)))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && ((get_attr_type (insn) == TYPE_IMOV) || (get_attr_type (insn) == TYPE_LEA))))
	    {
	      if ((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || ((! (get_attr_type (insn) == TYPE_IMOV)) && (! (get_attr_type (insn) == TYPE_LEA))))
	        {
		  return 1;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 1;
	    }

        case 404:
        case 338:
        case 329:
        case 328:
        case 327:
        case 326:
        case 319:
        case 318:
        case 262:
        case 260:
        case 258:
        case 211:
        case 209:
        case 197:
        case 195:
        case 155:
        case 134:
        case 133:
        case 132:
        case 131:
        case 128:
        case 82:
        case 79:
        case 77:
        case 49:
        case 43:
        case 34:
        case 33:
	  return 0;

        case 45:
        case 38:
        case 32:
        case 31:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[0], VOIDmode))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 44:
        case 37:
        case 30:
        case 29:
	  extract_insn_cached (insn);
	  if (memory_operand (operands[1], VOIDmode))
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case 411:
        case 340:
        case 223:
        case 222:
        case 221:
        case 220:
        case 219:
        case 218:
        case 217:
        case 216:
        case 215:
        case 214:
        case 213:
        case 212:
        case 210:
        case 208:
        case 207:
        case 206:
        case 205:
        case 204:
        case 203:
        case 202:
        case 201:
        case 200:
        case 199:
        case 198:
        case 196:
        case 194:
        case 193:
        case 191:
        case 188:
        case 187:
        case 164:
        case 163:
        case 162:
        case 161:
        case 160:
        case 159:
        case 158:
        case 157:
        case 156:
        case 153:
        case 152:
        case 151:
        case 150:
        case 149:
        case 148:
        case 147:
        case 145:
        case 144:
        case 143:
        case 142:
        case 141:
        case 139:
        case 138:
        case 137:
        case 136:
        case 130:
        case 129:
        case 56:
        case 55:
        case 48:
        case 42:
        case 12:
        case 11:
        case 10:
        case 9:
        case 8:
        case 7:
        case 6:
        case 5:
        case 4:
        case 3:
        case 2:
        case 1:
        case 0:
	  if (get_attr_imm_disp (insn) == IMM_DISP_TRUE)
	    {
	      return 1;
	    }
	  else
	    {
	      return 0;
	    }

        case -1:
	  if (GET_CODE (PATTERN (insn)) != ASM_INPUT
	      && asm_noperands (PATTERN (insn)) < 0)
	    fatal_insn_not_found (insn);
        default:
	  return 1;

      }

    case 12:
      switch (recog_memoized (insn))
	{
        case 370:
        case 368:
        case 366:
        case 364:
        case 362:
        case 360:
        case 358:
	  extract_insn_cached (insn);
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], TFmode))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 369:
        case 367:
        case 365:
        case 363:
        case 361:
        case 359:
        case 357:
	  extract_insn_cached (insn);
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], XFmode))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 356:
        case 355:
        case 354:
        case 353:
        case 352:
	  extract_insn_cached (insn);
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], DFmode))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 351:
        case 350:
        case 349:
	  extract_insn_cached (insn);
	  if ((! (get_attr_type (insn) == TYPE_FOP)) && (! (mult_operator (operands[3], SFmode))))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 126:
        case 125:
        case 124:
        case 123:
        case 122:
        case 121:
        case 120:
        case 119:
        case 118:
        case 117:
        case 116:
        case 115:
        case 108:
        case 106:
        case 104:
        case 102:
        case 100:
	  extract_constrain_insn_cached (insn);
	  if (which_alternative != 0)
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 74:
        case 73:
        case 72:
        case 71:
        case 65:
        case 64:
	  extract_constrain_insn_cached (insn);
	  if ((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2)))
	    {
	      return 2;
	    }
	  else
	    {
	      return 0;
	    }

        case 60:
	  extract_constrain_insn_cached (insn);
	  if ((((get_attr_imm_disp (insn) == IMM_DISP_TRUE) || (((which_alternative == 0) || (which_alternative == 1)) || (which_alternative == 2))) || ((! (get_attr_imm_disp (insn) == IMM_DISP_TRUE)) && (((which_alternative != 0) && (which_alternative != 1)) && (which_alternative != 2)))) || ((which_alternative == 0) || ((which_alternative == 1) || (which_alternative == 2))))
	    {
	      if ((which_alternative != 0) && ((which_alternative != 1) && (which_alternative != 2)))
	        {
		  return 2;
	        }
	      else
	        {
		  return 0;
	        }
	    }
	  else
	    {
	      return 2;
	    }

        case 410:
        case 409:
        case 408:
        case 407:
        case 389:
        case 388:
        case 387:
        case 386:
        case 385:
        case 384:
        case 383:
        case 382:
        case 381:
        case 380:
        case 379:
        case 378:
        case 377:
        case 376:
        case 375:
        case 374:
        case 373:
        case 372:
        case 371:
        case 348:
        case 347:
        case 346:
        case 345:
        case 256:
        case 255:
        case 254:
        case 253:
        case 252:
        case 251:
        case 250:
        case 249:
        case 248:
        case 243:
        case 242:
        case 241:
        case 240:
        case 239:
        case 238:
        case 237:
        case 236:
        case 235:
        case 109:
        case 107:
        case 105:
        case 103:
        case 101:
        case 99:
        case 98:
        case 97:
        case 96:
        case 95:
        case 28:
        case 27:
        case 22:
        case 19:
        case 18:
        case 16:
        case 15:
        case 14:
	  return 0;

        case -1:
	  if (GET_CODE (PATTERN (insn)) != ASM_INPUT
	      && asm_noperands (PATTERN (insn)) < 0)
	    fatal_insn_not_found (insn);
        default:
	  return 2;

      }

    default:
      abort ();
    }
}

struct function_unit_desc function_units[] = {
  {"pent_np", 1, 1, 0, 0, 46, pent_np_unit_ready_cost, pent_np_unit_conflict_cost, 46, pent_np_unit_blockage_range, pent_np_unit_blockage}, 
  {"pent_mul", 2, 1, 1, 0, 70, pent_mul_unit_ready_cost, pent_mul_unit_conflict_cost, 70, pent_mul_unit_blockage_range, pent_mul_unit_blockage}, 
  {"fpu", 4, 1, 0, 0, 68, fpu_unit_ready_cost, fpu_unit_conflict_cost, 68, fpu_unit_blockage_range, fpu_unit_blockage}, 
  {"pent_u", 8, 1, 0, 0, 3, pent_u_unit_ready_cost, pent_u_unit_conflict_cost, 3, pent_u_unit_blockage_range, pent_u_unit_blockage}, 
  {"pent_uv", 16, 2, 0, 0, 3, pent_uv_unit_ready_cost, pent_uv_unit_conflict_cost, 3, pent_uv_unit_blockage_range, pent_uv_unit_blockage}, 
  {"pent_v", 32, 1, 0, 1, 1, pent_v_unit_ready_cost, 0, 1, 0, 0}, 
  {"ppro_p0", 64, 1, 0, 0, 17, ppro_p0_unit_ready_cost, ppro_p0_unit_conflict_cost, 17, ppro_p0_unit_blockage_range, ppro_p0_unit_blockage}, 
  {"ppro_p01", 128, 2, 0, 1, 1, ppro_p01_unit_ready_cost, 0, 1, 0, 0}, 
  {"ppro_p2", 256, 1, 0, 1, 1, ppro_p2_unit_ready_cost, 0, 1, 0, 0}, 
  {"ppro_p34", 512, 1, 0, 1, 1, ppro_p34_unit_ready_cost, 0, 1, 0, 0}, 
  {"k6_alux", 1024, 1, 0, 0, 17, k6_alux_unit_ready_cost, k6_alux_unit_conflict_cost, 17, k6_alux_unit_blockage_range, k6_alux_unit_blockage}, 
  {"k6_alu", 2048, 2, 0, 0, 17, k6_alu_unit_ready_cost, k6_alu_unit_conflict_cost, 17, k6_alu_unit_blockage_range, k6_alu_unit_blockage}, 
  {"k6_branch", 4096, 1, 0, 1, 1, k6_branch_unit_ready_cost, 0, 1, 0, 0}, 
  {"k6_load", 8192, 1, 0, 0, 10, k6_load_unit_ready_cost, k6_load_unit_conflict_cost, 10, k6_load_unit_blockage_range, k6_load_unit_blockage}, 
  {"k6_store", 16384, 1, 0, 0, 10, k6_store_unit_ready_cost, k6_store_unit_conflict_cost, 10, k6_store_unit_blockage_range, k6_store_unit_blockage}, 
  {"k6_fpu", 32768, 1, 1, 0, 56, k6_fpu_unit_ready_cost, k6_fpu_unit_conflict_cost, 56, k6_fpu_unit_blockage_range, k6_fpu_unit_blockage}, 
  {"athlon_vectordec", 65536, 1, 0, 1, 1, athlon_vectordec_unit_ready_cost, 0, 1, athlon_vectordec_unit_blockage_range, athlon_vectordec_unit_blockage}, 
  {"athlon_directdec", 131072, 3, 0, 1, 1, athlon_directdec_unit_ready_cost, 0, 1, 0, 0}, 
  {"athlon_ieu", 262144, 3, 0, 0, 15, athlon_ieu_unit_ready_cost, athlon_ieu_unit_conflict_cost, 15, athlon_ieu_unit_blockage_range, athlon_ieu_unit_blockage}, 
  {"athlon_muldiv", 524288, 1, 0, 0, 42, athlon_muldiv_unit_ready_cost, athlon_muldiv_unit_conflict_cost, 42, athlon_muldiv_unit_blockage_range, athlon_muldiv_unit_blockage}, 
  {"athlon_fp", 1048576, 3, 0, 1, 1, athlon_fp_unit_ready_cost, 0, 1, 0, 0}, 
  {"athlon_fp_mul", 2097152, 1, 0, 1, 1, athlon_fp_mul_unit_ready_cost, 0, 1, 0, 0}, 
  {"athlon_fp_add", 4194304, 1, 0, 1, 1, athlon_fp_add_unit_ready_cost, 0, 1, 0, 0}, 
  {"athlon_fp_muladd", 8388608, 2, 0, 1, 1, athlon_fp_muladd_unit_ready_cost, 0, 1, 0, 0}, 
  {"athlon_fp_store", 16777216, 1, 0, 1, 1, athlon_fp_store_unit_ready_cost, 0, 1, 0, 0}, 
  {"athlon_load", 33554432, 2, 0, 1, 1, athlon_load_unit_ready_cost, 0, 1, 0, 0}, 
};

int length_unit_log = 0;
