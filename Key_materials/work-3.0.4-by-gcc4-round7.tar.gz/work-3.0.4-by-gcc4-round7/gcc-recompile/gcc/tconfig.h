#ifdef IN_GCC
# include "gansidecl.h"
# include "i386/xm-i386.h"
# include "defaults.h"
#endif
#ifndef POSIX
# define POSIX
#endif
#ifndef GENERATOR_FILE
#include "insn-codes.h"
#include "insn-flags.h"
#endif
#define USING_SJLJ_EXCEPTIONS 0
