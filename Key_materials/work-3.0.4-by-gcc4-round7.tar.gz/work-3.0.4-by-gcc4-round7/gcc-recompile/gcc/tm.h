#define TARGET_CPU_DEFAULT (3)
#ifdef IN_GCC
# include "gansidecl.h"
# include "i386/i386.h"
# include "i386/att.h"
# include "linux.h"
# include "i386/linux.h"
# include "defaults.h"
#endif
#ifndef GENERATOR_FILE
#include "insn-codes.h"
#include "insn-flags.h"
#endif
