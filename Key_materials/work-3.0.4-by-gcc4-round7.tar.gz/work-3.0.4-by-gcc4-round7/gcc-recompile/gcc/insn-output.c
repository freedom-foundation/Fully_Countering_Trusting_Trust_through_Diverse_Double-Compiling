/* Generated automatically by the program `genoutput'
   from the machine description file `md'.  */

#include "config.h"
#include "system.h"
#include "flags.h"
#include "ggc.h"
#include "rtl.h"
#include "tm_p.h"
#include "function.h"
#include "regs.h"
#include "hard-reg-set.h"
#include "real.h"
#include "insn-config.h"

#include "conditions.h"
#include "insn-attr.h"

#include "recog.h"

#include "toplev.h"
#include "output.h"

static const char * const output_0[] = {
  "test{l}\t{%0, %0|%0, %0}",
  "cmp{l}\t{%1, %0|%0, %1}",
};

static const char * const output_3[] = {
  "test{w}\t{%0, %0|%0, %0}",
  "cmp{w}\t{%1, %0|%0, %1}",
};

static const char * const output_6[] = {
  "test{b}\t{%0, %0|%0, %0}",
  "cmp{b}\t{$0, %0|%0, 0}",
};

static const char *output_13 PARAMS ((rtx *, rtx));

static const char *
output_13 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
    return "ftst\n\tfnstsw\t%0\n\tfstp\t%y0";
  else
    return "ftst\n\tfnstsw\t%0";
}
}

static const char *output_14 PARAMS ((rtx *, rtx));

static const char *
output_14 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 0, 0);
}

static const char *output_15 PARAMS ((rtx *, rtx));

static const char *
output_15 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 2, 0);
}

static const char *output_16 PARAMS ((rtx *, rtx));

static const char *
output_16 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 0, 0);
}

static const char *output_17 PARAMS ((rtx *, rtx));

static const char *
output_17 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 2, 0);
}

static const char *output_18 PARAMS ((rtx *, rtx));

static const char *
output_18 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 0, 0);
}

static const char *output_19 PARAMS ((rtx *, rtx));

static const char *
output_19 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 0, 0);
}

static const char *output_20 PARAMS ((rtx *, rtx));

static const char *
output_20 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 2, 0);
}

static const char *output_21 PARAMS ((rtx *, rtx));

static const char *
output_21 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 2, 0);
}

static const char *output_22 PARAMS ((rtx *, rtx));

static const char *
output_22 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 0, 1);
}

static const char *output_23 PARAMS ((rtx *, rtx));

static const char *
output_23 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 2, 1);
}

static const char *output_27 PARAMS ((rtx *, rtx));

static const char *
output_27 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 1, 0);
}

static const char *output_28 PARAMS ((rtx *, rtx));

static const char *
output_28 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fp_compare (insn, operands, 1, 1);
}

static const char *output_34 PARAMS ((rtx *, rtx));

static const char *
output_34 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  operands[1] = constm1_rtx;
  return "or{l}\t{%1, %0|%0, %1}";
}
}

static const char *output_35 PARAMS ((rtx *, rtx));

static const char *
output_35 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_MMX:
      return "movd\t{%1, %0|%0, %1}";

    case TYPE_LEA:
      return "lea{l}\t{%1, %0|%0, %1}";

    default:
      if (flag_pic && SYMBOLIC_CONST (operands[1]))
	abort();
      return "mov{l}\t{%1, %0|%0, %1}";
    }
}
}

static const char * const output_37[] = {
  "push{w}\t{|WORD PTR }%1",
  "push{w}\t%1",
};

static const char *output_39 PARAMS ((rtx *, rtx));

static const char *
output_39 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_IMOVX:
      /* movzwl is faster than movw on p2 due to partial word stalls,
	 though not as fast as an aligned movl.  */
      return "movz{wl|x}\t{%1, %k0|%k0, %1}";
    default:
      if (get_attr_mode (insn) == MODE_SI)
        return "mov{l}\t{%k1, %k0|%k0, %k1}";
      else
        return "mov{w}\t{%1, %0|%0, %1}";
    }
}
}

static const char * const output_44[] = {
  "push{w}\t{|word ptr }%1",
  "push{w}\t%w1",
};

static const char *output_46 PARAMS ((rtx *, rtx));

static const char *
output_46 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_IMOVX:
      if (!QI_REG_P (operands[1]) && GET_CODE (operands[1]) != MEM)
	abort ();
      return "movz{bl|x}\t{%1, %k0|%k0, %1}";
    default:
      if (get_attr_mode (insn) == MODE_SI)
        return "mov{l}\t{%k1, %k0|%k0, %k1}";
      else
        return "mov{b}\t{%1, %0|%0, %1}";
    }
}
}

static const char *output_52 PARAMS ((rtx *, rtx));

static const char *
output_52 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_IMOVX:
      return "movs{bl|x}\t{%h1, %k0|%k0, %h1}";
    default:
      return "mov{b}\t{%h1, %0|%0, %h1}";
    }
}
}

static const char *output_54 PARAMS ((rtx *, rtx));

static const char *
output_54 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_IMOVX:
      return "movz{bl|x}\t{%h1, %k0|%k0, %h1}";
    default:
      return "mov{b}\t{%h1, %0|%0, %h1}";
    }
}
}

static const char * const output_58[] = {
  "#",
  "#",
  "movq\t{%1, %0|%0, %1}",
  "movq\t{%1, %0|%0, %1}",
};

static const char *output_59 PARAMS ((rtx *, rtx));

static const char *
output_59 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      /* %%% We loose REG_DEAD notes for controling pops if we split late.  */
      operands[0] = gen_rtx_MEM (SFmode, stack_pointer_rtx);
      operands[2] = stack_pointer_rtx;
      operands[3] = GEN_INT (4);
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "sub{l}\t{%3, %2|%2, %3}\n\tfstp%z0\t%y0";
      else
	return "sub{l}\t{%3, %2|%2, %3}\n\tfst%z0\t%y0";

    case 1:
      return "push{l}\t%1";

    default:
      abort ();
    }
}
}

static const char *output_60 PARAMS ((rtx *, rtx));

static const char *
output_60 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0";
      else
        return "fst%z0\t%y0";

    case 2:
      switch (standard_80387_constant_p (operands[1]))
        {
        case 1:
	  return "fldz";
	case 2:
	  return "fld1";
	}
      abort();

    case 3:
    case 4:
      return "mov{l}\t{%1, %0|%0, %1}";

    default:
      abort();
    }
}
}

static const char *output_61 PARAMS ((rtx *, rtx));

static const char *
output_61 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (STACK_TOP_P (operands[0]))
    return "fxch\t%1";
  else
    return "fxch\t%0";
}
}

static const char *output_62 PARAMS ((rtx *, rtx));

static const char *
output_62 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      /* %%% We loose REG_DEAD notes for controling pops if we split late.  */
      operands[0] = gen_rtx_MEM (DFmode, stack_pointer_rtx);
      operands[2] = stack_pointer_rtx;
      operands[3] = GEN_INT (8);
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "sub{l}\t{%3, %2|%2, %3}\n\tfstp%z0\t%y0";
      else
	return "sub{l}\t{%3, %2|%2, %3}\n\tfst%z0\t%y0";

    case 1:
    case 2:
      return "#";

    default:
      abort ();
    }
}
}

static const char *output_63 PARAMS ((rtx *, rtx));

static const char *
output_63 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      /* %%% We loose REG_DEAD notes for controling pops if we split late.  */
      operands[0] = gen_rtx_MEM (DFmode, stack_pointer_rtx);
      operands[2] = stack_pointer_rtx;
      operands[3] = GEN_INT (8);
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "sub{l}\t{%3, %2|%2, %3}\n\tfstp%z0\t%y0";
      else
	return "sub{l}\t{%3, %2|%2, %3}\n\tfst%z0\t%y0";

    case 1:
      return "#";

    default:
      abort ();
    }
}
}

static const char *output_64 PARAMS ((rtx *, rtx));

static const char *
output_64 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0";
      else
        return "fst%z0\t%y0";

    case 2:
      switch (standard_80387_constant_p (operands[1]))
        {
        case 1:
	  return "fldz";
	case 2:
	  return "fld1";
	}
      abort();

    case 3:
    case 4:
      return "#";

    default:
      abort();
    }
}
}

static const char *output_65 PARAMS ((rtx *, rtx));

static const char *
output_65 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0";
      else
        return "fst%z0\t%y0";

    case 2:
      switch (standard_80387_constant_p (operands[1]))
        {
        case 1:
	  return "fldz";
	case 2:
	  return "fld1";
	}
      abort();

    case 3:
    case 4:
      return "#";

    default:
      abort();
    }
}
}

static const char *output_66 PARAMS ((rtx *, rtx));

static const char *
output_66 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (STACK_TOP_P (operands[0]))
    return "fxch\t%1";
  else
    return "fxch\t%0";
}
}

static const char *output_67 PARAMS ((rtx *, rtx));

static const char *
output_67 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      /* %%% We loose REG_DEAD notes for controling pops if we split late.  */
      operands[0] = gen_rtx_MEM (XFmode, stack_pointer_rtx);
      operands[2] = stack_pointer_rtx;
      operands[3] = GEN_INT (12);
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "sub{l}\t{%3, %2|%2, %3}\n\tfstp%z0\t%y0";
      else
	return "sub{l}\t{%3, %2|%2, %3}\n\tfst%z0\t%y0";

    case 1:
    case 2:
      return "#";

    default:
      abort ();
    }
}
}

static const char *output_68 PARAMS ((rtx *, rtx));

static const char *
output_68 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      /* %%% We loose REG_DEAD notes for controling pops if we split late.  */
      operands[0] = gen_rtx_MEM (XFmode, stack_pointer_rtx);
      operands[2] = stack_pointer_rtx;
      operands[3] = GEN_INT (16);
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "sub{l}\t{%3, %2|%2, %3}\n\tfstp%z0\t%y0";
      else
	return "sub{l}\t{%3, %2|%2, %3}\n\tfst%z0\t%y0";

    case 1:
    case 2:
      return "#";

    default:
      abort ();
    }
}
}

static const char *output_69 PARAMS ((rtx *, rtx));

static const char *
output_69 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      /* %%% We loose REG_DEAD notes for controling pops if we split late.  */
      operands[0] = gen_rtx_MEM (XFmode, stack_pointer_rtx);
      operands[2] = stack_pointer_rtx;
      operands[3] = GEN_INT (12);
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "sub{l}\t{%3, %2|%2, %3}\n\tfstp%z0\t%y0";
      else
	return "sub{l}\t{%3, %2|%2, %3}\n\tfst%z0\t%y0";

    case 1:
      return "#";

    default:
      abort ();
    }
}
}

static const char *output_70 PARAMS ((rtx *, rtx));

static const char *
output_70 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      /* %%% We loose REG_DEAD notes for controling pops if we split late.  */
      operands[0] = gen_rtx_MEM (XFmode, stack_pointer_rtx);
      operands[2] = stack_pointer_rtx;
      operands[3] = GEN_INT (16);
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "sub{l}\t{%3, %2|%2, %3}\n\tfstp%z0\t%y0";
      else
	return "sub{l}\t{%3, %2|%2, %3}\n\tfst%z0\t%y0";

    case 1:
      return "#";

    default:
      abort ();
    }
}
}

static const char *output_71 PARAMS ((rtx *, rtx));

static const char *
output_71 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      /* There is no non-popping store to memory for XFmode.  So if
	 we need one, follow the store with a load.  */
      if (! find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0\n\tfld%z0\t%y0";
      else
        return "fstp%z0\t%y0";

    case 2:
      switch (standard_80387_constant_p (operands[1]))
        {
        case 1:
	  return "fldz";
	case 2:
	  return "fld1";
	}
      break;

    case 3: case 4:
      return "#";
    }
  abort();
}
}

static const char *output_72 PARAMS ((rtx *, rtx));

static const char *
output_72 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      /* There is no non-popping store to memory for XFmode.  So if
	 we need one, follow the store with a load.  */
      if (! find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0\n\tfld%z0\t%y0";
      else
        return "fstp%z0\t%y0";

    case 2:
      switch (standard_80387_constant_p (operands[1]))
        {
        case 1:
	  return "fldz";
	case 2:
	  return "fld1";
	}
      break;

    case 3: case 4:
      return "#";
    }
  abort();
}
}

static const char *output_73 PARAMS ((rtx *, rtx));

static const char *
output_73 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      /* There is no non-popping store to memory for XFmode.  So if
	 we need one, follow the store with a load.  */
      if (! find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0\n\tfld%z0\t%y0";
      else
        return "fstp%z0\t%y0";

    case 2:
      switch (standard_80387_constant_p (operands[1]))
        {
        case 1:
	  return "fldz";
	case 2:
	  return "fld1";
	}
      break;

    case 3: case 4:
      return "#";
    }
  abort();
}
}

static const char *output_74 PARAMS ((rtx *, rtx));

static const char *
output_74 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      /* There is no non-popping store to memory for XFmode.  So if
	 we need one, follow the store with a load.  */
      if (! find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0\n\tfld%z0\t%y0";
      else
        return "fstp%z0\t%y0";

    case 2:
      switch (standard_80387_constant_p (operands[1]))
        {
        case 1:
	  return "fldz";
	case 2:
	  return "fld1";
	}
      break;

    case 3: case 4:
      return "#";
    }
  abort();
}
}

static const char *output_75 PARAMS ((rtx *, rtx));

static const char *
output_75 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (STACK_TOP_P (operands[0]))
    return "fxch\t%1";
  else
    return "fxch\t%0";
}
}

static const char *output_76 PARAMS ((rtx *, rtx));

static const char *
output_76 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (STACK_TOP_P (operands[0]))
    return "fxch\t%1";
  else
    return "fxch\t%0";
}
}

static const char *output_87 PARAMS ((rtx *, rtx));

static const char *
output_87 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_prefix_0f (insn))
    {
    case 0:
      return "{cwtl|cwde}";
    default:
      return "movs{wl|x}\t{%1,%0|%0, %1}";
    }
}
}

static const char *output_88 PARAMS ((rtx *, rtx));

static const char *
output_88 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_prefix_0f (insn))
    {
    case 0:
      return "{cbtw|cbw}";
    default:
      return "movs{bw|x}\t{%1,%0|%0, %1}";
    }
}
}

static const char *output_95 PARAMS ((rtx *, rtx));

static const char *
output_95 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0";

      else
        return "fst%z0\t%y0";

    default:
      abort ();
    }
}
}

static const char *output_96 PARAMS ((rtx *, rtx));

static const char *
output_96 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      /* There is no non-popping store to memory for XFmode.  So if
	 we need one, follow the store with a load.  */
      if (! find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0\n\tfld%z0\t%y0";
      else
        return "fstp%z0\t%y0";

    default:
      abort ();
    }
}
}

static const char *output_97 PARAMS ((rtx *, rtx));

static const char *
output_97 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      /* There is no non-popping store to memory for XFmode.  So if
	 we need one, follow the store with a load.  */
      if (! find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0\n\tfld%z0\t%y0";
      else
        return "fstp%z0\t%y0";

    default:
      abort ();
    }
}
}

static const char *output_98 PARAMS ((rtx *, rtx));

static const char *
output_98 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      /* There is no non-popping store to memory for XFmode.  So if
	 we need one, follow the store with a load.  */
      if (! find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0\n\tfld%z0\t%y0";
      else
        return "fstp%z0\t%y0";

    default:
      abort ();
    }
}
}

static const char *output_99 PARAMS ((rtx *, rtx));

static const char *
output_99 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (REG_P (operands[1])
          && find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp\t%y0";
      else if (STACK_TOP_P (operands[0]))
        return "fld%z1\t%y1";
      else
        return "fst\t%y0";

    case 1:
      /* There is no non-popping store to memory for XFmode.  So if
	 we need one, follow the store with a load.  */
      if (! find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
        return "fstp%z0\t%y0\n\tfld%z0\t%y0";
      else
        return "fstp%z0\t%y0";

    default:
      abort ();
    }
}
}

static const char *output_100 PARAMS ((rtx *, rtx));

static const char *
output_100 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "fstp%z0\t%y0";
      else
	return "fst%z0\t%y0";
    case 1:
      return "fstp%z2\t%y2\n\tfld%z2\t%y2";
    }
  abort ();
}
}

static const char *output_101 PARAMS ((rtx *, rtx));

static const char *
output_101 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
    return "fstp%z0\t%y0";
  else
    return "fst%z0\t%y0";
}
}

static const char *output_102 PARAMS ((rtx *, rtx));

static const char *
output_102 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "fstp%z0\t%y0";
      else
	return "fst%z0\t%y0";
    case 1:
      return "fstp%z2\t%y2\n\tfld%z2\t%y2";
    }
  abort ();
}
}

static const char *output_103 PARAMS ((rtx *, rtx));

static const char *
output_103 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
    return "fstp%z0\t%y0";
  else
    return "fst%z0\t%y0";
}
}

static const char *output_104 PARAMS ((rtx *, rtx));

static const char *
output_104 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "fstp%z0\t%y0";
      else
	return "fst%z0\t%y0";
    case 1:
      return "fstp%z2\t%y2\n\tfld%z2\t%y2";
    }
  abort ();
}
}

static const char *output_105 PARAMS ((rtx *, rtx));

static const char *
output_105 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
    return "fstp%z0\t%y0";
  else
    return "fst%z0\t%y0";
}
}

static const char *output_106 PARAMS ((rtx *, rtx));

static const char *
output_106 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "fstp%z0\t%y0";
      else
	return "fst%z0\t%y0";
    case 1:
      return "fstp%z2\t%y2\n\tfld%z2\t%y2";
    }
  abort ();
}
}

static const char *output_107 PARAMS ((rtx *, rtx));

static const char *
output_107 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
    return "fstp%z0\t%y0";
  else
    return "fst%z0\t%y0";
}
}

static const char *output_108 PARAMS ((rtx *, rtx));

static const char *
output_108 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (which_alternative)
    {
    case 0:
      if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
	return "fstp%z0\t%y0";
      else
	return "fst%z0\t%y0";
    case 1:
      return "fstp%z2\t%y2\n\tfld%z2\t%y2";
    }
  abort ();
}
}

static const char *output_109 PARAMS ((rtx *, rtx));

static const char *
output_109 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (find_regno_note (insn, REG_DEAD, REGNO (operands[1])))
    return "fstp%z0\t%y0";
  else
    return "fst%z0\t%y0";
}
}

static const char *output_110 PARAMS ((rtx *, rtx));

static const char *
output_110 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fix_trunc (insn, operands);
}

static const char *output_111 PARAMS ((rtx *, rtx));

static const char *
output_111 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fix_trunc (insn, operands);
}

static const char *output_112 PARAMS ((rtx *, rtx));

static const char *
output_112 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_fix_trunc (insn, operands);
}

static const char * const output_115[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_116[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_117[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_118[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_119[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_120[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_121[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_122[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_123[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_124[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_125[] = {
  "fild%z1\t%1",
  "#",
};

static const char * const output_126[] = {
  "fild%z1\t%1",
  "#",
};

static const char *output_135 PARAMS ((rtx *, rtx));

static const char *
output_135 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_LEA:
      operands[2] = SET_SRC (XVECEXP (PATTERN (insn), 0, 0));
      return "lea{l}\t{%a2, %0|%0, %a2}";

    case TYPE_INCDEC:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      if (operands[2] == const1_rtx)
        return "inc{l}\t%0";
      else if (operands[2] == constm1_rtx)
        return "dec{l}\t%0";
      else
	abort();

    default:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();

      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
        {
          operands[2] = GEN_INT (-INTVAL (operands[2]));
          return "sub{l}\t{%2, %0|%0, %2}";
        }
      return "add{l}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_136 PARAMS ((rtx *, rtx));

static const char *
output_136 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      if (operands[2] == const1_rtx)
        return "inc{l}\t%0";
      else if (operands[2] == constm1_rtx)
        return "dec{l}\t%0";
      else
	abort();

    default:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
        {
          operands[2] = GEN_INT (-INTVAL (operands[2]));
          return "sub{l}\t{%2, %0|%0, %2}";
        }
      return "add{l}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_137 PARAMS ((rtx *, rtx));

static const char *
output_137 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      if (operands[2] == const1_rtx)
        return "inc{l}\t%0";
      else if (operands[2] == constm1_rtx)
        return "dec{l}\t%0";
      else
	abort();

    default:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
        {
          operands[2] = GEN_INT (-INTVAL (operands[2]));
          return "sub{l}\t{%2, %0|%0, %2}";
        }
      return "add{l}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_138 PARAMS ((rtx *, rtx));

static const char *
output_138 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == constm1_rtx)
        return "inc{l}\t%0";
      else if (operands[2] == const1_rtx)
        return "dec{l}\t%0";
      else
	abort();

    default:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if ((INTVAL (operands[2]) == -128
	   || (INTVAL (operands[2]) > 0
	       && INTVAL (operands[2]) != 128)))
	return "sub{l}\t{%2, %0|%0, %2}";
      operands[2] = GEN_INT (-INTVAL (operands[2]));
      return "add{l}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_139 PARAMS ((rtx *, rtx));

static const char *
output_139 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      if (operands[2] == const1_rtx)
        return "inc{l}\t%0";
      else if (operands[2] == constm1_rtx)
        return "dec{l}\t%0";
      else
	abort();

    default:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
        {
          operands[2] = GEN_INT (-INTVAL (operands[2]));
          return "sub{l}\t{%2, %0|%0, %2}";
        }
      return "add{l}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_140 PARAMS ((rtx *, rtx));

static const char *
output_140 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_LEA:
      return "#";
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return "inc{w}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 65535))
	return "dec{w}\t%0";
      abort();

    default:
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  return "sub{w}\t{%2, %0|%0, %2}";
	}
      return "add{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_141 PARAMS ((rtx *, rtx));

static const char *
output_141 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return "inc{w}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 65535))
	return "dec{w}\t%0";
      abort();

    default:
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  return "sub{w}\t{%2, %0|%0, %2}";
	}
      return "add{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_142 PARAMS ((rtx *, rtx));

static const char *
output_142 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return "inc{w}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 65535))
	return "dec{w}\t%0";
      abort();

    default:
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  return "sub{w}\t{%2, %0|%0, %2}";
	}
      return "add{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_143 PARAMS ((rtx *, rtx));

static const char *
output_143 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return "inc{w}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 65535))
	return "dec{w}\t%0";
      abort();

    default:
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  return "sub{w}\t{%2, %0|%0, %2}";
	}
      return "add{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_144 PARAMS ((rtx *, rtx));

static const char *
output_144 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == constm1_rtx
	  || (GET_CODE (operands[2]) == CONST_INT
	      && INTVAL (operands[2]) == 65535))
        return "inc{w}\t%0";
      else if (operands[2] == const1_rtx)
        return "dec{w}\t%0";
      else
	abort();

    default:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if ((INTVAL (operands[2]) == -128
	   || (INTVAL (operands[2]) > 0
	       && INTVAL (operands[2]) != 128)))
	return "sub{w}\t{%2, %0|%0, %2}";
      operands[2] = GEN_INT (-INTVAL (operands[2]));
      return "add{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_145 PARAMS ((rtx *, rtx));

static const char *
output_145 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return "inc{w}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 65535))
	return "dec{w}\t%0";
      abort();

    default:
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  return "sub{w}\t{%2, %0|%0, %2}";
	}
      return "add{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_146 PARAMS ((rtx *, rtx));

static const char *
output_146 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  int widen = (which_alternative == 2);
  switch (get_attr_type (insn))
    {
    case TYPE_LEA:
      return "#";
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return widen ? "inc{l}\t%k0" : "inc{b}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 255))
	return widen ? "dec{l}\t%k0" : "dec{b}\t%0";
      abort();

    default:
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  if (widen)
	    return "sub{l}\t{%2, %k0|%k0, %2}";
	  else
	    return "sub{b}\t{%2, %0|%0, %2}";
	}
      if (widen)
        return "add{l}\t{%k2, %k0|%k0, %k2}";
      else
        return "add{b}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_147 PARAMS ((rtx *, rtx));

static const char *
output_147 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  int widen = (which_alternative == 2);
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return widen ? "inc{l}\t%k0" : "inc{b}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 255))
	return widen ? "dec{l}\t%k0" : "dec{b}\t%0";
      abort();

    default:
      /* Make things pretty and `subl $4,%eax' rather than `addl $-4, %eax'.
	 Exceptions: -128 encodes smaller than 128, so swap sign and op.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
		  && INTVAL (operands[2]) != -128)))
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  if (widen)
	    return "sub{l}\t{%2, %k0|%k0, %2}";
	  else
	    return "sub{b}\t{%2, %0|%0, %2}";
	}
      if (widen)
        return "add{l}\t{%k2, %k0|%k0, %k2}";
      else
        return "add{b}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_148 PARAMS ((rtx *, rtx));

static const char *
output_148 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return "inc{b}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 255))
	return "dec{b}\t%0";
      abort();

    default:
      /* Make things pretty and `subb $4,%al' rather than `addb $-4, %al'.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && INTVAL (operands[2]) < 0)
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  return "sub{b}\t{%2, %0|%0, %2}";
	}
      return "add{b}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_149 PARAMS ((rtx *, rtx));

static const char *
output_149 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return "inc{b}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 255))
	return "dec{b}\t%0";
      abort();

    default:
      /* Make things pretty and `subb $4,%al' rather than `addb $-4, %al'.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && INTVAL (operands[2]) < 0)
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  return "sub{b}\t{%2, %0|%0, %2}";
	}
      return "add{b}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_150 PARAMS ((rtx *, rtx));

static const char *
output_150 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == constm1_rtx
	  || (GET_CODE (operands[2]) == CONST_INT
	      && INTVAL (operands[2]) == 255))
        return "inc{b}\t%0";
      else if (operands[2] == const1_rtx)
        return "dec{b}\t%0";
      else
	abort();

    default:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      if (INTVAL (operands[2]) < 0)
        {
          operands[2] = GEN_INT (-INTVAL (operands[2]));
          return "add{b}\t{%2, %0|%0, %2}";
        }
      return "sub{b}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_151 PARAMS ((rtx *, rtx));

static const char *
output_151 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return "inc{b}\t%0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 255))
	return "dec{b}\t%0";
      abort();

    default:
      /* Make things pretty and `subb $4,%al' rather than `addb $-4, %al'.  */
      if (GET_CODE (operands[2]) == CONST_INT
          && INTVAL (operands[2]) < 0)
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  return "sub{b}\t{%2, %0|%0, %2}";
	}
      return "add{b}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_152 PARAMS ((rtx *, rtx));

static const char *
output_152 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_INCDEC:
      if (operands[2] == const1_rtx)
	return "inc{b}\t%h0";
      else if (operands[2] == constm1_rtx
	       || (GET_CODE (operands[2]) == CONST_INT
		   && INTVAL (operands[2]) == 255))
	return "dec{b}\t%h0";
      abort();

    default:
      return "add{b}\t{%2, %h0|%h0, %2}";
    }
}
}

static const char * const output_165[] = {
  "imul{l}\t{%2, %1, %0|%0, %1, %2}",
  "imul{l}\t{%2, %1, %0|%0, %1, %2}",
  "imul{l}\t{%2, %0|%0, %2}",
};

static const char * const output_166[] = {
  "imul{w}\t{%2, %1, %0|%0, %1, %2}",
  "imul{w}\t{%2, %1, %0|%0, %1, %2}",
  "imul{w}\t{%2, %0|%0, %2}",
};

static const char *output_185 PARAMS ((rtx *, rtx));

static const char *
output_185 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (which_alternative == 3)
    {
      if (GET_CODE (operands[1]) == CONST_INT
	  && (INTVAL (operands[1]) & 0xffffff00))
	operands[1] = GEN_INT (INTVAL (operands[1]) & 0xff);
      return "test{l}\t{%1, %k0|%k0, %1}";
    }
  return "test{b}\t{%1, %0|%0, %1}";
}
}

static const char *output_190 PARAMS ((rtx *, rtx));

static const char *
output_190 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_IMOVX:
      {
	enum machine_mode mode;

	if (GET_CODE (operands[2]) != CONST_INT)
	  abort ();
        if (INTVAL (operands[2]) == 0xff)
	  mode = QImode;
	else if (INTVAL (operands[2]) == 0xffff)
	  mode = HImode;
	else
	  abort ();
	
	operands[1] = gen_lowpart (mode, operands[1]);
	if (mode == QImode)
	  return "movz{bl|x}\t{%1,%0|%0, %1}";
	else
	  return "movz{wl|x}\t{%1,%0|%0, %1}";
      }

    default:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();
      return "and{l}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_192 PARAMS ((rtx *, rtx));

static const char *
output_192 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_IMOVX:
      if (GET_CODE (operands[2]) != CONST_INT)
	abort ();
      if (INTVAL (operands[2]) == 0xff)
	return "movz{bl|x}\t{%b1, %k0|%k0, %b1}";
      abort ();

    default:
      if (! rtx_equal_p (operands[0], operands[1]))
	abort ();

      return "and{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char * const output_194[] = {
  "and{b}\t{%2, %0|%0, %2}",
  "and{b}\t{%2, %0|%0, %2}",
  "and{l}\t{%k2, %k0|%k0, %k2}",
};

static const char *output_196 PARAMS ((rtx *, rtx));

static const char *
output_196 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (which_alternative == 2)
    {
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) & 0xffffff00))
        operands[2] = GEN_INT (INTVAL (operands[2]) & 0xff);
      return "and{l}\t{%2, %k0|%k0, %2}";
    }
  return "and{b}\t{%2, %0|%0, %2}";
}
}

static const char * const output_208[] = {
  "or{b}\t{%2, %0|%0, %2}",
  "or{b}\t{%2, %0|%0, %2}",
  "or{l}\t{%k2, %k0|%k0, %k2}",
};

static const char * const output_219[] = {
  "xor{b}\t{%2, %0|%0, %2}",
  "xor{b}\t{%2, %0|%0, %2}",
  "xor{l}\t{%k2, %k0|%k0, %k2}",
};

static const char * const output_261[] = {
  "not{b}\t%0",
  "not{l}\t%k0",
};

static const char * const output_265[] = {
  "shld{l}\t{%2, %1, %0|%0, %1, %2}",
  "shld{l}\t{%s2%1, %0|%0, %1, %2}",
};

static const char *output_266 PARAMS ((rtx *, rtx));

static const char *
output_266 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_ALU:
      if (operands[2] != const1_rtx)
	abort ();
      if (!rtx_equal_p (operands[0], operands[1]))
	abort ();
      return "add{l}\t{%0, %0|%0, %0}";

    case TYPE_LEA:
      if (GET_CODE (operands[2]) != CONST_INT
	  || (unsigned HOST_WIDE_INT) INTVAL (operands[2]) > 3)
	abort ();
      operands[1] = gen_rtx_MULT (SImode, operands[1],
				  GEN_INT (1 << INTVAL (operands[2])));
      return "lea{l}\t{%a1, %0|%0, %a1}";

    default:
      if (REG_P (operands[2]))
	return "sal{l}\t{%b2, %0|%0, %b2}";
      else if (GET_CODE (operands[2]) == CONST_INT
	       && INTVAL (operands[2]) == 1
	       && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
	return "sal{l}\t%0";
      else
	return "sal{l}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_267 PARAMS ((rtx *, rtx));

static const char *
output_267 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_ALU:
      if (operands[2] != const1_rtx)
	abort ();
      return "add{l}\t{%0, %0|%0, %0}";

    default:
      if (REG_P (operands[2]))
	return "sal{l}\t{%b2, %0|%0, %b2}";
      else if (GET_CODE (operands[2]) == CONST_INT
	       && INTVAL (operands[2]) == 1
	       && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
	return "sal{l}\t%0";
      else
	return "sal{l}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_268 PARAMS ((rtx *, rtx));

static const char *
output_268 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_LEA:
      return "#";
    case TYPE_ALU:
      if (operands[2] != const1_rtx)
	abort ();
      return "add{w}\t{%0, %0|%0, %0}";

    default:
      if (REG_P (operands[2]))
	return "sal{w}\t{%b2, %0|%0, %b2}";
      else if (GET_CODE (operands[2]) == CONST_INT
	       && INTVAL (operands[2]) == 1
	       && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
	return "sal{w}\t%0";
      else
	return "sal{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_269 PARAMS ((rtx *, rtx));

static const char *
output_269 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_ALU:
      if (operands[2] != const1_rtx)
	abort ();
      return "add{w}\t{%0, %0|%0, %0}";

    default:
      if (REG_P (operands[2]))
	return "sal{w}\t{%b2, %0|%0, %b2}";
      else if (GET_CODE (operands[2]) == CONST_INT
	       && INTVAL (operands[2]) == 1
	       && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
	return "sal{w}\t%0";
      else
	return "sal{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_270 PARAMS ((rtx *, rtx));

static const char *
output_270 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_ALU:
      if (operands[2] != const1_rtx)
	abort ();
      return "add{w}\t{%0, %0|%0, %0}";

    default:
      if (REG_P (operands[2]))
	return "sal{w}\t{%b2, %0|%0, %b2}";
      else if (GET_CODE (operands[2]) == CONST_INT
	       && INTVAL (operands[2]) == 1
	       && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
	return "sal{w}\t%0";
      else
	return "sal{w}\t{%2, %0|%0, %2}";
    }
}
}

static const char *output_271 PARAMS ((rtx *, rtx));

static const char *
output_271 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_LEA:
      return "#";
    case TYPE_ALU:
      if (operands[2] != const1_rtx)
	abort ();
      if (NON_QI_REG_P (operands[1]))
        return "add{l}\t{%k0, %k0|%k0, %k0}";
      else
        return "add{b}\t{%0, %0|%0, %0}";

    default:
      if (REG_P (operands[2]))
	{
	  if (get_attr_mode (insn) == MODE_SI)
	    return "sal{l}\t{%b2, %k0|%k0, %b2}";
	  else
	    return "sal{b}\t{%b2, %0|%0, %b2}";
	}
      else if (GET_CODE (operands[2]) == CONST_INT
	       && INTVAL (operands[2]) == 1
	       && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
	{
	  if (get_attr_mode (insn) == MODE_SI)
	    return "sal{l}\t%0";
	  else
	    return "sal{b}\t%0";
	}
      else
	{
	  if (get_attr_mode (insn) == MODE_SI)
	    return "sal{l}\t{%2, %k0|%k0, %2}";
	  else
	    return "sal{b}\t{%2, %0|%0, %2}";
	}
    }
}
}

static const char *output_272 PARAMS ((rtx *, rtx));

static const char *
output_272 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_ALU:
      if (operands[2] != const1_rtx)
	abort ();
      if (NON_QI_REG_P (operands[1]))
        return "add{l}\t{%k0, %k0|%k0, %k0}";
      else
        return "add{b}\t{%0, %0|%0, %0}";

    default:
      if (REG_P (operands[2]))
	{
          if (NON_QI_REG_P (operands[1]))
	    return "sal{l}\t{%b2, %k0|%k0, %b2}";
	  else
	    return "sal{b}\t{%b2, %0|%0, %b2}";
	}
      else if (GET_CODE (operands[2]) == CONST_INT
	       && INTVAL (operands[2]) == 1
	       && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
	{
          if (NON_QI_REG_P (operands[1]))
	    return "sal{l}\t%0";
	  else
	    return "sal{b}\t%0";
	}
      else
	{
          if (NON_QI_REG_P (operands[1]))
	    return "sal{l}\t{%2, %k0|%k0, %2}";
	  else
	    return "sal{b}\t{%2, %0|%0, %2}";
	}
    }
}
}

static const char *output_273 PARAMS ((rtx *, rtx));

static const char *
output_273 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_ALU:
      if (operands[2] != const1_rtx)
	abort ();
      return "add{b}\t{%0, %0|%0, %0}";

    default:
      if (REG_P (operands[2]))
	return "sal{b}\t{%b2, %0|%0, %b2}";
      else if (GET_CODE (operands[2]) == CONST_INT
	       && INTVAL (operands[2]) == 1
	       && (TARGET_PENTIUM || TARGET_PENTIUMPRO))
	return "sal{b}\t%0";
      else
	return "sal{b}\t{%2, %0|%0, %2}";
    }
}
}

static const char * const output_276[] = {
  "shrd{l}\t{%2, %1, %0|%0, %1, %2}",
  "shrd{l}\t{%s2%1, %0|%0, %1, %2}",
};

static const char * const output_277[] = {
  "{cltd|cdq}",
  "sar{l}\t{%2, %0|%0, %2}",
};

static const char * const output_279[] = {
  "sar{l}\t{%2, %0|%0, %2}",
  "sar{l}\t{%b2, %0|%0, %b2}",
};

static const char * const output_283[] = {
  "sar{w}\t{%2, %0|%0, %2}",
  "sar{w}\t{%b2, %0|%0, %b2}",
};

static const char * const output_287[] = {
  "sar{b}\t{%2, %0|%0, %2}",
  "sar{b}\t{%b2, %0|%0, %b2}",
};

static const char * const output_293[] = {
  "shr{l}\t{%2, %0|%0, %2}",
  "shr{l}\t{%b2, %0|%0, %b2}",
};

static const char * const output_297[] = {
  "shr{w}\t{%2, %0|%0, %2}",
  "shr{w}\t{%b2, %0|%0, %b2}",
};

static const char * const output_301[] = {
  "shr{b}\t{%2, %0|%0, %2}",
  "shr{b}\t{%b2, %0|%0, %b2}",
};

static const char * const output_305[] = {
  "rol{l}\t{%2, %0|%0, %2}",
  "rol{l}\t{%b2, %0|%0, %b2}",
};

static const char * const output_307[] = {
  "rol{w}\t{%2, %0|%0, %2}",
  "rol{w}\t{%b2, %0|%0, %b2}",
};

static const char * const output_309[] = {
  "rol{b}\t{%2, %0|%0, %2}",
  "rol{b}\t{%b2, %0|%0, %b2}",
};

static const char * const output_311[] = {
  "ror{l}\t{%2, %0|%0, %2}",
  "ror{l}\t{%b2, %0|%0, %b2}",
};

static const char * const output_313[] = {
  "ror{w}\t{%2, %0|%0, %2}",
  "ror{w}\t{%b2, %0|%0, %b2}",
};

static const char * const output_315[] = {
  "ror{b}\t{%2, %0|%0, %2}",
  "ror{b}\t{%b2, %0|%0, %b2}",
};

static const char *output_330 PARAMS ((rtx *, rtx));

static const char *
output_330 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (which_alternative != 0)
    return "#";
  if (get_attr_length (insn) == 2)
    return "loop\t%l0";
  else
    return "dec{l}\t%1\n\tjne\t%l0";
}
}

static const char *output_331 PARAMS ((rtx *, rtx));

static const char *
output_331 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (SIBLING_CALL_P (insn))
    return "jmp\t%P0";
  else
    return "call\t%P0";
}
}

static const char *output_332 PARAMS ((rtx *, rtx));

static const char *
output_332 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (constant_call_address_operand (operands[0], Pmode))
    {
      if (SIBLING_CALL_P (insn))
	return "jmp\t%P0";
      else
	return "call\t%P0";
    }
  if (SIBLING_CALL_P (insn))
    return "jmp\t%A0";
  else
    return "call\t%A0";
}
}

static const char *output_333 PARAMS ((rtx *, rtx));

static const char *
output_333 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (SIBLING_CALL_P (insn))
    return "jmp\t%P0";
  else
    return "call\t%P0";
}
}

static const char *output_334 PARAMS ((rtx *, rtx));

static const char *
output_334 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (constant_call_address_operand (operands[0], QImode))
    {
      if (SIBLING_CALL_P (insn))
	return "jmp\t%P0";
      else
	return "call\t%P0";
    }
  if (SIBLING_CALL_P (insn))
    return "jmp\t%A0";
  else
    return "call\t%A0";
}
}

static const char *output_340 PARAMS ((rtx *, rtx));

static const char *
output_340 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (GET_CODE (operands[2]) == LABEL_REF)
     operands[2] = XEXP (operands[2], 0);
  if (TARGET_DEEP_BRANCH_PREDICTION) 
    return "add{l}\t{%1, %0|%0, %1}";
  else  
    return "add{l}\t{%1+[.-%X2], %0|%0, %a1+(.-%X2)}";
}
}

static const char *output_341 PARAMS ((rtx *, rtx));

static const char *
output_341 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (GET_CODE (operands[1]) == LABEL_REF)
    operands[1] = XEXP (operands[1], 0);
  output_asm_insn ("call\t%X1", operands);
  if (! TARGET_DEEP_BRANCH_PREDICTION)
    {
      ASM_OUTPUT_INTERNAL_LABEL (asm_out_file, "L",
				 CODE_LABEL_NUMBER (operands[1]));
    }
  RET;
}
}

static const char *output_345 PARAMS ((rtx *, rtx));

static const char *
output_345 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_346 PARAMS ((rtx *, rtx));

static const char *
output_346 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_347 PARAMS ((rtx *, rtx));

static const char *
output_347 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_348 PARAMS ((rtx *, rtx));

static const char *
output_348 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_349 PARAMS ((rtx *, rtx));

static const char *
output_349 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_350 PARAMS ((rtx *, rtx));

static const char *
output_350 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return which_alternative ? "#" : output_387_binary_op (insn, operands);
}

static const char *output_351 PARAMS ((rtx *, rtx));

static const char *
output_351 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return which_alternative ? "#" : output_387_binary_op (insn, operands);
}

static const char *output_352 PARAMS ((rtx *, rtx));

static const char *
output_352 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_353 PARAMS ((rtx *, rtx));

static const char *
output_353 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return which_alternative ? "#" : output_387_binary_op (insn, operands);
}

static const char *output_354 PARAMS ((rtx *, rtx));

static const char *
output_354 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return which_alternative ? "#" : output_387_binary_op (insn, operands);
}

static const char *output_355 PARAMS ((rtx *, rtx));

static const char *
output_355 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_356 PARAMS ((rtx *, rtx));

static const char *
output_356 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_357 PARAMS ((rtx *, rtx));

static const char *
output_357 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_358 PARAMS ((rtx *, rtx));

static const char *
output_358 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_359 PARAMS ((rtx *, rtx));

static const char *
output_359 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return which_alternative ? "#" : output_387_binary_op (insn, operands);
}

static const char *output_360 PARAMS ((rtx *, rtx));

static const char *
output_360 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return which_alternative ? "#" : output_387_binary_op (insn, operands);
}

static const char *output_361 PARAMS ((rtx *, rtx));

static const char *
output_361 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return which_alternative ? "#" : output_387_binary_op (insn, operands);
}

static const char *output_362 PARAMS ((rtx *, rtx));

static const char *
output_362 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return which_alternative ? "#" : output_387_binary_op (insn, operands);
}

static const char *output_363 PARAMS ((rtx *, rtx));

static const char *
output_363 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_364 PARAMS ((rtx *, rtx));

static const char *
output_364 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_365 PARAMS ((rtx *, rtx));

static const char *
output_365 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_366 PARAMS ((rtx *, rtx));

static const char *
output_366 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_367 PARAMS ((rtx *, rtx));

static const char *
output_367 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_368 PARAMS ((rtx *, rtx));

static const char *
output_368 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_369 PARAMS ((rtx *, rtx));

static const char *
output_369 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char *output_370 PARAMS ((rtx *, rtx));

static const char *
output_370 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{
 return output_387_binary_op (insn, operands);
}

static const char * const output_405[] = {
  "cmov%C1\t{%2, %0|%0, %2}",
  "cmov%c1\t{%3, %0|%0, %3}",
};

static const char * const output_406[] = {
  "cmov%C1\t{%2, %0|%0, %2}",
  "cmov%c1\t{%3, %0|%0, %3}",
};

static const char * const output_407[] = {
  "fcmov%F1\t{%2, %0|%0, %2}",
  "fcmov%f1\t{%3, %0|%0, %3}",
};

static const char * const output_408[] = {
  "fcmov%F1\t{%2, %0|%0, %2}",
  "fcmov%f1\t{%3, %0|%0, %3}",
};

static const char * const output_409[] = {
  "fcmov%F1\t{%2, %0|%0, %2}",
  "fcmov%f1\t{%3, %0|%0, %3}",
};

static const char * const output_410[] = {
  "fcmov%F1\t{%2, %0|%0, %2}",
  "fcmov%f1\t{%3, %0|%0, %3}",
};

static const char *output_411 PARAMS ((rtx *, rtx));

static const char *
output_411 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (get_attr_type (insn))
    {
    case TYPE_IMOV:
      return "mov{l}\t{%1, %0|%0, %1}";

    case TYPE_ALU:
      if (GET_CODE (operands[2]) == CONST_INT
          && (INTVAL (operands[2]) == 128
	      || (INTVAL (operands[2]) < 0
	          && INTVAL (operands[2]) != -128)))
	{
	  operands[2] = GEN_INT (-INTVAL (operands[2]));
	  return "sub{l}\t{%2, %0|%0, %2}";
	}
      return "add{l}\t{%2, %0|%0, %2}";

    case TYPE_LEA:
      operands[2] = SET_SRC (XVECEXP (PATTERN (insn), 0, 0));
      return "lea{l}\t{%a2, %0|%0, %a2}";

    default:
      abort ();
    }
}
}

static const char *output_413 PARAMS ((rtx *, rtx));

static const char *
output_413 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (SIBLING_CALL_P (insn))
    return "jmp\t%P1";
  else
    return "call\t%P1";
}
}

static const char *output_414 PARAMS ((rtx *, rtx));

static const char *
output_414 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (constant_call_address_operand (operands[1], QImode))
    {
      if (SIBLING_CALL_P (insn))
	return "jmp\t%P1";
      else
	return "call\t%P1";
    }
  if (SIBLING_CALL_P (insn))
    return "jmp\t%A1";
  else
    return "call\t%A1";
}
}

static const char *output_415 PARAMS ((rtx *, rtx));

static const char *
output_415 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (SIBLING_CALL_P (insn))
    return "jmp\t%P1";
  else
    return "call\t%P1";
}
}

static const char *output_416 PARAMS ((rtx *, rtx));

static const char *
output_416 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  if (constant_call_address_operand (operands[1], QImode))
    {
      if (SIBLING_CALL_P (insn))
	return "jmp\t%P1";
      else
	return "call\t%P1";
    }
  if (SIBLING_CALL_P (insn))
    return "jmp\t%A1";
  else
    return "call\t%A1";
}
}

static const char *output_418 PARAMS ((rtx *, rtx));

static const char *
output_418 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  operands[2] = gen_label_rtx ();
  output_asm_insn ("j%c0\t%l2\n\t int\t%1", operands);
  ASM_OUTPUT_INTERNAL_LABEL (asm_out_file, "L",
			     CODE_LABEL_NUMBER (operands[2]));
  RET;
}
}

static const char * const output_430[] = {
  "movaps\t{%1, %0|%0, %1}",
  "movaps\t{%1, %0|%0, %1}",
};

static const char * const output_431[] = {
  "movaps\t{%1, %0|%0, %1}",
  "movaps\t{%1, %0|%0, %1}",
};

static const char * const output_432[] = {
  "movups\t{%1, %0|%0, %1}",
  "movups\t{%1, %0|%0, %1}",
};

static const char *output_465 PARAMS ((rtx *, rtx));

static const char *
output_465 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (GET_CODE (operands[3]))
    {
    case EQ:
      return "cmpeqps\t{%2, %0|%0, %2}";
    case LT:
      return "cmpltps\t{%2, %0|%0, %2}";
    case LE:
      return "cmpleps\t{%2, %0|%0, %2}";
    case UNORDERED:
      return "cmpunordps\t{%2, %0|%0, %2}";
    default:
      abort ();
    }
}
}

static const char *output_466 PARAMS ((rtx *, rtx));

static const char *
output_466 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (GET_CODE (operands[3]))
    {
    case EQ:
      return "cmpneqps\t{%2, %0|%0, %2}";
    case LT:
      return "cmpnltps\t{%2, %0|%0, %2}";
    case LE:
      return "cmpnleps\t{%2, %0|%0, %2}";
    case UNORDERED:
      return "cmpordps\t{%2, %0|%0, %2}";
    default:
      abort ();
    }
}
}

static const char *output_467 PARAMS ((rtx *, rtx));

static const char *
output_467 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (GET_CODE (operands[3]))
    {
    case EQ:
      return "cmpeqss\t{%2, %0|%0, %2}";
    case LT:
      return "cmpltss\t{%2, %0|%0, %2}";
    case LE:
      return "cmpless\t{%2, %0|%0, %2}";
    case UNORDERED:
      return "cmpunordss\t{%2, %0|%0, %2}";
    default:
      abort ();
    }
}
}

static const char *output_468 PARAMS ((rtx *, rtx));

static const char *
output_468 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (GET_CODE (operands[3]))
    {
    case EQ:
      return "cmpneqss\t{%2, %0|%0, %2}";
    case LT:
      return "cmpnltss\t{%2, %0|%0, %2}";
    case LE:
      return "cmpnless\t{%2, %0|%0, %2}";
    case UNORDERED:
      return "cmpordss\t{%2, %0|%0, %2}";
    default:
      abort ();
    }
}
}

static const char *output_543 PARAMS ((rtx *, rtx));

static const char *
output_543 (operands, insn)
     rtx *operands ATTRIBUTE_UNUSED;
     rtx insn ATTRIBUTE_UNUSED;
{

{
  switch (INTVAL (operands[1]))
    {
    case 0:
      return "prefetchnta\t%a0";
    case 1:
      return "prefetcht0\t%a0";
    case 2:
      return "prefetcht1\t%a0";
    case 3:
      return "prefetcht2\t%a0";
    default:
      abort ();
    }
}
}


extern int nonimmediate_operand PARAMS ((rtx, enum machine_mode));
extern int const0_operand PARAMS ((rtx, enum machine_mode));
extern int general_operand PARAMS ((rtx, enum machine_mode));
extern int ext_register_operand PARAMS ((rtx, enum machine_mode));
extern int register_operand PARAMS ((rtx, enum machine_mode));
extern int push_operand PARAMS ((rtx, enum machine_mode));
extern int general_no_elim_operand PARAMS ((rtx, enum machine_mode));
extern int immediate_operand PARAMS ((rtx, enum machine_mode));
extern int nonmemory_no_elim_operand PARAMS ((rtx, enum machine_mode));
extern int q_regs_operand PARAMS ((rtx, enum machine_mode));
extern int scratch_operand PARAMS ((rtx, enum machine_mode));
extern int memory_operand PARAMS ((rtx, enum machine_mode));
extern int address_operand PARAMS ((rtx, enum machine_mode));
extern int const248_operand PARAMS ((rtx, enum machine_mode));
extern int nonmemory_operand PARAMS ((rtx, enum machine_mode));
extern int const_int_operand PARAMS ((rtx, enum machine_mode));
extern int const_int_1_operand PARAMS ((rtx, enum machine_mode));
extern int ix86_comparison_operator PARAMS ((rtx, enum machine_mode));
extern int comparison_operator PARAMS ((rtx, enum machine_mode));
extern int constant_call_address_operand PARAMS ((rtx, enum machine_mode));
extern int call_insn_operand PARAMS ((rtx, enum machine_mode));
extern int symbolic_operand PARAMS ((rtx, enum machine_mode));
extern int binary_fp_operator PARAMS ((rtx, enum machine_mode));
extern int fcmov_comparison_operator PARAMS ((rtx, enum machine_mode));
extern int sse_comparison_operator PARAMS ((rtx, enum machine_mode));
extern int cmpsi_operand PARAMS ((rtx, enum machine_mode));
extern int cmp_fp_expander_operand PARAMS ((rtx, enum machine_mode));
extern int aligned_operand PARAMS ((rtx, enum machine_mode));
extern int promotable_binary_operator PARAMS ((rtx, enum machine_mode));
extern int arith_or_logical_operator PARAMS ((rtx, enum machine_mode));
extern int incdec_operand PARAMS ((rtx, enum machine_mode));



static const struct insn_operand_data operand_data[] = 
{
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "r,?mr",
    SImode,
    0,
    1
  },
  {
    const0_operand,
    "n,n",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm,r",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "ri,mr",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "r,?mr",
    HImode,
    0,
    1
  },
  {
    const0_operand,
    "n,n",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm,r",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "ri,mr",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "q,?mq",
    QImode,
    0,
    1
  },
  {
    const0_operand,
    "n,n",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm,q",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qi,mq",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qm",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "q",
    VOIDmode,
    0,
    1
  },
  {
    const0_operand,
    "n",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "q",
    VOIDmode,
    0,
    1
  },
  {
    general_operand,
    "qmn",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "q",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "q",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    const0_operand,
    "X",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "f,f",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,?r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "a",
    HImode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    SImode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "ri*m",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r*m",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    const0_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=*a,r,*a,m,!*y,!r",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "im,rinm,rinm,rin,r,*y",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "+r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "+r",
    SImode,
    0,
    1
  },
  {
    push_operand,
    "=<,<",
    HImode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "n,r*m",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r*m",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=*a,r,r,*a,r,m",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "i,r,rn,rm,rm,rn",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "+r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "+r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "+rm,r",
    HImode,
    1,
    1
  },
  {
    general_operand,
    "rn,m",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "+r",
    HImode,
    1,
    1
  },
  {
    const0_operand,
    "i",
    HImode,
    0,
    1
  },
  {
    push_operand,
    "=<,<",
    QImode,
    0,
    1
  },
  {
    nonmemory_no_elim_operand,
    "n,r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r*m",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=q,q,q,r,r,?r,m",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "q,qn,qm,q,rn,qm,qn",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "+r",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "+r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "+qm,q",
    QImode,
    1,
    1
  },
  {
    general_operand,
    "*qn,m",
    QImode,
    0,
    1
  },
  {
    q_regs_operand,
    "+q",
    QImode,
    1,
    1
  },
  {
    const0_operand,
    "i",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "q",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "q",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,?r",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "q,q",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    ext_register_operand,
    "q",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,?r",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "q,q",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "+q",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm",
    SImode,
    0,
    1
  },
  {
    ext_register_operand,
    "+q",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "q",
    SImode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    DImode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "riF*m",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,o,!m*y,!*y",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "riFo,riF,*y,m",
    DImode,
    0,
    1
  },
  {
    push_operand,
    "=<,<",
    SFmode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "f#r,rFm#f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f#r,m,f#r,r#f,m",
    SFmode,
    0,
    1
  },
  {
    general_operand,
    "fm#r,f#r,G,rmF#f,Fr#f",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "+f",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "+f",
    SFmode,
    0,
    1
  },
  {
    push_operand,
    "=<,<,<",
    DFmode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "f,Fo#f,*r#f",
    DFmode,
    0,
    1
  },
  {
    push_operand,
    "=<,<",
    DFmode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "f#r,rFo#f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f,m,f,*r,o",
    DFmode,
    0,
    1
  },
  {
    general_operand,
    "fm,f,G,*roF,F*r",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f#r,m,f#r,r#f,o",
    DFmode,
    0,
    1
  },
  {
    general_operand,
    "fm#r,f#r,G,roF#f,Fr#f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "+f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "+f",
    DFmode,
    0,
    1
  },
  {
    push_operand,
    "=<,<,<",
    XFmode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "f,Fo,*r",
    XFmode,
    0,
    1
  },
  {
    push_operand,
    "=<,<,<",
    TFmode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "f,Fo,*r",
    TFmode,
    0,
    1
  },
  {
    push_operand,
    "=<,<",
    XFmode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "f#r,rFo#f",
    XFmode,
    0,
    1
  },
  {
    push_operand,
    "=<,<",
    TFmode,
    0,
    1
  },
  {
    general_no_elim_operand,
    "f#r,rFo#f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f,m,f,*r,o",
    XFmode,
    0,
    1
  },
  {
    general_operand,
    "fm,f,G,*roF,F*r",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f,m,f,*r,o",
    TFmode,
    0,
    1
  },
  {
    general_operand,
    "fm,f,G,*roF,F*r",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f#r,m,f#r,r#f,o",
    XFmode,
    0,
    1
  },
  {
    general_operand,
    "fm#r,f#r,G,roF#f,Fr#f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f#r,m,f#r,r#f,o",
    TFmode,
    0,
    1
  },
  {
    general_operand,
    "fm#r,f#r,G,roF#f,Fr#f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "+f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "+f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "+f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "+f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=r,?&q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,qm",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm,0",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r,?&q",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,qm",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm,0",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,?r,?*o",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "0,rm,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=*A,r,?r,?*o",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "0,0,r,r",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "=X,X,X,&r",
    SImode,
    0,
    0
  },
  {
    register_operand,
    "=*a,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "*0,rm",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=*a,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "*0,qm",
    QImode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "f",
    SFmode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "f",
    SFmode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "f",
    SFmode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "f",
    DFmode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f,m",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f,m",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f,m",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f,m",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f,m",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=m,f",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "f,0",
    DFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m,m",
    SFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=m,f",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "f,0",
    XFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m,m",
    SFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=m,f",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "f,0",
    TFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m,m",
    SFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=m,f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "f,0",
    XFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m,m",
    DFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=m,f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "f,0",
    TFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m,m",
    DFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=m,?r",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "f,f",
    VOIDmode,
    0,
    1
  },
  {
    memory_operand,
    "=o,o",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "=m,m",
    DImode,
    0,
    1
  },
  {
    scratch_operand,
    "=&r,&r",
    SImode,
    0,
    0
  },
  {
    scratch_operand,
    "=&f,&f",
    VOIDmode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "=m,?r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "f,f",
    VOIDmode,
    0,
    1
  },
  {
    memory_operand,
    "=o,o",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "=m,m",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "=&r,r",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "=m,?r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "f,f",
    VOIDmode,
    0,
    1
  },
  {
    memory_operand,
    "=o,o",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "=m,m",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "=&r,r",
    SImode,
    0,
    0
  },
  {
    memory_operand,
    "=m",
    HImode,
    0,
    1
  },
  {
    memory_operand,
    "m",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,r",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,o",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "roiF,riF",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "ri,rm",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qi,qm",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    address_operand,
    "p",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "r",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "r",
    VOIDmode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "r",
    VOIDmode,
    0,
    1
  },
  {
    const248_operand,
    "i",
    VOIDmode,
    0,
    1
  },
  {
    nonmemory_operand,
    "ri",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "r",
    VOIDmode,
    0,
    1
  },
  {
    const248_operand,
    "i",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "r",
    VOIDmode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,rm,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,r",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "rmni,rni,rni",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,rm",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "rmni,rni",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "=r",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "%0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "rmni",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "=rm",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    const_int_operand,
    "n",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,r",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "ri,rm,rni",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "ri,rm",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,rm",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rmni,rni",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "=r",
    HImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "%0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rmni",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "=rm",
    HImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    const_int_operand,
    "n",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,q,r,r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,0,r",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qn,qmn,rn,rn",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,q,r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qn,qmn,rn",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=q,qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qmni,qni",
    QImode,
    0,
    1
  },
  {
    scratch_operand,
    "=q",
    QImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "%0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qmni",
    QImode,
    0,
    1
  },
  {
    scratch_operand,
    "=qm",
    QImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    const_int_operand,
    "n",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "=q",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "0",
    VOIDmode,
    0,
    1
  },
  {
    general_operand,
    "qmn",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "=q",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "%0",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "q",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,o",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "roiF,riF",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "ri,rm",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "ri,rm",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qn,qmn",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,q",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qi,qm",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%rm,0,0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "K,i,mr",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%rm,0,0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "K,i,mr",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "%0",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "%0",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=A",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "%0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=d",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "%a",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "=a",
    SImode,
    0,
    0
  },
  {
    register_operand,
    "=a",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=&a,?a",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=&d,&d",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "1,0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm,rm",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=&d",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "a",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=d",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "3",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=&d",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=&d",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=d",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "3",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%*a,r,rm",
    SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "in,in,rin",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%*a,r,rm",
    HImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "n,n,rn",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%*a,q,qm,r",
    QImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "n,n,qn,n",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "q",
    VOIDmode,
    0,
    1
  },
  {
    const_int_operand,
    "n",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "q",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    VOIDmode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,qm",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "ri,rm,L",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,rm",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "rim,ri",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,qm",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "ri,rm,L",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,rm",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rim,ri",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,q,r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qi,qmi,ri",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "+qm,q",
    QImode,
    1,
    1
  },
  {
    general_operand,
    "qi,qmi",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=q,qm,*r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qim,qi,i",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "+q,qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "qmi,qi",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "=q",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "0",
    VOIDmode,
    0,
    1
  },
  {
    const_int_operand,
    "n",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "=q",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "0",
    VOIDmode,
    0,
    1
  },
  {
    general_operand,
    "qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "ri,rmi",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "=r",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "%0",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "rim",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=r,m",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rmi,ri",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "=r",
    HImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "%0",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "rim",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=q,m,r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qmi,qi,ri",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "+q,m",
    QImode,
    1,
    1
  },
  {
    general_operand,
    "qmi,qi",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=q,qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "%0,0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qim,qi",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "+q,qm",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qim,qi",
    QImode,
    0,
    1
  },
  {
    scratch_operand,
    "=q",
    QImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "%0",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "qim",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "=q",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "0",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "q",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=ro",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "0",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f#r,rm#f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f#r,rm#f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f#r,rm#f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=f#r,rm#f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    DImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "Jc",
    QImode,
    0,
    1
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "+r*m,r*m",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "r,r",
    SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "I,c",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,r",
    SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "cI,M",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "I",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,r",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,r",
    HImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "cI,M",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "cI",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    immediate_operand,
    "I",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,r,r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0,r",
    QImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "cI,cI,M",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,r",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    QImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "cI,cI",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    immediate_operand,
    "I",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=*d,rm",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "*a,0",
    SImode,
    0,
    1
  },
  {
    const_int_operand,
    "i,i",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    const_int_1_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,rm",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "I,c",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    HImode,
    0,
    1
  },
  {
    const_int_1_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm,rm",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    HImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "I,c",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    const_int_1_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm,qm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    QImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "I,c",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    const_int_1_operand,
    "I",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=rm",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0",
    QImode,
    0,
    1
  },
  {
    immediate_operand,
    "I",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=qm",
    QImode,
    0,
    1
  },
  {
    ix86_comparison_operator,
    "",
    QImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "+qm",
    QImode,
    1,
    1
  },
  {
    ix86_comparison_operator,
    "",
    QImode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    ix86_comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    scratch_operand,
    "=a",
    HImode,
    0,
    0
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    scratch_operand,
    "=a",
    HImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "rm",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "c,?*r,?*r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=1,1,*m*r",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "=X,X,r",
    SImode,
    0,
    0
  },
  {
    constant_call_address_operand,
    "",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    call_insn_operand,
    "rsm",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    symbolic_operand,
    "",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "c",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=f",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "%0",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm",
    SFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    SFmode,
    0,
    0
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "%0",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm",
    DFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    DFmode,
    0,
    0
  },
  {
    register_operand,
    "=f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "%0",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    XFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    XFmode,
    0,
    0
  },
  {
    register_operand,
    "=f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "%0",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "f",
    TFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    TFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,fm",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    SFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    SFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,?r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    SFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    SFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,?r",
    SImode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    SFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,fm",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    DFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    DFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,?r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    DFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    DFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,?r",
    SImode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    DFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    DFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    DFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    SFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    DFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "f,0",
    XFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    XFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "f,0",
    TFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    TFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,?r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    XFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    XFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,?r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    TFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    TFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,?r",
    SImode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    XFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "0,0",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,?r",
    SImode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    TFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    XFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    XFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    TFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    TFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    SFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    XFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    SFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    TFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    XFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    XFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    TFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    TFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    DFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    XFmode,
    0,
    0
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "fm,0",
    DFmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    TFmode,
    0,
    0
  },
  {
    register_operand,
    "=D",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=S",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "1",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=D",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=S",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=c",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "1",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "2",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=D",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "a",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=D",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "a",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=D",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "a",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=D",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=c",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "a",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "1",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=D",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=c",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "a",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "1",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=S",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=D",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=c",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "1",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "2",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=&c",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=D",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "a",
    QImode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "0",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "1",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    1
  },
  {
    ix86_comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "rm,0",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,rm",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    1
  },
  {
    ix86_comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "rm,0",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,rm",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    SFmode,
    0,
    1
  },
  {
    fcmov_comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "f,0",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    DFmode,
    0,
    1
  },
  {
    fcmov_comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "f,0",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    XFmode,
    0,
    1
  },
  {
    fcmov_comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "f,0",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "=f,f",
    TFmode,
    0,
    1
  },
  {
    fcmov_comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "f,0",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "0,f",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "0,r",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "i,i",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    constant_call_address_operand,
    "",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    call_insn_operand,
    "rsm",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    const_int_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=x,m",
    V4SFmode,
    0,
    1
  },
  {
    general_operand,
    "xm,x",
    V4SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=x,m",
    V4SImode,
    0,
    1
  },
  {
    general_operand,
    "xm,x",
    V4SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=y,m",
    V8QImode,
    0,
    1
  },
  {
    general_operand,
    "ym,y",
    V8QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=y,m",
    V4HImode,
    0,
    1
  },
  {
    general_operand,
    "ym,y",
    V4HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=y,m",
    V2SImode,
    0,
    1
  },
  {
    general_operand,
    "ym,y",
    V2SImode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    TImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "x",
    TImode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    V4SFmode,
    0,
    1
  },
  {
    nonmemory_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    V4SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "x",
    V4SImode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    V2SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "y",
    V2SImode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    V4HImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "y",
    V4HImode,
    0,
    1
  },
  {
    push_operand,
    "=<",
    V8QImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "y",
    V8QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=x,m",
    TImode,
    0,
    1
  },
  {
    general_operand,
    "xm,x",
    TImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    V8QImode,
    0,
    1
  },
  {
    register_operand,
    "D",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    V8QImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    V8QImode,
    0,
    1
  },
  {
    memory_operand,
    "=m",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "=x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "=x,m",
    V4SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "0,0",
    V4SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "m,x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "=x",
    V4SFmode,
    0,
    1
  },
  {
    memory_operand,
    "m",
    V4SFmode,
    0,
    1
  },
  {
    memory_operand,
    "=m",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "=x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "xm",
    V4SFmode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "xm",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "=x",
    TImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    TImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "xm",
    TImode,
    0,
    1
  },
  {
    register_operand,
    "=x",
    V4SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    sse_comparison_operator,
    "",
    V4SImode,
    0,
    0
  },
  {
    register_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    sse_comparison_operator,
    "",
    CCFPmode,
    0,
    0
  },
  {
    register_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "x",
    V4SFmode,
    0,
    1
  },
  {
    sse_comparison_operator,
    "",
    CCFPUmode,
    0,
    0
  },
  {
    register_operand,
    "=x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "x",
    V8QImode,
    0,
    1
  },
  {
    register_operand,
    "=x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "ym",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "xm",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "=x",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "rm",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "xm",
    V4SFmode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V8QImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V8QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "ym",
    V8QImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "ym",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V2SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "ym",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "ym",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "ym",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "rm",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    V4HImode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "ym",
    V4HImode,
    0,
    1
  },
  {
    immediate_operand,
    "i",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4HImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "yi",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V2SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "yi",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    DImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "yi",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V8QImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V8QImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V8QImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    V8QImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    V4HImode,
    0,
    1
  },
  {
    register_operand,
    "=y",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "0",
    V2SImode,
    0,
    1
  },
  {
    register_operand,
    "y",
    V2SImode,
    0,
    1
  },
  {
    memory_operand,
    "m",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "=m",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    BLKmode,
    0,
    1
  },
  {
    address_operand,
    "p",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "n",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "",
    DImode,
    0,
    1
  },
  {
    cmpsi_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "",
    QImode,
    0,
    1
  },
  {
    cmp_fp_expander_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    cmp_fp_expander_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    cmp_fp_expander_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    cmp_fp_expander_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    cmp_fp_expander_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    cmp_fp_expander_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    cmp_fp_expander_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    cmp_fp_expander_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    1,
    1
  },
  {
    general_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "",
    QImode,
    0,
    1
  },
  {
    0,
    "=m",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "r",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "=&q",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    QImode,
    1,
    1
  },
  {
    general_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "",
    DImode,
    0,
    1
  },
  {
    push_operand,
    "",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    general_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    general_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    general_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    general_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    general_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    general_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    push_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    general_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    push_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    XFmode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    TFmode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    DFmode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SFmode,
    0,
    0
  },
  {
    register_operand,
    "",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    DImode,
    0,
    1
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    VOIDmode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DImode,
    0,
    1
  },
  {
    general_operand,
    "",
    DImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    const248_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    const248_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    general_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    QImode,
    0,
    1
  },
  {
    ext_register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    q_regs_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    ext_register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    general_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DImode,
    0,
    1
  },
  {
    register_operand,
    "",
    DImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    QImode,
    0,
    1
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    ext_register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    scratch_operand,
    "=a",
    HImode,
    0,
    0
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "",
    SImode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    ix86_comparison_operator,
    "",
    QImode,
    0,
    0
  },
  {
    q_regs_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    QImode,
    0,
    1
  },
  {
    0,
    "",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    1
  },
  {
    0,
    "",
    QImode,
    0,
    1
  },
  {
    0,
    "",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    binary_fp_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    memory_operand,
    "",
    BLKmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    BLKmode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    BLKmode,
    0,
    1
  },
  {
    general_operand,
    "",
    BLKmode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    BLKmode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    nonimmediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    XFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "",
    TFmode,
    0,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    aligned_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    promotable_binary_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    aligned_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    const_int_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    0
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    1
  },
  {
    push_operand,
    "",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "r",
    SImode,
    0,
    0
  },
  {
    push_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SFmode,
    0,
    1
  },
  {
    scratch_operand,
    "r",
    SFmode,
    0,
    0
  },
  {
    push_operand,
    "",
    HImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "r",
    HImode,
    0,
    0
  },
  {
    push_operand,
    "",
    QImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    QImode,
    0,
    1
  },
  {
    scratch_operand,
    "q",
    QImode,
    0,
    0
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "r",
    SImode,
    0,
    0
  },
  {
    memory_operand,
    "",
    HImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    HImode,
    0,
    1
  },
  {
    scratch_operand,
    "r",
    HImode,
    0,
    0
  },
  {
    memory_operand,
    "",
    QImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    scratch_operand,
    "q",
    QImode,
    0,
    0
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0
  },
  {
    scratch_operand,
    "r",
    SImode,
    0,
    0
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    immediate_operand,
    "",
    QImode,
    0,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "r",
    SImode,
    0,
    0
  },
  {
    arith_or_logical_operator,
    "",
    SImode,
    0,
    0
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "r",
    SImode,
    0,
    0
  },
  {
    arith_or_logical_operator,
    "",
    SImode,
    0,
    0
  },
  {
    register_operand,
    "",
    VOIDmode,
    1,
    1
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    SImode,
    0,
    1
  },
  {
    scratch_operand,
    "r",
    SImode,
    0,
    0
  },
  {
    scratch_operand,
    "r",
    SImode,
    0,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    1
  },
  {
    incdec_operand,
    "",
    SImode,
    0,
    1
  },
  {
    register_operand,
    "",
    HImode,
    0,
    1
  },
  {
    incdec_operand,
    "",
    HImode,
    0,
    1
  },
  {
    register_operand,
    "",
    QImode,
    0,
    1
  },
  {
    incdec_operand,
    "",
    QImode,
    0,
    1
  },
  {
    general_operand,
    "",
    TImode,
    0,
    1
  },
  {
    general_operand,
    "",
    TImode,
    0,
    1
  },
  {
    general_operand,
    "",
    V4SFmode,
    0,
    1
  },
  {
    general_operand,
    "",
    V4SFmode,
    0,
    1
  },
  {
    general_operand,
    "",
    V4SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    V4SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    V2SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    V2SImode,
    0,
    1
  },
  {
    general_operand,
    "",
    V4HImode,
    0,
    1
  },
  {
    general_operand,
    "",
    V4HImode,
    0,
    1
  },
  {
    general_operand,
    "",
    V8QImode,
    0,
    1
  },
  {
    general_operand,
    "",
    V8QImode,
    0,
    1
  },
  {
    push_operand,
    "",
    TImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    TImode,
    0,
    1
  },
  {
    push_operand,
    "",
    V4SFmode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    V4SFmode,
    0,
    1
  },
  {
    push_operand,
    "",
    V4SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    V4SImode,
    0,
    1
  },
  {
    push_operand,
    "",
    V2SImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    V2SImode,
    0,
    1
  },
  {
    push_operand,
    "",
    V4HImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    V4HImode,
    0,
    1
  },
  {
    push_operand,
    "",
    V8QImode,
    0,
    1
  },
  {
    nonmemory_operand,
    "",
    V8QImode,
    0,
    1
  },
};



const struct insn_data insn_data[] = 
{
  {
    "*cmpsi_ccno_1",
    (const PTR) output_0,
    0,
    &operand_data[1],
    2,
    0,
    2,
    2
  },
  {
    "*cmpsi_minus_1",
    "cmp{l}\t{%1, %0|%0, %1}",
    0,
    &operand_data[3],
    2,
    0,
    2,
    1
  },
  {
    "*cmpsi_1_insn",
    "cmp{l}\t{%1, %0|%0, %1}",
    0,
    &operand_data[3],
    2,
    0,
    2,
    1
  },
  {
    "*cmphi_ccno_1",
    (const PTR) output_3,
    0,
    &operand_data[5],
    2,
    0,
    2,
    2
  },
  {
    "*cmphi_minus_1",
    "cmp{w}\t{%1, %0|%0, %1}",
    0,
    &operand_data[7],
    2,
    0,
    2,
    1
  },
  {
    "*cmphi_1",
    "cmp{w}\t{%1, %0|%0, %1}",
    0,
    &operand_data[7],
    2,
    0,
    2,
    1
  },
  {
    "*cmpqi_ccno_1",
    (const PTR) output_6,
    0,
    &operand_data[9],
    2,
    0,
    2,
    2
  },
  {
    "*cmpqi_1",
    "cmp{b}\t{%1, %0|%0, %1}",
    0,
    &operand_data[11],
    2,
    0,
    2,
    1
  },
  {
    "*cmpqi_minus_1",
    "cmp{b}\t{%1, %0|%0, %1}",
    0,
    &operand_data[11],
    2,
    0,
    2,
    1
  },
  {
    "*cmpqi_ext_1",
    "cmp{b}\t{%h1, %0|%0, %h1}",
    0,
    &operand_data[13],
    2,
    0,
    1,
    1
  },
  {
    "*cmpqi_ext_2",
    "test{b}\t%h0, %h0",
    0,
    &operand_data[14],
    2,
    0,
    1,
    1
  },
  {
    "cmpqi_ext_3_insn",
    "cmp{b}\t{%1, %h0|%h0, %1}",
    (insn_gen_fn) gen_cmpqi_ext_3_insn,
    &operand_data[16],
    2,
    0,
    1,
    1
  },
  {
    "*cmpqi_ext_4",
    "cmp{b}\t{%h1, %h0|%h0, %h1}",
    0,
    &operand_data[18],
    2,
    0,
    1,
    1
  },
  {
    "*cmpfp_0",
    (const PTR) output_13,
    0,
    &operand_data[20],
    3,
    0,
    1,
    3
  },
  {
    "*cmpfp_2_sf",
    (const PTR) output_14,
    0,
    &operand_data[23],
    2,
    0,
    1,
    3
  },
  {
    "*cmpfp_2_sf_1",
    (const PTR) output_15,
    0,
    &operand_data[25],
    3,
    0,
    1,
    3
  },
  {
    "*cmpfp_2_df",
    (const PTR) output_16,
    0,
    &operand_data[28],
    2,
    0,
    1,
    3
  },
  {
    "*cmpfp_2_df_1",
    (const PTR) output_17,
    0,
    &operand_data[30],
    3,
    0,
    1,
    3
  },
  {
    "*cmpfp_2_xf",
    (const PTR) output_18,
    0,
    &operand_data[33],
    2,
    0,
    1,
    3
  },
  {
    "*cmpfp_2_tf",
    (const PTR) output_19,
    0,
    &operand_data[35],
    2,
    0,
    1,
    3
  },
  {
    "*cmpfp_2_xf_1",
    (const PTR) output_20,
    0,
    &operand_data[37],
    3,
    0,
    1,
    3
  },
  {
    "*cmpfp_2_tf_1",
    (const PTR) output_21,
    0,
    &operand_data[40],
    3,
    0,
    1,
    3
  },
  {
    "*cmpfp_2u",
    (const PTR) output_22,
    0,
    &operand_data[43],
    2,
    0,
    1,
    3
  },
  {
    "*cmpfp_2u_1",
    (const PTR) output_23,
    0,
    &operand_data[45],
    3,
    0,
    1,
    3
  },
  {
    "*ficom_1",
    "#",
    0,
    &operand_data[48],
    2,
    0,
    2,
    1
  },
  {
    "x86_fnstsw_1",
    "fnstsw\t%0",
    (insn_gen_fn) gen_x86_fnstsw_1,
    &operand_data[20],
    1,
    0,
    1,
    1
  },
  {
    "x86_sahf_1",
    "sahf",
    (insn_gen_fn) gen_x86_sahf_1,
    &operand_data[50],
    1,
    0,
    1,
    1
  },
  {
    "*cmpfp_i",
    (const PTR) output_27,
    0,
    &operand_data[43],
    2,
    0,
    1,
    3
  },
  {
    "*cmpfp_iu",
    (const PTR) output_28,
    0,
    &operand_data[43],
    2,
    0,
    1,
    3
  },
  {
    "*pushsi2",
    "push{l}\t%1",
    0,
    &operand_data[51],
    2,
    0,
    1,
    1
  },
  {
    "*pushsi2_prologue",
    "push{l}\t%1",
    0,
    &operand_data[51],
    2,
    0,
    1,
    1
  },
  {
    "*popsi1_epilogue",
    "pop{l}\t%0",
    0,
    &operand_data[53],
    1,
    0,
    1,
    1
  },
  {
    "popsi1",
    "pop{l}\t%0",
    (insn_gen_fn) gen_popsi1,
    &operand_data[53],
    1,
    0,
    1,
    1
  },
  {
    "movsi_xor",
    "xor{l}\t{%0, %0|%0, %0}",
    (insn_gen_fn) gen_movsi_xor,
    &operand_data[54],
    2,
    0,
    1,
    1
  },
  {
    "*movsi_or",
    (const PTR) output_34,
    0,
    &operand_data[56],
    2,
    0,
    1,
    3
  },
  {
    "*movsi_1",
    (const PTR) output_35,
    0,
    &operand_data[58],
    2,
    0,
    6,
    3
  },
  {
    "*swapsi",
    "xchg{l}\t%1, %0",
    0,
    &operand_data[60],
    2,
    2,
    1,
    1
  },
  {
    "*pushhi2",
    (const PTR) output_37,
    0,
    &operand_data[62],
    2,
    0,
    2,
    2
  },
  {
    "*pophi1",
    "pop{w}\t%0",
    0,
    &operand_data[64],
    1,
    0,
    1,
    1
  },
  {
    "*movhi_1",
    (const PTR) output_39,
    0,
    &operand_data[65],
    2,
    0,
    6,
    3
  },
  {
    "*swaphi_1",
    "xchg{w}\t%1, %0",
    0,
    &operand_data[67],
    2,
    2,
    1,
    1
  },
  {
    "*swaphi_2",
    "xchg{l}\t%k1, %k0",
    0,
    &operand_data[67],
    2,
    2,
    1,
    1
  },
  {
    "*movstricthi_1",
    "mov{w}\t{%1, %0|%0, %1}",
    0,
    &operand_data[69],
    2,
    0,
    2,
    1
  },
  {
    "*movstricthi_xor",
    "xor{w}\t{%0, %0|%0, %0}",
    0,
    &operand_data[71],
    2,
    0,
    1,
    1
  },
  {
    "*pushqi2",
    (const PTR) output_44,
    0,
    &operand_data[73],
    2,
    0,
    2,
    2
  },
  {
    "*popqi1",
    "pop{w}\t%0",
    0,
    &operand_data[75],
    1,
    0,
    1,
    1
  },
  {
    "*movqi_1",
    (const PTR) output_46,
    0,
    &operand_data[76],
    2,
    0,
    7,
    3
  },
  {
    "*swapqi",
    "xchg{b}\t%1, %0",
    0,
    &operand_data[78],
    2,
    2,
    1,
    1
  },
  {
    "*movstrictqi_1",
    "mov{b}\t{%1, %0|%0, %1}",
    0,
    &operand_data[80],
    2,
    0,
    2,
    1
  },
  {
    "*movstrictqi_xor",
    "xor{b}\t{%0, %0|%0, %0}",
    0,
    &operand_data[82],
    2,
    0,
    1,
    1
  },
  {
    "*movsi_extv_1",
    "movs{bl|x}\t{%h1, %0|%0, %h1}",
    0,
    &operand_data[84],
    2,
    0,
    1,
    1
  },
  {
    "*movhi_extv_1",
    "movs{bl|x}\t{%h1, %k0|%k0, %h1}",
    0,
    &operand_data[86],
    2,
    0,
    1,
    1
  },
  {
    "*movqi_extv_1",
    (const PTR) output_52,
    0,
    &operand_data[88],
    2,
    0,
    2,
    3
  },
  {
    "*movsi_extzv_1",
    "movz{bl|x}\t{%h1, %0|%0, %h1}",
    0,
    &operand_data[90],
    2,
    0,
    1,
    1
  },
  {
    "*movqi_extzv_1",
    (const PTR) output_54,
    0,
    &operand_data[92],
    2,
    0,
    2,
    3
  },
  {
    "*movsi_insv_1",
    "mov{b}\t{%b1, %h0|%h0, %b1}",
    0,
    &operand_data[94],
    2,
    0,
    1,
    1
  },
  {
    "*movqi_insv_2",
    "mov{b}\t{%h1, %h0|%h0, %h1}",
    0,
    &operand_data[96],
    2,
    0,
    1,
    1
  },
  {
    "*pushdi",
    "#",
    0,
    &operand_data[98],
    2,
    0,
    1,
    1
  },
  {
    "*movdi_2",
    (const PTR) output_58,
    0,
    &operand_data[100],
    2,
    0,
    4,
    2
  },
  {
    "*pushsf",
    (const PTR) output_59,
    0,
    &operand_data[102],
    2,
    0,
    2,
    3
  },
  {
    "*movsf_1",
    (const PTR) output_60,
    0,
    &operand_data[104],
    2,
    0,
    5,
    3
  },
  {
    "*swapsf",
    (const PTR) output_61,
    0,
    &operand_data[106],
    2,
    2,
    1,
    3
  },
  {
    "*pushdf_nointeger",
    (const PTR) output_62,
    0,
    &operand_data[108],
    2,
    0,
    3,
    3
  },
  {
    "*pushdf_integer",
    (const PTR) output_63,
    0,
    &operand_data[110],
    2,
    0,
    2,
    3
  },
  {
    "*movdf_nointeger",
    (const PTR) output_64,
    0,
    &operand_data[112],
    2,
    0,
    5,
    3
  },
  {
    "*movdf_integer",
    (const PTR) output_65,
    0,
    &operand_data[114],
    2,
    0,
    5,
    3
  },
  {
    "*swapdf",
    (const PTR) output_66,
    0,
    &operand_data[116],
    2,
    2,
    1,
    3
  },
  {
    "*pushxf_nointeger",
    (const PTR) output_67,
    0,
    &operand_data[118],
    2,
    0,
    3,
    3
  },
  {
    "*pushtf_nointeger",
    (const PTR) output_68,
    0,
    &operand_data[120],
    2,
    0,
    3,
    3
  },
  {
    "*pushxf_integer",
    (const PTR) output_69,
    0,
    &operand_data[122],
    2,
    0,
    2,
    3
  },
  {
    "*pushtf_integer",
    (const PTR) output_70,
    0,
    &operand_data[124],
    2,
    0,
    2,
    3
  },
  {
    "*movxf_nointeger",
    (const PTR) output_71,
    0,
    &operand_data[126],
    2,
    0,
    5,
    3
  },
  {
    "*movtf_nointeger",
    (const PTR) output_72,
    0,
    &operand_data[128],
    2,
    0,
    5,
    3
  },
  {
    "*movxf_integer",
    (const PTR) output_73,
    0,
    &operand_data[130],
    2,
    0,
    5,
    3
  },
  {
    "*movtf_integer",
    (const PTR) output_74,
    0,
    &operand_data[132],
    2,
    0,
    5,
    3
  },
  {
    "swapxf",
    (const PTR) output_75,
    (insn_gen_fn) gen_swapxf,
    &operand_data[134],
    2,
    2,
    1,
    3
  },
  {
    "swaptf",
    (const PTR) output_76,
    (insn_gen_fn) gen_swaptf,
    &operand_data[136],
    2,
    2,
    1,
    3
  },
  {
    "zero_extendhisi2_and",
    "#",
    (insn_gen_fn) gen_zero_extendhisi2_and,
    &operand_data[138],
    2,
    0,
    1,
    1
  },
  {
    "*zero_extendhisi2_movzwl",
    "movz{wl|x}\t{%1, %0|%0, %1}",
    0,
    &operand_data[140],
    2,
    0,
    1,
    1
  },
  {
    "*zero_extendqihi2_and",
    "#",
    0,
    &operand_data[142],
    2,
    0,
    2,
    1
  },
  {
    "*zero_extendqihi2_movzbw_and",
    "#",
    0,
    &operand_data[144],
    2,
    0,
    2,
    1
  },
  {
    "*zero_extendqihi2_movzbw",
    "movz{bw|x}\t{%1, %0|%0, %1}",
    0,
    &operand_data[146],
    2,
    0,
    1,
    1
  },
  {
    "*zero_extendqisi2_and",
    "#",
    0,
    &operand_data[148],
    2,
    0,
    2,
    1
  },
  {
    "*zero_extendqisi2_movzbw_and",
    "#",
    0,
    &operand_data[150],
    2,
    0,
    2,
    1
  },
  {
    "*zero_extendqisi2_movzbw",
    "movz{bl|x}\t{%1, %0|%0, %1}",
    0,
    &operand_data[152],
    2,
    0,
    1,
    1
  },
  {
    "zero_extendsidi2",
    "#",
    (insn_gen_fn) gen_zero_extendsidi2,
    &operand_data[154],
    2,
    0,
    3,
    1
  },
  {
    "extendsidi2",
    "#",
    (insn_gen_fn) gen_extendsidi2,
    &operand_data[156],
    3,
    0,
    4,
    1
  },
  {
    "extendhisi2",
    (const PTR) output_87,
    (insn_gen_fn) gen_extendhisi2,
    &operand_data[159],
    2,
    0,
    2,
    3
  },
  {
    "extendqihi2",
    (const PTR) output_88,
    (insn_gen_fn) gen_extendqihi2,
    &operand_data[161],
    2,
    0,
    2,
    3
  },
  {
    "extendqisi2",
    "movs{bl|x}\t{%1,%0|%0, %1}",
    (insn_gen_fn) gen_extendqisi2,
    &operand_data[152],
    2,
    0,
    1,
    1
  },
  {
    "*dummy_extendsfdf2",
    "#",
    0,
    &operand_data[163],
    2,
    0,
    1,
    1
  },
  {
    "*dummy_extendsfxf2",
    "#",
    0,
    &operand_data[165],
    2,
    0,
    1,
    1
  },
  {
    "*dummy_extendsftf2",
    "#",
    0,
    &operand_data[167],
    2,
    0,
    1,
    1
  },
  {
    "*dummy_extenddfxf2",
    "#",
    0,
    &operand_data[169],
    2,
    0,
    1,
    1
  },
  {
    "*dummy_extenddftf2",
    "#",
    0,
    &operand_data[171],
    2,
    0,
    1,
    1
  },
  {
    "*extendsfdf2_1",
    (const PTR) output_95,
    0,
    &operand_data[173],
    2,
    0,
    2,
    3
  },
  {
    "*extendsfxf2_1",
    (const PTR) output_96,
    0,
    &operand_data[175],
    2,
    0,
    2,
    3
  },
  {
    "*extendsftf2_1",
    (const PTR) output_97,
    0,
    &operand_data[177],
    2,
    0,
    2,
    3
  },
  {
    "*extenddfxf2_1",
    (const PTR) output_98,
    0,
    &operand_data[179],
    2,
    0,
    2,
    3
  },
  {
    "*extenddftf2_1",
    (const PTR) output_99,
    0,
    &operand_data[181],
    2,
    0,
    2,
    3
  },
  {
    "*truncdfsf2_1",
    (const PTR) output_100,
    0,
    &operand_data[183],
    3,
    0,
    2,
    3
  },
  {
    "*truncdfsf2_2",
    (const PTR) output_101,
    0,
    &operand_data[186],
    2,
    0,
    1,
    3
  },
  {
    "*truncxfsf2_1",
    (const PTR) output_102,
    0,
    &operand_data[188],
    3,
    0,
    2,
    3
  },
  {
    "*truncxfsf2_2",
    (const PTR) output_103,
    0,
    &operand_data[191],
    2,
    0,
    1,
    3
  },
  {
    "*trunctfsf2_1",
    (const PTR) output_104,
    0,
    &operand_data[193],
    3,
    0,
    2,
    3
  },
  {
    "*truncxfsf2_2",
    (const PTR) output_105,
    0,
    &operand_data[196],
    2,
    0,
    1,
    3
  },
  {
    "*truncxfdf2_1",
    (const PTR) output_106,
    0,
    &operand_data[198],
    3,
    0,
    2,
    3
  },
  {
    "*truncxfdf2_2",
    (const PTR) output_107,
    0,
    &operand_data[201],
    2,
    0,
    1,
    3
  },
  {
    "*trunctfdf2_1",
    (const PTR) output_108,
    0,
    &operand_data[203],
    3,
    0,
    2,
    3
  },
  {
    "*truncxfdf2_2",
    (const PTR) output_109,
    0,
    &operand_data[206],
    2,
    0,
    1,
    3
  },
  {
    "*fix_truncdi_1",
    (const PTR) output_110,
    0,
    &operand_data[208],
    6,
    0,
    2,
    3
  },
  {
    "*fix_truncsi_1",
    (const PTR) output_111,
    0,
    &operand_data[214],
    5,
    0,
    2,
    3
  },
  {
    "*fix_trunchi_1",
    (const PTR) output_112,
    0,
    &operand_data[219],
    5,
    0,
    2,
    3
  },
  {
    "x86_fnstcw_1",
    "fnstcw\t%0",
    (insn_gen_fn) gen_x86_fnstcw_1,
    &operand_data[224],
    1,
    0,
    1,
    1
  },
  {
    "x86_fldcw_1",
    "fldcw\t%0",
    (insn_gen_fn) gen_x86_fldcw_1,
    &operand_data[225],
    1,
    0,
    1,
    1
  },
  {
    "floathisf2",
    (const PTR) output_115,
    (insn_gen_fn) gen_floathisf2,
    &operand_data[226],
    2,
    0,
    2,
    2
  },
  {
    "floatsisf2",
    (const PTR) output_116,
    (insn_gen_fn) gen_floatsisf2,
    &operand_data[228],
    2,
    0,
    2,
    2
  },
  {
    "floatdisf2",
    (const PTR) output_117,
    (insn_gen_fn) gen_floatdisf2,
    &operand_data[230],
    2,
    0,
    2,
    2
  },
  {
    "floathidf2",
    (const PTR) output_118,
    (insn_gen_fn) gen_floathidf2,
    &operand_data[232],
    2,
    0,
    2,
    2
  },
  {
    "floatsidf2",
    (const PTR) output_119,
    (insn_gen_fn) gen_floatsidf2,
    &operand_data[234],
    2,
    0,
    2,
    2
  },
  {
    "floatdidf2",
    (const PTR) output_120,
    (insn_gen_fn) gen_floatdidf2,
    &operand_data[236],
    2,
    0,
    2,
    2
  },
  {
    "floathixf2",
    (const PTR) output_121,
    (insn_gen_fn) gen_floathixf2,
    &operand_data[238],
    2,
    0,
    2,
    2
  },
  {
    "floathitf2",
    (const PTR) output_122,
    (insn_gen_fn) gen_floathitf2,
    &operand_data[240],
    2,
    0,
    2,
    2
  },
  {
    "floatsixf2",
    (const PTR) output_123,
    (insn_gen_fn) gen_floatsixf2,
    &operand_data[242],
    2,
    0,
    2,
    2
  },
  {
    "floatsitf2",
    (const PTR) output_124,
    (insn_gen_fn) gen_floatsitf2,
    &operand_data[244],
    2,
    0,
    2,
    2
  },
  {
    "floatdixf2",
    (const PTR) output_125,
    (insn_gen_fn) gen_floatdixf2,
    &operand_data[246],
    2,
    0,
    2,
    2
  },
  {
    "floatditf2",
    (const PTR) output_126,
    (insn_gen_fn) gen_floatditf2,
    &operand_data[248],
    2,
    0,
    2,
    2
  },
  {
    "adddi3",
    "#",
    (insn_gen_fn) gen_adddi3,
    &operand_data[250],
    3,
    0,
    2,
    1
  },
  {
    "*addsi3_carry",
    "adc{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[253],
    3,
    0,
    2,
    1
  },
  {
    "*addsi3_cc",
    "add{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[253],
    3,
    2,
    2,
    1
  },
  {
    "addqi3_cc",
    "add{b}\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_addqi3_cc,
    &operand_data[256],
    3,
    2,
    2,
    1
  },
  {
    "*lea_0",
    "lea{l}\t{%a1, %0|%0, %a1}",
    0,
    &operand_data[259],
    2,
    0,
    1,
    1
  },
  {
    "*lea_general_1",
    "#",
    0,
    &operand_data[261],
    4,
    0,
    1,
    1
  },
  {
    "*lea_general_2",
    "#",
    0,
    &operand_data[265],
    4,
    0,
    1,
    1
  },
  {
    "*lea_general_3",
    "#",
    0,
    &operand_data[269],
    5,
    0,
    1,
    1
  },
  {
    "*addsi_1",
    (const PTR) output_135,
    0,
    &operand_data[274],
    3,
    0,
    3,
    3
  },
  {
    "*addsi_2",
    (const PTR) output_136,
    0,
    &operand_data[277],
    3,
    2,
    2,
    3
  },
  {
    "*addsi_3",
    (const PTR) output_137,
    0,
    &operand_data[280],
    3,
    0,
    1,
    3
  },
  {
    "*addsi_4",
    (const PTR) output_138,
    0,
    &operand_data[283],
    3,
    0,
    1,
    3
  },
  {
    "*addsi_5",
    (const PTR) output_139,
    0,
    &operand_data[280],
    3,
    0,
    1,
    3
  },
  {
    "*addhi_1_lea",
    (const PTR) output_140,
    0,
    &operand_data[286],
    3,
    0,
    3,
    3
  },
  {
    "*addhi_1",
    (const PTR) output_141,
    0,
    &operand_data[289],
    3,
    0,
    2,
    3
  },
  {
    "*addhi_2",
    (const PTR) output_142,
    0,
    &operand_data[292],
    3,
    2,
    2,
    3
  },
  {
    "*addhi_3",
    (const PTR) output_143,
    0,
    &operand_data[295],
    3,
    0,
    1,
    3
  },
  {
    "*addhi_4",
    (const PTR) output_144,
    0,
    &operand_data[298],
    3,
    0,
    1,
    3
  },
  {
    "*addhi_5",
    (const PTR) output_145,
    0,
    &operand_data[295],
    3,
    0,
    1,
    3
  },
  {
    "*addqi_1_lea",
    (const PTR) output_146,
    0,
    &operand_data[301],
    3,
    0,
    4,
    3
  },
  {
    "*addqi_1",
    (const PTR) output_147,
    0,
    &operand_data[304],
    3,
    0,
    3,
    3
  },
  {
    "*addqi_2",
    (const PTR) output_148,
    0,
    &operand_data[307],
    3,
    2,
    2,
    3
  },
  {
    "*addqi_3",
    (const PTR) output_149,
    0,
    &operand_data[310],
    3,
    0,
    1,
    3
  },
  {
    "*addqi_4",
    (const PTR) output_150,
    0,
    &operand_data[313],
    3,
    0,
    1,
    3
  },
  {
    "*addqi_5",
    (const PTR) output_151,
    0,
    &operand_data[310],
    3,
    0,
    1,
    3
  },
  {
    "addqi_ext_1",
    (const PTR) output_152,
    (insn_gen_fn) gen_addqi_ext_1,
    &operand_data[316],
    3,
    0,
    1,
    3
  },
  {
    "*addqi_ext_2",
    "add{b}\t{%h2, %h0|%h0, %h2}",
    0,
    &operand_data[319],
    3,
    0,
    1,
    1
  },
  {
    "subdi3",
    "#",
    (insn_gen_fn) gen_subdi3,
    &operand_data[322],
    3,
    0,
    2,
    1
  },
  {
    "subsi3_carry",
    "sbb{l}\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_subsi3_carry,
    &operand_data[325],
    3,
    0,
    2,
    1
  },
  {
    "*subsi_1",
    "sub{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[325],
    3,
    0,
    2,
    1
  },
  {
    "*subsi_2",
    "sub{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[325],
    3,
    2,
    2,
    1
  },
  {
    "*subsi_3",
    "sub{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[325],
    3,
    2,
    2,
    1
  },
  {
    "*subhi_1",
    "sub{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[328],
    3,
    0,
    2,
    1
  },
  {
    "*subhi_2",
    "sub{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[328],
    3,
    2,
    2,
    1
  },
  {
    "*subhi_3",
    "sub{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[328],
    3,
    2,
    2,
    1
  },
  {
    "*subqi_1",
    "sub{b}\t{%2, %0|%0, %2}",
    0,
    &operand_data[331],
    3,
    0,
    2,
    1
  },
  {
    "*subqi_2",
    "sub{b}\t{%2, %0|%0, %2}",
    0,
    &operand_data[334],
    3,
    2,
    2,
    1
  },
  {
    "*subqi_3",
    "sub{b}\t{%2, %0|%0, %2}",
    0,
    &operand_data[334],
    3,
    2,
    2,
    1
  },
  {
    "*mulsi3_1",
    (const PTR) output_165,
    0,
    &operand_data[337],
    3,
    0,
    3,
    2
  },
  {
    "*mulhi3_1",
    (const PTR) output_166,
    0,
    &operand_data[340],
    3,
    0,
    3,
    2
  },
  {
    "mulqi3",
    "mul{b}\t%2",
    (insn_gen_fn) gen_mulqi3,
    &operand_data[343],
    3,
    0,
    1,
    1
  },
  {
    "umulqihi3",
    "mul{b}\t%2",
    (insn_gen_fn) gen_umulqihi3,
    &operand_data[346],
    3,
    0,
    1,
    1
  },
  {
    "mulqihi3",
    "imul{b}\t%2",
    (insn_gen_fn) gen_mulqihi3,
    &operand_data[346],
    3,
    0,
    1,
    1
  },
  {
    "umulsidi3",
    "mul{l}\t%2",
    (insn_gen_fn) gen_umulsidi3,
    &operand_data[349],
    3,
    0,
    1,
    1
  },
  {
    "mulsidi3",
    "imul{l}\t%2",
    (insn_gen_fn) gen_mulsidi3,
    &operand_data[349],
    3,
    0,
    1,
    1
  },
  {
    "umulsi3_highpart",
    "mul{l}\t%2",
    (insn_gen_fn) gen_umulsi3_highpart,
    &operand_data[352],
    4,
    0,
    1,
    1
  },
  {
    "smulsi3_highpart",
    "imul{l}\t%2",
    (insn_gen_fn) gen_smulsi3_highpart,
    &operand_data[352],
    4,
    0,
    1,
    1
  },
  {
    "divqi3",
    "idiv{b}\t%2",
    (insn_gen_fn) gen_divqi3,
    &operand_data[356],
    3,
    0,
    1,
    1
  },
  {
    "udivqi3",
    "div{b}\t%2",
    (insn_gen_fn) gen_udivqi3,
    &operand_data[356],
    3,
    0,
    1,
    1
  },
  {
    "*divmodsi4_nocltd",
    "#",
    0,
    &operand_data[359],
    4,
    2,
    2,
    1
  },
  {
    "*divmodsi4_cltd",
    "#",
    0,
    &operand_data[363],
    4,
    2,
    1,
    1
  },
  {
    "*divmodsi_noext",
    "idiv{l}\t%2",
    0,
    &operand_data[367],
    5,
    2,
    1,
    1
  },
  {
    "divmodhi4",
    "cwtd\n\tidiv{w}\t%2",
    (insn_gen_fn) gen_divmodhi4,
    &operand_data[372],
    4,
    2,
    1,
    1
  },
  {
    "udivmodsi4",
    "xor{l}\t%3, %3\n\tdiv{l}\t%2",
    (insn_gen_fn) gen_udivmodsi4,
    &operand_data[376],
    4,
    2,
    1,
    1
  },
  {
    "*udivmodsi4_noext",
    "div{l}\t%2",
    0,
    &operand_data[367],
    4,
    3,
    1,
    1
  },
  {
    "*udivmodhi_noext",
    "div{w}\t%2",
    0,
    &operand_data[380],
    5,
    2,
    1,
    1
  },
  {
    "testsi_1",
    "test{l}\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_testsi_1,
    &operand_data[385],
    2,
    0,
    3,
    1
  },
  {
    "*testhi_1",
    "test{w}\t{%1, %0|%0, %1}",
    0,
    &operand_data[387],
    2,
    0,
    3,
    1
  },
  {
    "*testqi_1",
    (const PTR) output_185,
    0,
    &operand_data[389],
    2,
    0,
    4,
    3
  },
  {
    "*testqi_ext_0",
    "test{b}\t{%1, %h0|%h0, %1}",
    0,
    &operand_data[391],
    2,
    0,
    1,
    1
  },
  {
    "*testqi_ext_1",
    "test{b}\t{%1, %h0|%h0, %1}",
    0,
    &operand_data[393],
    2,
    0,
    1,
    1
  },
  {
    "*testqi_ext_2",
    "test{b}\t{%h1, %h0|%h0, %h1}",
    0,
    &operand_data[18],
    2,
    0,
    1,
    1
  },
  {
    "*testqi_ext_3",
    "#",
    0,
    &operand_data[395],
    3,
    0,
    1,
    1
  },
  {
    "*andsi_1",
    (const PTR) output_190,
    0,
    &operand_data[398],
    3,
    0,
    3,
    3
  },
  {
    "*andsi_2",
    "and{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[401],
    3,
    2,
    2,
    1
  },
  {
    "*andhi_1",
    (const PTR) output_192,
    0,
    &operand_data[404],
    3,
    0,
    3,
    3
  },
  {
    "*andhi_2",
    "and{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[407],
    3,
    2,
    2,
    1
  },
  {
    "*andqi_1",
    (const PTR) output_194,
    0,
    &operand_data[410],
    3,
    0,
    3,
    2
  },
  {
    "*andqi_1_slp",
    "and{b}\t{%1, %0|%0, %1}",
    0,
    &operand_data[413],
    2,
    1,
    2,
    1
  },
  {
    "*andqi_2",
    (const PTR) output_196,
    0,
    &operand_data[415],
    3,
    2,
    3,
    3
  },
  {
    "*andqi_2_slp",
    "and{b}\t{%1, %0|%0, %1}",
    0,
    &operand_data[418],
    2,
    3,
    2,
    1
  },
  {
    "andqi_ext_0",
    "and{b}\t{%2, %h0|%h0, %2}",
    (insn_gen_fn) gen_andqi_ext_0,
    &operand_data[420],
    3,
    0,
    1,
    1
  },
  {
    "*andqi_ext_0_cc",
    "and{b}\t{%2, %h0|%h0, %2}",
    0,
    &operand_data[420],
    3,
    2,
    1,
    1
  },
  {
    "*andqi_ext_1",
    "and{b}\t{%2, %h0|%h0, %2}",
    0,
    &operand_data[423],
    3,
    0,
    1,
    1
  },
  {
    "*andqi_ext_2",
    "and{b}\t{%h2, %h0|%h0, %h2}",
    0,
    &operand_data[319],
    3,
    0,
    1,
    1
  },
  {
    "*iorsi_1",
    "or{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[426],
    3,
    0,
    2,
    1
  },
  {
    "*iorsi_2",
    "or{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[401],
    3,
    2,
    2,
    1
  },
  {
    "*iorsi_3",
    "or{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[429],
    3,
    0,
    1,
    1
  },
  {
    "*iorhi_1",
    "or{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[432],
    3,
    0,
    2,
    1
  },
  {
    "*iorhi_2",
    "or{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[407],
    3,
    2,
    2,
    1
  },
  {
    "*iorhi_3",
    "or{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[435],
    3,
    0,
    1,
    1
  },
  {
    "*iorqi_1",
    (const PTR) output_208,
    0,
    &operand_data[438],
    3,
    0,
    3,
    2
  },
  {
    "*iorqi_1_slp",
    "or{b}\t{%1, %0|%0, %1}",
    0,
    &operand_data[441],
    2,
    1,
    2,
    1
  },
  {
    "*iorqi_2",
    "or{b}\t{%2, %0|%0, %2}",
    0,
    &operand_data[443],
    3,
    2,
    2,
    1
  },
  {
    "*iorqi_2_slp",
    "or{b}\t{%1, %0|%0, %1}",
    0,
    &operand_data[446],
    2,
    3,
    2,
    1
  },
  {
    "*iorqi_3",
    "or{b}\t{%2, %0|%0, %2}",
    0,
    &operand_data[448],
    3,
    0,
    1,
    1
  },
  {
    "*xorsi_1",
    "xor{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[253],
    3,
    0,
    2,
    1
  },
  {
    "*xorsi_2",
    "xor{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[401],
    3,
    2,
    2,
    1
  },
  {
    "*xorsi_3",
    "xor{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[429],
    3,
    0,
    1,
    1
  },
  {
    "*xorhi_1",
    "xor{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[432],
    3,
    0,
    2,
    1
  },
  {
    "*xorhi_2",
    "xor{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[407],
    3,
    2,
    2,
    1
  },
  {
    "*xorhi_3",
    "xor{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[435],
    3,
    0,
    1,
    1
  },
  {
    "*xorqi_1",
    (const PTR) output_219,
    0,
    &operand_data[438],
    3,
    0,
    3,
    2
  },
  {
    "*xorqi_ext_1",
    "xor{b}\t{%h2, %h0|%h0, %h2}",
    0,
    &operand_data[451],
    3,
    0,
    1,
    1
  },
  {
    "*xorqi_cc_1",
    "xor{b}\t{%2, %0|%0, %2}",
    0,
    &operand_data[443],
    3,
    2,
    2,
    1
  },
  {
    "*xorqi_cc_2",
    "xor{b}\t{%2, %0|%0, %2}",
    0,
    &operand_data[448],
    3,
    0,
    1,
    1
  },
  {
    "*xorqi_cc_ext_1",
    "xor{b}\t{%2, %h0|%h0, %2}",
    0,
    &operand_data[316],
    3,
    2,
    1,
    1
  },
  {
    "*negdi2_1",
    "#",
    0,
    &operand_data[454],
    2,
    0,
    1,
    1
  },
  {
    "*negsi2_1",
    "neg{l}\t%0",
    0,
    &operand_data[456],
    2,
    0,
    1,
    1
  },
  {
    "*negsi2_cmpz",
    "neg{l}\t%0",
    0,
    &operand_data[456],
    2,
    1,
    1,
    1
  },
  {
    "*neghi2_1",
    "neg{w}\t%0",
    0,
    &operand_data[458],
    2,
    0,
    1,
    1
  },
  {
    "*neghi2_cmpz",
    "neg{w}\t%0",
    0,
    &operand_data[458],
    2,
    1,
    1,
    1
  },
  {
    "*negqi2_1",
    "neg{b}\t%0",
    0,
    &operand_data[460],
    2,
    0,
    1,
    1
  },
  {
    "*negqi2_cmpz",
    "neg{b}\t%0",
    0,
    &operand_data[460],
    2,
    1,
    1,
    1
  },
  {
    "*negsf2_if",
    "#",
    0,
    &operand_data[462],
    2,
    0,
    2,
    1
  },
  {
    "*negdf2_if",
    "#",
    0,
    &operand_data[464],
    2,
    0,
    2,
    1
  },
  {
    "*negxf2_if",
    "#",
    0,
    &operand_data[466],
    2,
    0,
    2,
    1
  },
  {
    "*negtf2_if",
    "#",
    0,
    &operand_data[468],
    2,
    0,
    2,
    1
  },
  {
    "*negsf2_1",
    "fchs",
    0,
    &operand_data[470],
    2,
    0,
    1,
    1
  },
  {
    "*negdf2_1",
    "fchs",
    0,
    &operand_data[472],
    2,
    0,
    1,
    1
  },
  {
    "*negextendsfdf2",
    "fchs",
    0,
    &operand_data[474],
    2,
    0,
    1,
    1
  },
  {
    "*negxf2_1",
    "fchs",
    0,
    &operand_data[476],
    2,
    0,
    1,
    1
  },
  {
    "*negextenddfxf2",
    "fchs",
    0,
    &operand_data[478],
    2,
    0,
    1,
    1
  },
  {
    "*negextendsfxf2",
    "fchs",
    0,
    &operand_data[480],
    2,
    0,
    1,
    1
  },
  {
    "*negtf2_1",
    "fchs",
    0,
    &operand_data[482],
    2,
    0,
    1,
    1
  },
  {
    "*negextenddftf2",
    "fchs",
    0,
    &operand_data[484],
    2,
    0,
    1,
    1
  },
  {
    "*negextendsftf2",
    "fchs",
    0,
    &operand_data[486],
    2,
    0,
    1,
    1
  },
  {
    "*abssf2_if",
    "#",
    0,
    &operand_data[462],
    2,
    0,
    2,
    1
  },
  {
    "*absdf2_if",
    "#",
    0,
    &operand_data[464],
    2,
    0,
    2,
    1
  },
  {
    "*absxf2_if",
    "#",
    0,
    &operand_data[466],
    2,
    0,
    2,
    1
  },
  {
    "*abstf2_if",
    "#",
    0,
    &operand_data[468],
    2,
    0,
    2,
    1
  },
  {
    "*abssf2_1",
    "fabs",
    0,
    &operand_data[470],
    2,
    0,
    1,
    1
  },
  {
    "*absdf2_1",
    "fabs",
    0,
    &operand_data[472],
    2,
    0,
    1,
    1
  },
  {
    "*absextendsfdf2",
    "fabs",
    0,
    &operand_data[474],
    2,
    0,
    1,
    1
  },
  {
    "*absxf2_1",
    "fabs",
    0,
    &operand_data[476],
    2,
    0,
    1,
    1
  },
  {
    "*absextenddfxf2",
    "fabs",
    0,
    &operand_data[478],
    2,
    0,
    1,
    1
  },
  {
    "*absextendsfxf2",
    "fabs",
    0,
    &operand_data[480],
    2,
    0,
    1,
    1
  },
  {
    "*abstf2_1",
    "fabs",
    0,
    &operand_data[482],
    2,
    0,
    1,
    1
  },
  {
    "*absextenddftf2",
    "fabs",
    0,
    &operand_data[484],
    2,
    0,
    1,
    1
  },
  {
    "*absextendsftf2",
    "fabs",
    0,
    &operand_data[486],
    2,
    0,
    1,
    1
  },
  {
    "*one_cmplsi2_1",
    "not{l}\t%0",
    0,
    &operand_data[456],
    2,
    0,
    1,
    1
  },
  {
    "*one_cmplsi2_2",
    "#",
    0,
    &operand_data[456],
    2,
    1,
    1,
    1
  },
  {
    "*one_cmplhi2_1",
    "not{w}\t%0",
    0,
    &operand_data[458],
    2,
    0,
    1,
    1
  },
  {
    "*one_cmplhi2_2",
    "#",
    0,
    &operand_data[458],
    2,
    1,
    1,
    1
  },
  {
    "*one_cmplqi2_1",
    (const PTR) output_261,
    0,
    &operand_data[488],
    2,
    0,
    2,
    2
  },
  {
    "*one_cmplqi2_2",
    "#",
    0,
    &operand_data[460],
    2,
    1,
    1,
    1
  },
  {
    "ashldi3_1",
    "#",
    (insn_gen_fn) gen_ashldi3_1,
    &operand_data[490],
    4,
    0,
    1,
    1
  },
  {
    "*ashldi3_2",
    "#",
    0,
    &operand_data[490],
    3,
    0,
    1,
    1
  },
  {
    "x86_shld_1",
    (const PTR) output_265,
    (insn_gen_fn) gen_x86_shld_1,
    &operand_data[494],
    3,
    2,
    2,
    2
  },
  {
    "*ashlsi3_1",
    (const PTR) output_266,
    0,
    &operand_data[497],
    3,
    0,
    2,
    3
  },
  {
    "*ashlsi3_cmp",
    (const PTR) output_267,
    0,
    &operand_data[500],
    3,
    2,
    1,
    3
  },
  {
    "*ashlhi3_1_lea",
    (const PTR) output_268,
    0,
    &operand_data[503],
    3,
    0,
    2,
    3
  },
  {
    "*ashlhi3_1",
    (const PTR) output_269,
    0,
    &operand_data[506],
    3,
    0,
    1,
    3
  },
  {
    "*ashlhi3_cmp",
    (const PTR) output_270,
    0,
    &operand_data[509],
    3,
    2,
    1,
    3
  },
  {
    "*ashlqi3_1_lea",
    (const PTR) output_271,
    0,
    &operand_data[512],
    3,
    0,
    3,
    3
  },
  {
    "*ashlqi3_1",
    (const PTR) output_272,
    0,
    &operand_data[515],
    3,
    0,
    2,
    3
  },
  {
    "*ashlqi3_cmp",
    (const PTR) output_273,
    0,
    &operand_data[518],
    3,
    2,
    1,
    3
  },
  {
    "ashrdi3_1",
    "#",
    (insn_gen_fn) gen_ashrdi3_1,
    &operand_data[490],
    4,
    0,
    1,
    1
  },
  {
    "*ashrdi3_2",
    "#",
    0,
    &operand_data[490],
    3,
    0,
    1,
    1
  },
  {
    "x86_shrd_1",
    (const PTR) output_276,
    (insn_gen_fn) gen_x86_shrd_1,
    &operand_data[494],
    3,
    2,
    2,
    2
  },
  {
    "ashrsi3_31",
    (const PTR) output_277,
    (insn_gen_fn) gen_ashrsi3_31,
    &operand_data[521],
    3,
    0,
    2,
    2
  },
  {
    "*ashrsi3_1_one_bit",
    "sar{l}\t%0",
    0,
    &operand_data[524],
    3,
    0,
    1,
    1
  },
  {
    "*ashrsi3_1",
    (const PTR) output_279,
    0,
    &operand_data[527],
    3,
    0,
    2,
    2
  },
  {
    "*ashrsi3_one_bit_cmp",
    "sar{l}\t%0",
    0,
    &operand_data[524],
    3,
    2,
    1,
    1
  },
  {
    "*ashrsi3_cmp",
    "sar{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[500],
    3,
    2,
    1,
    1
  },
  {
    "*ashrhi3_1_one_bit",
    "sar{w}\t%0",
    0,
    &operand_data[530],
    3,
    0,
    1,
    1
  },
  {
    "*ashrhi3_1",
    (const PTR) output_283,
    0,
    &operand_data[533],
    3,
    0,
    2,
    2
  },
  {
    "*ashrhi3_one_bit_cmp",
    "sar{w}\t%0",
    0,
    &operand_data[530],
    3,
    2,
    1,
    1
  },
  {
    "*ashrhi3_cmp",
    "sar{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[509],
    3,
    2,
    1,
    1
  },
  {
    "*ashrqi3_1_one_bit",
    "sar{b}\t%0",
    0,
    &operand_data[536],
    3,
    0,
    1,
    1
  },
  {
    "*ashrqi3_1",
    (const PTR) output_287,
    0,
    &operand_data[539],
    3,
    0,
    2,
    2
  },
  {
    "*ashrqi3_one_bit_cmp",
    "sar{b}\t%0",
    0,
    &operand_data[542],
    3,
    2,
    1,
    1
  },
  {
    "*ashrqi3_cmp",
    "sar{b}\t{%2, %0|%0, %2}",
    0,
    &operand_data[545],
    3,
    2,
    1,
    1
  },
  {
    "lshrdi3_1",
    "#",
    (insn_gen_fn) gen_lshrdi3_1,
    &operand_data[490],
    4,
    0,
    1,
    1
  },
  {
    "*lshrdi3_2",
    "#",
    0,
    &operand_data[490],
    3,
    0,
    1,
    1
  },
  {
    "*lshrsi3_1_one_bit",
    "shr{l}\t%0",
    0,
    &operand_data[524],
    3,
    0,
    1,
    1
  },
  {
    "*lshrsi3_1",
    (const PTR) output_293,
    0,
    &operand_data[527],
    3,
    0,
    2,
    2
  },
  {
    "*lshrsi3_one_bit_cmp",
    "shr{l}\t%0",
    0,
    &operand_data[524],
    3,
    2,
    1,
    1
  },
  {
    "*lshrsi3_cmp",
    "shr{l}\t{%2, %0|%0, %2}",
    0,
    &operand_data[500],
    3,
    2,
    1,
    1
  },
  {
    "*lshrhi3_1_one_bit",
    "shr{w}\t%0",
    0,
    &operand_data[530],
    3,
    0,
    1,
    1
  },
  {
    "*lshrhi3_1",
    (const PTR) output_297,
    0,
    &operand_data[533],
    3,
    0,
    2,
    2
  },
  {
    "*lshrhi3_one_bit_cmp",
    "shr{w}\t%0",
    0,
    &operand_data[530],
    3,
    2,
    1,
    1
  },
  {
    "*lshrhi3_cmp",
    "shr{w}\t{%2, %0|%0, %2}",
    0,
    &operand_data[509],
    3,
    2,
    1,
    1
  },
  {
    "*lshrqi3_1_one_bit",
    "shr{b}\t%0",
    0,
    &operand_data[536],
    3,
    0,
    1,
    1
  },
  {
    "*lshrqi3_1",
    (const PTR) output_301,
    0,
    &operand_data[539],
    3,
    0,
    2,
    2
  },
  {
    "*lshrqi2_one_bit_cmp",
    "shr{b}\t%0",
    0,
    &operand_data[536],
    3,
    2,
    1,
    1
  },
  {
    "*lshrqi2_cmp",
    "shr{b}\t{%2, %0|%0, %2}",
    0,
    &operand_data[518],
    3,
    2,
    1,
    1
  },
  {
    "*rotlsi3_1_one_bit",
    "rol{l}\t%0",
    0,
    &operand_data[524],
    3,
    0,
    1,
    1
  },
  {
    "*rotlsi3_1",
    (const PTR) output_305,
    0,
    &operand_data[527],
    3,
    0,
    2,
    2
  },
  {
    "*rotlhi3_1_one_bit",
    "rol{w}\t%0",
    0,
    &operand_data[530],
    3,
    0,
    1,
    1
  },
  {
    "*rotlhi3_1",
    (const PTR) output_307,
    0,
    &operand_data[533],
    3,
    0,
    2,
    2
  },
  {
    "*rotlqi3_1_one_bit",
    "rol{b}\t%0",
    0,
    &operand_data[536],
    3,
    0,
    1,
    1
  },
  {
    "*rotlqi3_1",
    (const PTR) output_309,
    0,
    &operand_data[539],
    3,
    0,
    2,
    2
  },
  {
    "*rotrsi3_1_one_bit",
    "ror{l}\t%0",
    0,
    &operand_data[524],
    3,
    0,
    1,
    1
  },
  {
    "*rotrsi3_1",
    (const PTR) output_311,
    0,
    &operand_data[527],
    3,
    0,
    2,
    2
  },
  {
    "*rotrhi3_one_bit",
    "ror{w}\t%0",
    0,
    &operand_data[530],
    3,
    0,
    1,
    1
  },
  {
    "*rotrhi3",
    (const PTR) output_313,
    0,
    &operand_data[533],
    3,
    0,
    2,
    2
  },
  {
    "*rotrqi3_1_one_bit",
    "ror{b}\t%0",
    0,
    &operand_data[536],
    3,
    0,
    1,
    1
  },
  {
    "*rotrqi3_1",
    (const PTR) output_315,
    0,
    &operand_data[539],
    3,
    0,
    2,
    2
  },
  {
    "*setcc_1",
    "set%C1\t%0",
    0,
    &operand_data[548],
    2,
    0,
    1,
    1
  },
  {
    "setcc_2",
    "set%C1\t%0",
    (insn_gen_fn) gen_setcc_2,
    &operand_data[550],
    2,
    0,
    1,
    1
  },
  {
    "*jcc_1",
    "j%C1\t%l0",
    0,
    &operand_data[552],
    2,
    0,
    0,
    1
  },
  {
    "*jcc_2",
    "j%c1\t%l0",
    0,
    &operand_data[552],
    2,
    0,
    0,
    1
  },
  {
    "*fp_jcc_1",
    "#",
    0,
    &operand_data[554],
    4,
    0,
    1,
    1
  },
  {
    "*fp_jcc_2",
    "#",
    0,
    &operand_data[554],
    4,
    0,
    1,
    1
  },
  {
    "*fp_jcc_3",
    "#",
    0,
    &operand_data[558],
    5,
    0,
    1,
    1
  },
  {
    "*fp_jcc_4",
    "#",
    0,
    &operand_data[558],
    5,
    0,
    1,
    1
  },
  {
    "*fp_jcc_5",
    "#",
    0,
    &operand_data[563],
    5,
    0,
    1,
    1
  },
  {
    "*fp_jcc_6",
    "#",
    0,
    &operand_data[563],
    5,
    0,
    1,
    1
  },
  {
    "jump",
    "jmp\t%l0",
    (insn_gen_fn) gen_jump,
    &operand_data[552],
    1,
    0,
    0,
    1
  },
  {
    "indirect_jump",
    "jmp\t%A0",
    (insn_gen_fn) gen_indirect_jump,
    &operand_data[351],
    1,
    0,
    1,
    1
  },
  {
    "tablejump",
    "jmp\t%A0",
    (insn_gen_fn) gen_tablejump,
    &operand_data[568],
    2,
    0,
    1,
    1
  },
  {
    "*tablejump_pic",
    "jmp\t%A0",
    0,
    &operand_data[568],
    2,
    0,
    1,
    1
  },
  {
    "doloop_end_internal",
    (const PTR) output_330,
    (insn_gen_fn) gen_doloop_end_internal,
    &operand_data[569],
    4,
    1,
    3,
    3
  },
  {
    "*call_pop_0",
    (const PTR) output_331,
    0,
    &operand_data[573],
    3,
    0,
    0,
    3
  },
  {
    "*call_pop_1",
    (const PTR) output_332,
    0,
    &operand_data[576],
    3,
    0,
    1,
    3
  },
  {
    "*call_0",
    (const PTR) output_333,
    0,
    &operand_data[573],
    2,
    0,
    0,
    3
  },
  {
    "*call_1",
    (const PTR) output_334,
    0,
    &operand_data[576],
    2,
    0,
    1,
    3
  },
  {
    "blockage",
    "",
    (insn_gen_fn) gen_blockage,
    &operand_data[0],
    0,
    0,
    0,
    1
  },
  {
    "return_internal",
    "ret",
    (insn_gen_fn) gen_return_internal,
    &operand_data[0],
    0,
    0,
    0,
    1
  },
  {
    "return_pop_internal",
    "ret\t%0",
    (insn_gen_fn) gen_return_pop_internal,
    &operand_data[396],
    1,
    0,
    0,
    1
  },
  {
    "return_indirect_internal",
    "jmp\t%A0",
    (insn_gen_fn) gen_return_indirect_internal,
    &operand_data[579],
    1,
    0,
    1,
    1
  },
  {
    "nop",
    "nop",
    (insn_gen_fn) gen_nop,
    &operand_data[0],
    0,
    0,
    0,
    1
  },
  {
    "prologue_set_got",
    (const PTR) output_340,
    (insn_gen_fn) gen_prologue_set_got,
    &operand_data[580],
    3,
    1,
    1,
    3
  },
  {
    "prologue_get_pc",
    (const PTR) output_341,
    (insn_gen_fn) gen_prologue_get_pc,
    &operand_data[583],
    2,
    0,
    1,
    3
  },
  {
    "eh_return_1",
    "#",
    (insn_gen_fn) gen_eh_return_1,
    &operand_data[585],
    1,
    0,
    1,
    1
  },
  {
    "leave",
    "leave",
    (insn_gen_fn) gen_leave,
    &operand_data[0],
    0,
    0,
    0,
    1
  },
  {
    "ffssi_1",
    "bsf{l}\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_ffssi_1,
    &operand_data[586],
    2,
    1,
    1,
    1
  },
  {
    "*fop_sf_comm",
    (const PTR) output_345,
    0,
    &operand_data[588],
    4,
    0,
    1,
    3
  },
  {
    "*fop_df_comm",
    (const PTR) output_346,
    0,
    &operand_data[592],
    4,
    0,
    1,
    3
  },
  {
    "*fop_xf_comm",
    (const PTR) output_347,
    0,
    &operand_data[596],
    4,
    0,
    1,
    3
  },
  {
    "*fop_tf_comm",
    (const PTR) output_348,
    0,
    &operand_data[600],
    4,
    0,
    1,
    3
  },
  {
    "*fop_sf_1",
    (const PTR) output_349,
    0,
    &operand_data[604],
    4,
    0,
    2,
    3
  },
  {
    "*fop_sf_2",
    (const PTR) output_350,
    0,
    &operand_data[608],
    4,
    0,
    2,
    3
  },
  {
    "*fop_sf_3",
    (const PTR) output_351,
    0,
    &operand_data[612],
    4,
    0,
    2,
    3
  },
  {
    "*fop_df_1",
    (const PTR) output_352,
    0,
    &operand_data[616],
    4,
    0,
    2,
    3
  },
  {
    "*fop_df_2",
    (const PTR) output_353,
    0,
    &operand_data[620],
    4,
    0,
    2,
    3
  },
  {
    "*fop_df_3",
    (const PTR) output_354,
    0,
    &operand_data[624],
    4,
    0,
    2,
    3
  },
  {
    "*fop_df_4",
    (const PTR) output_355,
    0,
    &operand_data[628],
    4,
    0,
    2,
    3
  },
  {
    "*fop_df_5",
    (const PTR) output_356,
    0,
    &operand_data[632],
    4,
    0,
    2,
    3
  },
  {
    "*fop_xf_1",
    (const PTR) output_357,
    0,
    &operand_data[636],
    4,
    0,
    2,
    3
  },
  {
    "*fop_tf_1",
    (const PTR) output_358,
    0,
    &operand_data[640],
    4,
    0,
    2,
    3
  },
  {
    "*fop_xf_2",
    (const PTR) output_359,
    0,
    &operand_data[644],
    4,
    0,
    2,
    3
  },
  {
    "*fop_tf_2",
    (const PTR) output_360,
    0,
    &operand_data[648],
    4,
    0,
    2,
    3
  },
  {
    "*fop_xf_3",
    (const PTR) output_361,
    0,
    &operand_data[652],
    4,
    0,
    2,
    3
  },
  {
    "*fop_tf_3",
    (const PTR) output_362,
    0,
    &operand_data[656],
    4,
    0,
    2,
    3
  },
  {
    "*fop_xf_4",
    (const PTR) output_363,
    0,
    &operand_data[660],
    4,
    0,
    2,
    3
  },
  {
    "*fop_tf_4",
    (const PTR) output_364,
    0,
    &operand_data[664],
    4,
    0,
    2,
    3
  },
  {
    "*fop_xf_5",
    (const PTR) output_365,
    0,
    &operand_data[668],
    4,
    0,
    2,
    3
  },
  {
    "*fop_tf_5",
    (const PTR) output_366,
    0,
    &operand_data[672],
    4,
    0,
    2,
    3
  },
  {
    "*fop_xf_6",
    (const PTR) output_367,
    0,
    &operand_data[676],
    4,
    0,
    2,
    3
  },
  {
    "*fop_tf_6",
    (const PTR) output_368,
    0,
    &operand_data[680],
    4,
    0,
    2,
    3
  },
  {
    "*fop_xf_7",
    (const PTR) output_369,
    0,
    &operand_data[684],
    4,
    0,
    2,
    3
  },
  {
    "*fop_tf_7",
    (const PTR) output_370,
    0,
    &operand_data[688],
    4,
    0,
    2,
    3
  },
  {
    "sqrtsf2",
    "fsqrt",
    (insn_gen_fn) gen_sqrtsf2,
    &operand_data[470],
    2,
    0,
    1,
    1
  },
  {
    "sqrtdf2",
    "fsqrt",
    (insn_gen_fn) gen_sqrtdf2,
    &operand_data[472],
    2,
    0,
    1,
    1
  },
  {
    "*sqrtextendsfdf2",
    "fsqrt",
    0,
    &operand_data[474],
    2,
    0,
    1,
    1
  },
  {
    "sqrtxf2",
    "fsqrt",
    (insn_gen_fn) gen_sqrtxf2,
    &operand_data[476],
    2,
    0,
    1,
    1
  },
  {
    "sqrttf2",
    "fsqrt",
    (insn_gen_fn) gen_sqrttf2,
    &operand_data[482],
    2,
    0,
    1,
    1
  },
  {
    "*sqrtextenddfxf2",
    "fsqrt",
    0,
    &operand_data[478],
    2,
    0,
    1,
    1
  },
  {
    "*sqrtextenddftf2",
    "fsqrt",
    0,
    &operand_data[484],
    2,
    0,
    1,
    1
  },
  {
    "*sqrtextendsfxf2",
    "fsqrt",
    0,
    &operand_data[480],
    2,
    0,
    1,
    1
  },
  {
    "*sqrtextendsftf2",
    "fsqrt",
    0,
    &operand_data[486],
    2,
    0,
    1,
    1
  },
  {
    "sindf2",
    "fsin",
    (insn_gen_fn) gen_sindf2,
    &operand_data[472],
    2,
    0,
    1,
    1
  },
  {
    "sinsf2",
    "fsin",
    (insn_gen_fn) gen_sinsf2,
    &operand_data[470],
    2,
    0,
    1,
    1
  },
  {
    "*sinextendsfdf2",
    "fsin",
    0,
    &operand_data[474],
    2,
    0,
    1,
    1
  },
  {
    "sinxf2",
    "fsin",
    (insn_gen_fn) gen_sinxf2,
    &operand_data[476],
    2,
    0,
    1,
    1
  },
  {
    "sintf2",
    "fsin",
    (insn_gen_fn) gen_sintf2,
    &operand_data[482],
    2,
    0,
    1,
    1
  },
  {
    "cosdf2",
    "fcos",
    (insn_gen_fn) gen_cosdf2,
    &operand_data[472],
    2,
    0,
    1,
    1
  },
  {
    "cossf2",
    "fcos",
    (insn_gen_fn) gen_cossf2,
    &operand_data[470],
    2,
    0,
    1,
    1
  },
  {
    "*cosextendsfdf2",
    "fcos",
    0,
    &operand_data[474],
    2,
    0,
    1,
    1
  },
  {
    "cosxf2",
    "fcos",
    (insn_gen_fn) gen_cosxf2,
    &operand_data[476],
    2,
    0,
    1,
    1
  },
  {
    "costf2",
    "fcos",
    (insn_gen_fn) gen_costf2,
    &operand_data[482],
    2,
    0,
    1,
    1
  },
  {
    "cld",
    "cld",
    (insn_gen_fn) gen_cld,
    &operand_data[0],
    0,
    0,
    0,
    1
  },
  {
    "strmovsi_1",
    "movsl",
    (insn_gen_fn) gen_strmovsi_1,
    &operand_data[692],
    4,
    2,
    1,
    1
  },
  {
    "strmovhi_1",
    "movsw",
    (insn_gen_fn) gen_strmovhi_1,
    &operand_data[692],
    4,
    2,
    1,
    1
  },
  {
    "strmovqi_1",
    "movsb",
    (insn_gen_fn) gen_strmovqi_1,
    &operand_data[692],
    4,
    2,
    1,
    1
  },
  {
    "rep_movsi",
    "rep\n\tmovsl|rep movsd",
    (insn_gen_fn) gen_rep_movsi,
    &operand_data[696],
    6,
    4,
    1,
    1
  },
  {
    "rep_movqi",
    "rep\n\tmovsb|rep movsb",
    (insn_gen_fn) gen_rep_movqi,
    &operand_data[696],
    6,
    4,
    1,
    1
  },
  {
    "strsetsi_1",
    "stosl",
    (insn_gen_fn) gen_strsetsi_1,
    &operand_data[702],
    3,
    1,
    1,
    1
  },
  {
    "strsethi_1",
    "stosw",
    (insn_gen_fn) gen_strsethi_1,
    &operand_data[705],
    3,
    1,
    1,
    1
  },
  {
    "strsetqi_1",
    "stosb",
    (insn_gen_fn) gen_strsetqi_1,
    &operand_data[708],
    3,
    1,
    1,
    1
  },
  {
    "rep_stossi",
    "rep\n\tstosl|rep stosd",
    (insn_gen_fn) gen_rep_stossi,
    &operand_data[711],
    5,
    2,
    1,
    1
  },
  {
    "rep_stosqi",
    "rep\n\tstosb|rep stosb",
    (insn_gen_fn) gen_rep_stosqi,
    &operand_data[716],
    5,
    2,
    1,
    1
  },
  {
    "cmpstrsi_nz_1",
    "repz{\n\t| }cmpsb",
    (insn_gen_fn) gen_cmpstrsi_nz_1,
    &operand_data[721],
    7,
    0,
    1,
    1
  },
  {
    "cmpstrsi_1",
    "repz{\n\t| }cmpsb",
    (insn_gen_fn) gen_cmpstrsi_1,
    &operand_data[721],
    7,
    0,
    1,
    1
  },
  {
    "strlensi_1",
    "repnz{\n\t| }scasb",
    (insn_gen_fn) gen_strlensi_1,
    &operand_data[728],
    6,
    0,
    1,
    1
  },
  {
    "x86_movsicc_0_m1",
    "sbb{l}\t%0, %0",
    (insn_gen_fn) gen_x86_movsicc_0_m1,
    &operand_data[54],
    1,
    0,
    1,
    1
  },
  {
    "*movsicc_noc",
    (const PTR) output_405,
    0,
    &operand_data[734],
    4,
    0,
    2,
    2
  },
  {
    "*movhicc_noc",
    (const PTR) output_406,
    0,
    &operand_data[738],
    4,
    0,
    2,
    2
  },
  {
    "*movsfcc_1",
    (const PTR) output_407,
    0,
    &operand_data[742],
    4,
    0,
    2,
    2
  },
  {
    "*movdfcc_1",
    (const PTR) output_408,
    0,
    &operand_data[746],
    4,
    0,
    2,
    2
  },
  {
    "*movxfcc_1",
    (const PTR) output_409,
    0,
    &operand_data[750],
    4,
    0,
    2,
    2
  },
  {
    "*movtfcc_1",
    (const PTR) output_410,
    0,
    &operand_data[754],
    4,
    0,
    2,
    2
  },
  {
    "pro_epilogue_adjust_stack",
    (const PTR) output_411,
    (insn_gen_fn) gen_pro_epilogue_adjust_stack,
    &operand_data[758],
    3,
    0,
    2,
    3
  },
  {
    "allocate_stack_worker",
    "call\t__alloca",
    (insn_gen_fn) gen_allocate_stack_worker,
    &operand_data[365],
    1,
    2,
    1,
    1
  },
  {
    "*call_value_pop_0",
    (const PTR) output_413,
    0,
    &operand_data[761],
    4,
    0,
    0,
    3
  },
  {
    "*call_value_pop_1",
    (const PTR) output_414,
    0,
    &operand_data[765],
    4,
    0,
    1,
    3
  },
  {
    "*call_value_0",
    (const PTR) output_415,
    0,
    &operand_data[761],
    3,
    0,
    0,
    3
  },
  {
    "*call_value_1",
    (const PTR) output_416,
    0,
    &operand_data[765],
    3,
    0,
    1,
    3
  },
  {
    "trap",
    "int\t$5",
    (insn_gen_fn) gen_trap,
    &operand_data[0],
    0,
    0,
    0,
    1
  },
  {
    "*i386.md:12737",
    (const PTR) output_418,
    0,
    &operand_data[769],
    2,
    0,
    0,
    3
  },
  {
    "movv4sf_internal",
    "movaps\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_movv4sf_internal,
    &operand_data[771],
    2,
    0,
    2,
    1
  },
  {
    "movv4si_internal",
    "movaps\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_movv4si_internal,
    &operand_data[773],
    2,
    0,
    2,
    1
  },
  {
    "movv8qi_internal",
    "movq\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_movv8qi_internal,
    &operand_data[775],
    2,
    0,
    2,
    1
  },
  {
    "movv4hi_internal",
    "movq\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_movv4hi_internal,
    &operand_data[777],
    2,
    0,
    2,
    1
  },
  {
    "movv2si_internal",
    "movq\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_movv2si_internal,
    &operand_data[779],
    2,
    0,
    2,
    1
  },
  {
    "*pushti",
    "#",
    0,
    &operand_data[781],
    2,
    0,
    1,
    1
  },
  {
    "*pushv4sf",
    "#",
    0,
    &operand_data[783],
    2,
    0,
    1,
    1
  },
  {
    "*pushv4si",
    "#",
    0,
    &operand_data[785],
    2,
    0,
    1,
    1
  },
  {
    "*pushv2si",
    "#",
    0,
    &operand_data[787],
    2,
    0,
    1,
    1
  },
  {
    "*pushv4hi",
    "#",
    0,
    &operand_data[789],
    2,
    0,
    1,
    1
  },
  {
    "*pushv8qi",
    "#",
    0,
    &operand_data[791],
    2,
    0,
    1,
    1
  },
  {
    "movti_internal",
    (const PTR) output_430,
    (insn_gen_fn) gen_movti_internal,
    &operand_data[793],
    2,
    0,
    2,
    2
  },
  {
    "sse_movaps",
    (const PTR) output_431,
    (insn_gen_fn) gen_sse_movaps,
    &operand_data[771],
    2,
    0,
    2,
    2
  },
  {
    "sse_movups",
    (const PTR) output_432,
    (insn_gen_fn) gen_sse_movups,
    &operand_data[771],
    2,
    0,
    2,
    2
  },
  {
    "sse_movmskps",
    "movmskps\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_sse_movmskps,
    &operand_data[795],
    2,
    0,
    1,
    1
  },
  {
    "mmx_pmovmskb",
    "pmovmskb\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_mmx_pmovmskb,
    &operand_data[797],
    2,
    0,
    1,
    1
  },
  {
    "mmx_maskmovq",
    "maskmovq\t{%2, %1|%1, %2}",
    (insn_gen_fn) gen_mmx_maskmovq,
    &operand_data[799],
    3,
    0,
    1,
    1
  },
  {
    "sse_movntv4sf",
    "movntps\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_sse_movntv4sf,
    &operand_data[802],
    2,
    0,
    1,
    1
  },
  {
    "sse_movntdi",
    "movntq\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_sse_movntdi,
    &operand_data[804],
    2,
    0,
    1,
    1
  },
  {
    "sse_movhlps",
    "movhlps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_movhlps,
    &operand_data[806],
    3,
    0,
    1,
    1
  },
  {
    "sse_movlhps",
    "movlhps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_movlhps,
    &operand_data[806],
    3,
    0,
    1,
    1
  },
  {
    "sse_movhps",
    "movhps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_movhps,
    &operand_data[809],
    3,
    0,
    2,
    1
  },
  {
    "sse_movlps",
    "movlps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_movlps,
    &operand_data[809],
    3,
    0,
    2,
    1
  },
  {
    "sse_loadss",
    "movss\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_sse_loadss,
    &operand_data[812],
    2,
    0,
    1,
    1
  },
  {
    "sse_movss",
    "movss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_movss,
    &operand_data[806],
    3,
    0,
    1,
    1
  },
  {
    "sse_storess",
    "movss\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_sse_storess,
    &operand_data[814],
    2,
    0,
    1,
    1
  },
  {
    "sse_shufps",
    "shufps\t{%3, %2, %0|%0, %2, %3}",
    (insn_gen_fn) gen_sse_shufps,
    &operand_data[816],
    4,
    0,
    1,
    1
  },
  {
    "addv4sf3",
    "addps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_addv4sf3,
    &operand_data[816],
    3,
    0,
    1,
    1
  },
  {
    "vmaddv4sf3",
    "addss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_vmaddv4sf3,
    &operand_data[816],
    3,
    1,
    1,
    1
  },
  {
    "subv4sf3",
    "subps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_subv4sf3,
    &operand_data[816],
    3,
    0,
    1,
    1
  },
  {
    "vmsubv4sf3",
    "subss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_vmsubv4sf3,
    &operand_data[816],
    3,
    1,
    1,
    1
  },
  {
    "mulv4sf3",
    "mulps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mulv4sf3,
    &operand_data[816],
    3,
    0,
    1,
    1
  },
  {
    "vmmulv4sf3",
    "mulss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_vmmulv4sf3,
    &operand_data[816],
    3,
    1,
    1,
    1
  },
  {
    "divv4sf3",
    "divps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_divv4sf3,
    &operand_data[816],
    3,
    0,
    1,
    1
  },
  {
    "vmdivv4sf3",
    "divss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_vmdivv4sf3,
    &operand_data[816],
    3,
    1,
    1,
    1
  },
  {
    "rcpv4sf2",
    "rcpps\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_rcpv4sf2,
    &operand_data[820],
    2,
    0,
    1,
    1
  },
  {
    "vmrcpv4sf2",
    "rcpss\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_vmrcpv4sf2,
    &operand_data[820],
    3,
    0,
    1,
    1
  },
  {
    "rsqrtv4sf2",
    "rsqrtps\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_rsqrtv4sf2,
    &operand_data[820],
    2,
    0,
    1,
    1
  },
  {
    "vmrsqrtv4sf2",
    "rsqrtss\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_vmrsqrtv4sf2,
    &operand_data[820],
    3,
    0,
    1,
    1
  },
  {
    "sqrtv4sf2",
    "sqrtps\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_sqrtv4sf2,
    &operand_data[820],
    2,
    0,
    1,
    1
  },
  {
    "vmsqrtv4sf2",
    "sqrtss\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_vmsqrtv4sf2,
    &operand_data[820],
    3,
    0,
    1,
    1
  },
  {
    "sse_andti3",
    "andps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_andti3,
    &operand_data[823],
    3,
    0,
    1,
    1
  },
  {
    "sse_nandti3",
    "andnps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_nandti3,
    &operand_data[823],
    3,
    0,
    1,
    1
  },
  {
    "sse_iorti3",
    "iorps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_iorti3,
    &operand_data[823],
    3,
    0,
    1,
    1
  },
  {
    "sse_xorti3",
    "xorps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_xorti3,
    &operand_data[823],
    3,
    0,
    1,
    1
  },
  {
    "sse_clrti",
    "xorps\t{%0, %0|%0, %0}",
    (insn_gen_fn) gen_sse_clrti,
    &operand_data[823],
    1,
    0,
    1,
    1
  },
  {
    "maskcmpv4sf3",
    (const PTR) output_465,
    (insn_gen_fn) gen_maskcmpv4sf3,
    &operand_data[826],
    4,
    0,
    1,
    3
  },
  {
    "maskncmpv4sf3",
    (const PTR) output_466,
    (insn_gen_fn) gen_maskncmpv4sf3,
    &operand_data[826],
    4,
    0,
    1,
    3
  },
  {
    "vmmaskcmpv4sf3",
    (const PTR) output_467,
    (insn_gen_fn) gen_vmmaskcmpv4sf3,
    &operand_data[826],
    4,
    1,
    1,
    3
  },
  {
    "vmmaskncmpv4sf3",
    (const PTR) output_468,
    (insn_gen_fn) gen_vmmaskncmpv4sf3,
    &operand_data[826],
    4,
    1,
    1,
    3
  },
  {
    "sse_comi",
    "comiss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_comi,
    &operand_data[830],
    3,
    0,
    1,
    1
  },
  {
    "sse_ucomi",
    "ucomiss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_ucomi,
    &operand_data[833],
    3,
    0,
    1,
    1
  },
  {
    "sse_unpckhps",
    "unpckhps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_unpckhps,
    &operand_data[836],
    3,
    0,
    1,
    1
  },
  {
    "sse_unpcklps",
    "unpcklps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sse_unpcklps,
    &operand_data[836],
    3,
    0,
    1,
    1
  },
  {
    "smaxv4sf3",
    "maxps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_smaxv4sf3,
    &operand_data[816],
    3,
    0,
    1,
    1
  },
  {
    "vmsmaxv4sf3",
    "maxss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_vmsmaxv4sf3,
    &operand_data[816],
    3,
    1,
    1,
    1
  },
  {
    "sminv4sf3",
    "minps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sminv4sf3,
    &operand_data[816],
    3,
    0,
    1,
    1
  },
  {
    "vmsminv4sf3",
    "minss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_vmsminv4sf3,
    &operand_data[816],
    3,
    1,
    1,
    1
  },
  {
    "cvtpi2ps",
    "cvtpi2ps\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_cvtpi2ps,
    &operand_data[839],
    3,
    0,
    1,
    1
  },
  {
    "cvtps2pi",
    "cvtps2pi\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_cvtps2pi,
    &operand_data[842],
    2,
    0,
    1,
    1
  },
  {
    "cvttps2pi",
    "cvttps2pi\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_cvttps2pi,
    &operand_data[842],
    2,
    0,
    1,
    1
  },
  {
    "cvtsi2ss",
    "cvtsi2ss\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_cvtsi2ss,
    &operand_data[844],
    3,
    0,
    1,
    1
  },
  {
    "cvtss2si",
    "cvtss2si\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_cvtss2si,
    &operand_data[847],
    2,
    0,
    1,
    1
  },
  {
    "cvttss2si",
    "cvttss2si\t{%1, %0|%0, %1}",
    (insn_gen_fn) gen_cvttss2si,
    &operand_data[847],
    2,
    0,
    1,
    1
  },
  {
    "addv8qi3",
    "paddb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_addv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "addv4hi3",
    "paddw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_addv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "addv2si3",
    "paddd\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_addv2si3,
    &operand_data[855],
    3,
    0,
    1,
    1
  },
  {
    "ssaddv8qi3",
    "paddsb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_ssaddv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "ssaddv4hi3",
    "paddsw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_ssaddv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "usaddv8qi3",
    "paddusb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_usaddv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "usaddv4hi3",
    "paddusw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_usaddv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "subv8qi3",
    "psubb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_subv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "subv4hi3",
    "psubw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_subv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "subv2si3",
    "psubd\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_subv2si3,
    &operand_data[855],
    3,
    0,
    1,
    1
  },
  {
    "sssubv8qi3",
    "psubsb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sssubv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "sssubv4hi3",
    "psubsw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sssubv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "ussubv8qi3",
    "psubusb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_ussubv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "ussubv4hi3",
    "psubusw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_ussubv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "mulv4hi3",
    "pmullw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mulv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "smulv4hi3_highpart",
    "pmulhw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_smulv4hi3_highpart,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "umulv4hi3_highpart",
    "pmulhuw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_umulv4hi3_highpart,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "mmx_pmaddwd",
    "pmaddwd\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_pmaddwd,
    &operand_data[858],
    3,
    2,
    1,
    1
  },
  {
    "mmx_iordi3",
    "por\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_iordi3,
    &operand_data[861],
    3,
    0,
    1,
    1
  },
  {
    "mmx_xordi3",
    "pxor\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_xordi3,
    &operand_data[861],
    3,
    0,
    1,
    1
  },
  {
    "mmx_clrdi",
    "pxor\t{%0, %0|%0, %0}",
    (insn_gen_fn) gen_mmx_clrdi,
    &operand_data[861],
    1,
    0,
    1,
    1
  },
  {
    "mmx_anddi3",
    "pand\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_anddi3,
    &operand_data[861],
    3,
    0,
    1,
    1
  },
  {
    "mmx_nanddi3",
    "pandn\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_nanddi3,
    &operand_data[861],
    3,
    0,
    1,
    1
  },
  {
    "mmx_uavgv8qi3",
    "pavgb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_uavgv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "mmx_uavgv4hi3",
    "pavgw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_uavgv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "mmx_psadbw",
    "psadbw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_psadbw,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "mmx_pinsrw",
    "pinsrw\t{%3, %2, %0|%0, %2, %3}",
    (insn_gen_fn) gen_mmx_pinsrw,
    &operand_data[864],
    4,
    0,
    1,
    1
  },
  {
    "mmx_pextrw",
    "pextrw\t{%2, %1, %0|%0, %1, %2}",
    (insn_gen_fn) gen_mmx_pextrw,
    &operand_data[868],
    3,
    0,
    1,
    1
  },
  {
    "mmx_pshufw",
    "pshufw\t{%3, %2, %0|%0, %2, %3}",
    (insn_gen_fn) gen_mmx_pshufw,
    &operand_data[871],
    4,
    0,
    1,
    1
  },
  {
    "eqv8qi3",
    "pcmpeqb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_eqv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "eqv4hi3",
    "pcmpeqw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_eqv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "eqv2si3",
    "pcmpeqd\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_eqv2si3,
    &operand_data[855],
    3,
    0,
    1,
    1
  },
  {
    "gtv8qi3",
    "pcmpgtb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_gtv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "gtv4hi3",
    "pcmpgtw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_gtv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "gtv2si3",
    "pcmpgtd\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_gtv2si3,
    &operand_data[855],
    3,
    0,
    1,
    1
  },
  {
    "umaxv8qi3",
    "pmaxub\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_umaxv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "smaxv4hi3",
    "pmaxsw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_smaxv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "uminv8qi3",
    "pminub\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_uminv8qi3,
    &operand_data[849],
    3,
    0,
    1,
    1
  },
  {
    "sminv4hi3",
    "pminsw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_sminv4hi3,
    &operand_data[852],
    3,
    0,
    1,
    1
  },
  {
    "ashrv4hi3",
    "psraw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_ashrv4hi3,
    &operand_data[875],
    3,
    0,
    1,
    1
  },
  {
    "ashrv2si3",
    "psrad\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_ashrv2si3,
    &operand_data[878],
    3,
    0,
    1,
    1
  },
  {
    "lshrv4hi3",
    "psrlw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_lshrv4hi3,
    &operand_data[875],
    3,
    0,
    1,
    1
  },
  {
    "lshrv2si3",
    "psrld\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_lshrv2si3,
    &operand_data[878],
    3,
    0,
    1,
    1
  },
  {
    "mmx_lshrdi3",
    "psrlq\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_lshrdi3,
    &operand_data[881],
    3,
    0,
    1,
    1
  },
  {
    "ashlv4hi3",
    "psllw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_ashlv4hi3,
    &operand_data[875],
    3,
    0,
    1,
    1
  },
  {
    "ashlv2si3",
    "pslld\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_ashlv2si3,
    &operand_data[878],
    3,
    0,
    1,
    1
  },
  {
    "mmx_ashldi3",
    "psllq\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_ashldi3,
    &operand_data[881],
    3,
    0,
    1,
    1
  },
  {
    "mmx_packsswb",
    "packsswb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_packsswb,
    &operand_data[884],
    3,
    0,
    1,
    1
  },
  {
    "mmx_packssdw",
    "packssdw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_packssdw,
    &operand_data[887],
    3,
    0,
    1,
    1
  },
  {
    "mmx_packuswb",
    "packuswb\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_packuswb,
    &operand_data[884],
    3,
    0,
    1,
    1
  },
  {
    "mmx_punpckhbw",
    "punpckhbw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_punpckhbw,
    &operand_data[890],
    3,
    0,
    1,
    1
  },
  {
    "mmx_punpckhwd",
    "punpckhwd\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_punpckhwd,
    &operand_data[893],
    3,
    0,
    1,
    1
  },
  {
    "mmx_punpckhdq",
    "punpckhdq\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_punpckhdq,
    &operand_data[896],
    3,
    0,
    1,
    1
  },
  {
    "mmx_punpcklbw",
    "punpcklbw\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_punpcklbw,
    &operand_data[890],
    3,
    0,
    1,
    1
  },
  {
    "mmx_punpcklwd",
    "punpcklwd\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_punpcklwd,
    &operand_data[893],
    3,
    0,
    1,
    1
  },
  {
    "mmx_punpckldq",
    "punpckldq\t{%2, %0|%0, %2}",
    (insn_gen_fn) gen_mmx_punpckldq,
    &operand_data[896],
    3,
    0,
    1,
    1
  },
  {
    "emms",
    "emms",
    (insn_gen_fn) gen_emms,
    &operand_data[0],
    0,
    0,
    0,
    1
  },
  {
    "ldmxcsr",
    "ldmxcsr\t%0",
    (insn_gen_fn) gen_ldmxcsr,
    &operand_data[899],
    1,
    0,
    1,
    1
  },
  {
    "stmxcsr",
    "stmxcsr\t%0",
    (insn_gen_fn) gen_stmxcsr,
    &operand_data[900],
    1,
    0,
    1,
    1
  },
  {
    "*sfence_insn",
    "sfence",
    0,
    &operand_data[901],
    1,
    1,
    0,
    1
  },
  {
    "prefetch",
    (const PTR) output_543,
    (insn_gen_fn) gen_prefetch,
    &operand_data[902],
    2,
    0,
    1,
    3
  },
  {
    "cmpdi",
    0,
    (insn_gen_fn) gen_cmpdi,
    &operand_data[904],
    2,
    0,
    0,
    0
  },
  {
    "cmpsi",
    0,
    (insn_gen_fn) gen_cmpsi,
    &operand_data[906],
    2,
    0,
    0,
    0
  },
  {
    "cmphi",
    0,
    (insn_gen_fn) gen_cmphi,
    &operand_data[908],
    2,
    0,
    0,
    0
  },
  {
    "cmpqi",
    0,
    (insn_gen_fn) gen_cmpqi,
    &operand_data[910],
    2,
    0,
    0,
    0
  },
  {
    "cmpsi_1",
    0,
    (insn_gen_fn) gen_cmpsi_1,
    &operand_data[3],
    2,
    0,
    2,
    0
  },
  {
    "cmpqi_ext_3",
    0,
    (insn_gen_fn) gen_cmpqi_ext_3,
    &operand_data[16],
    2,
    0,
    1,
    0
  },
  {
    "cmpxf",
    0,
    (insn_gen_fn) gen_cmpxf,
    &operand_data[912],
    2,
    0,
    0,
    0
  },
  {
    "cmptf",
    0,
    (insn_gen_fn) gen_cmptf,
    &operand_data[914],
    2,
    0,
    0,
    0
  },
  {
    "cmpdf",
    0,
    (insn_gen_fn) gen_cmpdf,
    &operand_data[916],
    2,
    0,
    0,
    0
  },
  {
    "cmpsf",
    0,
    (insn_gen_fn) gen_cmpsf,
    &operand_data[918],
    2,
    0,
    0,
    0
  },
  {
    "cmpsf+1",
    0,
    0,
    &operand_data[920],
    2,
    0,
    0,
    0
  },
  {
    "movsi",
    0,
    (insn_gen_fn) gen_movsi,
    &operand_data[922],
    2,
    0,
    0,
    0
  },
  {
    "movhi",
    0,
    (insn_gen_fn) gen_movhi,
    &operand_data[924],
    2,
    0,
    0,
    0
  },
  {
    "movstricthi",
    0,
    (insn_gen_fn) gen_movstricthi,
    &operand_data[926],
    2,
    0,
    0,
    0
  },
  {
    "movqi",
    0,
    (insn_gen_fn) gen_movqi,
    &operand_data[928],
    2,
    0,
    0,
    0
  },
  {
    "reload_outqi",
    0,
    (insn_gen_fn) gen_reload_outqi,
    &operand_data[930],
    3,
    0,
    1,
    0
  },
  {
    "movstrictqi",
    0,
    (insn_gen_fn) gen_movstrictqi,
    &operand_data[933],
    2,
    0,
    0,
    0
  },
  {
    "movdi",
    0,
    (insn_gen_fn) gen_movdi,
    &operand_data[935],
    2,
    0,
    0,
    0
  },
  {
    "movdi+1",
    0,
    0,
    &operand_data[937],
    2,
    0,
    0,
    0
  },
  {
    "movsf-1",
    0,
    0,
    &operand_data[935],
    2,
    0,
    0,
    0
  },
  {
    "movsf",
    0,
    (insn_gen_fn) gen_movsf,
    &operand_data[939],
    2,
    0,
    0,
    0
  },
  {
    "movsf+1",
    0,
    0,
    &operand_data[941],
    2,
    0,
    0,
    0
  },
  {
    "movsf+2",
    0,
    0,
    &operand_data[943],
    2,
    0,
    0,
    0
  },
  {
    "movdf-1",
    0,
    0,
    &operand_data[945],
    2,
    0,
    0,
    0
  },
  {
    "movdf",
    0,
    (insn_gen_fn) gen_movdf,
    &operand_data[947],
    2,
    0,
    0,
    0
  },
  {
    "movdf+1",
    0,
    0,
    &operand_data[949],
    2,
    0,
    0,
    0
  },
  {
    "movdf+2",
    0,
    0,
    &operand_data[951],
    2,
    0,
    0,
    0
  },
  {
    "movxf-2",
    0,
    0,
    &operand_data[947],
    2,
    0,
    0,
    0
  },
  {
    "movxf-1",
    0,
    0,
    &operand_data[953],
    2,
    0,
    0,
    0
  },
  {
    "movxf",
    0,
    (insn_gen_fn) gen_movxf,
    &operand_data[955],
    2,
    0,
    0,
    0
  },
  {
    "movtf",
    0,
    (insn_gen_fn) gen_movtf,
    &operand_data[957],
    2,
    0,
    0,
    0
  },
  {
    "movtf+1",
    0,
    0,
    &operand_data[959],
    2,
    0,
    0,
    0
  },
  {
    "movtf+2",
    0,
    0,
    &operand_data[961],
    2,
    0,
    0,
    0
  },
  {
    "movtf+3",
    0,
    0,
    &operand_data[963],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendhisi2-2",
    0,
    0,
    &operand_data[965],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendhisi2-1",
    0,
    0,
    &operand_data[967],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendhisi2",
    0,
    (insn_gen_fn) gen_zero_extendhisi2,
    &operand_data[969],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendhisi2+1",
    0,
    0,
    &operand_data[971],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqihi2",
    0,
    (insn_gen_fn) gen_zero_extendqihi2,
    &operand_data[972],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqihi2+1",
    0,
    0,
    &operand_data[972],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqihi2+2",
    0,
    0,
    &operand_data[972],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqisi2-1",
    0,
    0,
    &operand_data[974],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqisi2",
    0,
    (insn_gen_fn) gen_zero_extendqisi2,
    &operand_data[976],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqisi2+1",
    0,
    0,
    &operand_data[976],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqisi2+2",
    0,
    0,
    &operand_data[976],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqisi2+3",
    0,
    0,
    &operand_data[978],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqisi2+4",
    0,
    0,
    &operand_data[980],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqisi2+5",
    0,
    0,
    &operand_data[982],
    2,
    0,
    0,
    0
  },
  {
    "zero_extendqisi2+6",
    0,
    0,
    &operand_data[984],
    3,
    0,
    0,
    0
  },
  {
    "zero_extendqisi2+7",
    0,
    0,
    &operand_data[984],
    3,
    0,
    0,
    0
  },
  {
    "extendsfdf2-6",
    0,
    0,
    &operand_data[987],
    3,
    0,
    0,
    0
  },
  {
    "extendsfdf2-5",
    0,
    0,
    &operand_data[990],
    2,
    0,
    0,
    0
  },
  {
    "extendsfdf2-4",
    0,
    0,
    &operand_data[992],
    2,
    0,
    0,
    0
  },
  {
    "extendsfdf2-3",
    0,
    0,
    &operand_data[994],
    2,
    0,
    0,
    0
  },
  {
    "extendsfdf2-2",
    0,
    0,
    &operand_data[996],
    2,
    0,
    0,
    0
  },
  {
    "extendsfdf2-1",
    0,
    0,
    &operand_data[998],
    2,
    0,
    0,
    0
  },
  {
    "extendsfdf2",
    0,
    (insn_gen_fn) gen_extendsfdf2,
    &operand_data[1000],
    2,
    0,
    0,
    0
  },
  {
    "extendsfxf2",
    0,
    (insn_gen_fn) gen_extendsfxf2,
    &operand_data[1002],
    2,
    0,
    0,
    0
  },
  {
    "extendsftf2",
    0,
    (insn_gen_fn) gen_extendsftf2,
    &operand_data[1004],
    2,
    0,
    0,
    0
  },
  {
    "extenddfxf2",
    0,
    (insn_gen_fn) gen_extenddfxf2,
    &operand_data[1006],
    2,
    0,
    0,
    0
  },
  {
    "extenddftf2",
    0,
    (insn_gen_fn) gen_extenddftf2,
    &operand_data[1008],
    2,
    0,
    0,
    0
  },
  {
    "truncdfsf2",
    0,
    (insn_gen_fn) gen_truncdfsf2,
    &operand_data[1010],
    2,
    1,
    0,
    0
  },
  {
    "truncdfsf2+1",
    0,
    0,
    &operand_data[1012],
    3,
    0,
    0,
    0
  },
  {
    "truncxfsf2-1",
    0,
    0,
    &operand_data[1015],
    3,
    0,
    0,
    0
  },
  {
    "truncxfsf2",
    0,
    (insn_gen_fn) gen_truncxfsf2,
    &operand_data[1018],
    2,
    1,
    0,
    0
  },
  {
    "truncxfsf2+1",
    0,
    0,
    &operand_data[1020],
    3,
    0,
    0,
    0
  },
  {
    "trunctfsf2-1",
    0,
    0,
    &operand_data[1023],
    3,
    0,
    0,
    0
  },
  {
    "trunctfsf2",
    0,
    (insn_gen_fn) gen_trunctfsf2,
    &operand_data[1026],
    2,
    1,
    0,
    0
  },
  {
    "trunctfsf2+1",
    0,
    0,
    &operand_data[1028],
    3,
    0,
    0,
    0
  },
  {
    "truncxfdf2-1",
    0,
    0,
    &operand_data[1031],
    3,
    0,
    0,
    0
  },
  {
    "truncxfdf2",
    0,
    (insn_gen_fn) gen_truncxfdf2,
    &operand_data[1034],
    2,
    1,
    0,
    0
  },
  {
    "truncxfdf2+1",
    0,
    0,
    &operand_data[1036],
    3,
    0,
    0,
    0
  },
  {
    "trunctfdf2-1",
    0,
    0,
    &operand_data[1039],
    3,
    0,
    0,
    0
  },
  {
    "trunctfdf2",
    0,
    (insn_gen_fn) gen_trunctfdf2,
    &operand_data[1042],
    2,
    1,
    0,
    0
  },
  {
    "trunctfdf2+1",
    0,
    0,
    &operand_data[1044],
    3,
    0,
    0,
    0
  },
  {
    "fix_truncxfdi2-1",
    0,
    0,
    &operand_data[1047],
    3,
    0,
    0,
    0
  },
  {
    "fix_truncxfdi2",
    0,
    (insn_gen_fn) gen_fix_truncxfdi2,
    &operand_data[1050],
    6,
    2,
    0,
    0
  },
  {
    "fix_trunctfdi2",
    0,
    (insn_gen_fn) gen_fix_trunctfdi2,
    &operand_data[1056],
    6,
    2,
    0,
    0
  },
  {
    "fix_truncdfdi2",
    0,
    (insn_gen_fn) gen_fix_truncdfdi2,
    &operand_data[1062],
    6,
    2,
    0,
    0
  },
  {
    "fix_truncsfdi2",
    0,
    (insn_gen_fn) gen_fix_truncsfdi2,
    &operand_data[1068],
    6,
    2,
    0,
    0
  },
  {
    "fix_truncsfdi2+1",
    0,
    0,
    &operand_data[1074],
    6,
    0,
    0,
    0
  },
  {
    "fix_truncxfsi2",
    0,
    (insn_gen_fn) gen_fix_truncxfsi2,
    &operand_data[1080],
    5,
    2,
    0,
    0
  },
  {
    "fix_trunctfsi2",
    0,
    (insn_gen_fn) gen_fix_trunctfsi2,
    &operand_data[1085],
    5,
    2,
    0,
    0
  },
  {
    "fix_truncdfsi2",
    0,
    (insn_gen_fn) gen_fix_truncdfsi2,
    &operand_data[1090],
    5,
    2,
    0,
    0
  },
  {
    "fix_truncsfsi2",
    0,
    (insn_gen_fn) gen_fix_truncsfsi2,
    &operand_data[1095],
    5,
    2,
    0,
    0
  },
  {
    "fix_truncsfsi2+1",
    0,
    0,
    &operand_data[1100],
    5,
    0,
    0,
    0
  },
  {
    "fix_truncxfhi2",
    0,
    (insn_gen_fn) gen_fix_truncxfhi2,
    &operand_data[1105],
    5,
    2,
    0,
    0
  },
  {
    "fix_trunctfhi2",
    0,
    (insn_gen_fn) gen_fix_trunctfhi2,
    &operand_data[1110],
    5,
    2,
    0,
    0
  },
  {
    "fix_truncdfhi2",
    0,
    (insn_gen_fn) gen_fix_truncdfhi2,
    &operand_data[1115],
    5,
    2,
    0,
    0
  },
  {
    "fix_truncsfhi2",
    0,
    (insn_gen_fn) gen_fix_truncsfhi2,
    &operand_data[1120],
    5,
    2,
    0,
    0
  },
  {
    "fix_truncsfhi2+1",
    0,
    0,
    &operand_data[1125],
    5,
    0,
    0,
    0
  },
  {
    "fix_truncsfhi2+2",
    0,
    0,
    &operand_data[1130],
    2,
    0,
    0,
    0
  },
  {
    "addsi3-1",
    0,
    0,
    &operand_data[1132],
    3,
    0,
    0,
    0
  },
  {
    "addsi3",
    0,
    (insn_gen_fn) gen_addsi3,
    &operand_data[1135],
    3,
    0,
    0,
    0
  },
  {
    "addsi3+1",
    0,
    0,
    &operand_data[1138],
    4,
    0,
    0,
    0
  },
  {
    "addsi3+2",
    0,
    0,
    &operand_data[1142],
    4,
    0,
    0,
    0
  },
  {
    "addhi3-2",
    0,
    0,
    &operand_data[1146],
    5,
    0,
    0,
    0
  },
  {
    "addhi3-1",
    0,
    0,
    &operand_data[1151],
    3,
    0,
    0,
    0
  },
  {
    "addhi3",
    0,
    (insn_gen_fn) gen_addhi3,
    &operand_data[1154],
    3,
    0,
    0,
    0
  },
  {
    "addqi3",
    0,
    (insn_gen_fn) gen_addqi3,
    &operand_data[1157],
    3,
    0,
    0,
    0
  },
  {
    "addxf3",
    0,
    (insn_gen_fn) gen_addxf3,
    &operand_data[1160],
    3,
    0,
    0,
    0
  },
  {
    "addtf3",
    0,
    (insn_gen_fn) gen_addtf3,
    &operand_data[1163],
    3,
    0,
    0,
    0
  },
  {
    "adddf3",
    0,
    (insn_gen_fn) gen_adddf3,
    &operand_data[1166],
    3,
    0,
    0,
    0
  },
  {
    "addsf3",
    0,
    (insn_gen_fn) gen_addsf3,
    &operand_data[1169],
    3,
    0,
    0,
    0
  },
  {
    "addsf3+1",
    0,
    0,
    &operand_data[1132],
    3,
    0,
    0,
    0
  },
  {
    "subsi3",
    0,
    (insn_gen_fn) gen_subsi3,
    &operand_data[1135],
    3,
    0,
    0,
    0
  },
  {
    "subhi3",
    0,
    (insn_gen_fn) gen_subhi3,
    &operand_data[1154],
    3,
    0,
    0,
    0
  },
  {
    "subqi3",
    0,
    (insn_gen_fn) gen_subqi3,
    &operand_data[1157],
    3,
    0,
    0,
    0
  },
  {
    "subxf3",
    0,
    (insn_gen_fn) gen_subxf3,
    &operand_data[1160],
    3,
    0,
    0,
    0
  },
  {
    "subtf3",
    0,
    (insn_gen_fn) gen_subtf3,
    &operand_data[1163],
    3,
    0,
    0,
    0
  },
  {
    "subdf3",
    0,
    (insn_gen_fn) gen_subdf3,
    &operand_data[1166],
    3,
    0,
    0,
    0
  },
  {
    "subsf3",
    0,
    (insn_gen_fn) gen_subsf3,
    &operand_data[1169],
    3,
    0,
    0,
    0
  },
  {
    "mulsi3",
    0,
    (insn_gen_fn) gen_mulsi3,
    &operand_data[1172],
    3,
    0,
    0,
    0
  },
  {
    "mulhi3",
    0,
    (insn_gen_fn) gen_mulhi3,
    &operand_data[1175],
    3,
    0,
    0,
    0
  },
  {
    "mulxf3",
    0,
    (insn_gen_fn) gen_mulxf3,
    &operand_data[1160],
    3,
    0,
    0,
    0
  },
  {
    "multf3",
    0,
    (insn_gen_fn) gen_multf3,
    &operand_data[1163],
    3,
    0,
    0,
    0
  },
  {
    "muldf3",
    0,
    (insn_gen_fn) gen_muldf3,
    &operand_data[1166],
    3,
    0,
    0,
    0
  },
  {
    "mulsf3",
    0,
    (insn_gen_fn) gen_mulsf3,
    &operand_data[1169],
    3,
    0,
    0,
    0
  },
  {
    "divxf3",
    0,
    (insn_gen_fn) gen_divxf3,
    &operand_data[1160],
    3,
    0,
    0,
    0
  },
  {
    "divtf3",
    0,
    (insn_gen_fn) gen_divtf3,
    &operand_data[1163],
    3,
    0,
    0,
    0
  },
  {
    "divdf3",
    0,
    (insn_gen_fn) gen_divdf3,
    &operand_data[1166],
    3,
    0,
    0,
    0
  },
  {
    "divsf3",
    0,
    (insn_gen_fn) gen_divsf3,
    &operand_data[1169],
    3,
    0,
    0,
    0
  },
  {
    "divmodsi4",
    0,
    (insn_gen_fn) gen_divmodsi4,
    &operand_data[1178],
    4,
    2,
    0,
    0
  },
  {
    "divmodsi4+1",
    0,
    0,
    &operand_data[1178],
    4,
    0,
    0,
    0
  },
  {
    "udivmodhi4-1",
    0,
    0,
    &operand_data[1178],
    4,
    0,
    0,
    0
  },
  {
    "udivmodhi4",
    0,
    (insn_gen_fn) gen_udivmodhi4,
    &operand_data[1182],
    4,
    4,
    0,
    0
  },
  {
    "testsi_ccno_1",
    0,
    (insn_gen_fn) gen_testsi_ccno_1,
    &operand_data[1186],
    2,
    0,
    0,
    0
  },
  {
    "testqi_ccz_1",
    0,
    (insn_gen_fn) gen_testqi_ccz_1,
    &operand_data[1188],
    2,
    0,
    0,
    0
  },
  {
    "testqi_ext_ccno_0",
    0,
    (insn_gen_fn) gen_testqi_ext_ccno_0,
    &operand_data[1190],
    2,
    0,
    0,
    0
  },
  {
    "testqi_ext_ccno_0+1",
    0,
    0,
    &operand_data[395],
    3,
    0,
    0,
    0
  },
  {
    "andsi3",
    0,
    (insn_gen_fn) gen_andsi3,
    &operand_data[1135],
    3,
    0,
    0,
    0
  },
  {
    "andsi3+1",
    0,
    0,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "andsi3+2",
    0,
    0,
    &operand_data[1192],
    1,
    0,
    0,
    0
  },
  {
    "andhi3-1",
    0,
    0,
    &operand_data[1192],
    1,
    0,
    0,
    0
  },
  {
    "andhi3",
    0,
    (insn_gen_fn) gen_andhi3,
    &operand_data[1154],
    3,
    0,
    0,
    0
  },
  {
    "andqi3",
    0,
    (insn_gen_fn) gen_andqi3,
    &operand_data[1157],
    3,
    0,
    0,
    0
  },
  {
    "iorsi3",
    0,
    (insn_gen_fn) gen_iorsi3,
    &operand_data[1135],
    3,
    0,
    0,
    0
  },
  {
    "iorhi3",
    0,
    (insn_gen_fn) gen_iorhi3,
    &operand_data[1154],
    3,
    0,
    0,
    0
  },
  {
    "iorqi3",
    0,
    (insn_gen_fn) gen_iorqi3,
    &operand_data[1157],
    3,
    0,
    0,
    0
  },
  {
    "xorsi3",
    0,
    (insn_gen_fn) gen_xorsi3,
    &operand_data[1135],
    3,
    0,
    0,
    0
  },
  {
    "xorhi3",
    0,
    (insn_gen_fn) gen_xorhi3,
    &operand_data[1154],
    3,
    0,
    0,
    0
  },
  {
    "xorqi3",
    0,
    (insn_gen_fn) gen_xorqi3,
    &operand_data[1157],
    3,
    0,
    0,
    0
  },
  {
    "xorqi_cc_ext_1",
    0,
    (insn_gen_fn) gen_xorqi_cc_ext_1,
    &operand_data[1193],
    3,
    2,
    0,
    0
  },
  {
    "negdi2",
    0,
    (insn_gen_fn) gen_negdi2,
    &operand_data[1132],
    2,
    0,
    0,
    0
  },
  {
    "negdi2+1",
    0,
    0,
    &operand_data[935],
    2,
    0,
    0,
    0
  },
  {
    "negsi2",
    0,
    (insn_gen_fn) gen_negsi2,
    &operand_data[1135],
    2,
    0,
    0,
    0
  },
  {
    "neghi2",
    0,
    (insn_gen_fn) gen_neghi2,
    &operand_data[1154],
    2,
    0,
    0,
    0
  },
  {
    "negqi2",
    0,
    (insn_gen_fn) gen_negqi2,
    &operand_data[1157],
    2,
    0,
    0,
    0
  },
  {
    "negsf2",
    0,
    (insn_gen_fn) gen_negsf2,
    &operand_data[1196],
    2,
    0,
    0,
    0
  },
  {
    "negsf2+1",
    0,
    0,
    &operand_data[1169],
    2,
    0,
    0,
    0
  },
  {
    "negsf2+2",
    0,
    0,
    &operand_data[1169],
    2,
    0,
    0,
    0
  },
  {
    "negdf2-1",
    0,
    0,
    &operand_data[1198],
    2,
    0,
    0,
    0
  },
  {
    "negdf2",
    0,
    (insn_gen_fn) gen_negdf2,
    &operand_data[1200],
    2,
    0,
    0,
    0
  },
  {
    "negdf2+1",
    0,
    0,
    &operand_data[1166],
    2,
    0,
    0,
    0
  },
  {
    "negxf2-1",
    0,
    0,
    &operand_data[1166],
    2,
    0,
    0,
    0
  },
  {
    "negxf2",
    0,
    (insn_gen_fn) gen_negxf2,
    &operand_data[1202],
    2,
    0,
    0,
    0
  },
  {
    "negtf2",
    0,
    (insn_gen_fn) gen_negtf2,
    &operand_data[1204],
    2,
    0,
    0,
    0
  },
  {
    "negtf2+1",
    0,
    0,
    &operand_data[1160],
    2,
    0,
    0,
    0
  },
  {
    "negtf2+2",
    0,
    0,
    &operand_data[1160],
    2,
    0,
    0,
    0
  },
  {
    "abssf2-2",
    0,
    0,
    &operand_data[1163],
    2,
    0,
    0,
    0
  },
  {
    "abssf2-1",
    0,
    0,
    &operand_data[1163],
    2,
    0,
    0,
    0
  },
  {
    "abssf2",
    0,
    (insn_gen_fn) gen_abssf2,
    &operand_data[1196],
    2,
    0,
    0,
    0
  },
  {
    "abssf2+1",
    0,
    0,
    &operand_data[1169],
    2,
    0,
    0,
    0
  },
  {
    "abssf2+2",
    0,
    0,
    &operand_data[1169],
    2,
    0,
    0,
    0
  },
  {
    "absdf2-1",
    0,
    0,
    &operand_data[1198],
    2,
    0,
    0,
    0
  },
  {
    "absdf2",
    0,
    (insn_gen_fn) gen_absdf2,
    &operand_data[1200],
    2,
    0,
    0,
    0
  },
  {
    "absdf2+1",
    0,
    0,
    &operand_data[1166],
    2,
    0,
    0,
    0
  },
  {
    "absxf2-1",
    0,
    0,
    &operand_data[1166],
    2,
    0,
    0,
    0
  },
  {
    "absxf2",
    0,
    (insn_gen_fn) gen_absxf2,
    &operand_data[1202],
    2,
    0,
    0,
    0
  },
  {
    "abstf2",
    0,
    (insn_gen_fn) gen_abstf2,
    &operand_data[1204],
    2,
    0,
    0,
    0
  },
  {
    "abstf2+1",
    0,
    0,
    &operand_data[1160],
    2,
    0,
    0,
    0
  },
  {
    "abstf2+2",
    0,
    0,
    &operand_data[1160],
    2,
    0,
    0,
    0
  },
  {
    "one_cmplsi2-2",
    0,
    0,
    &operand_data[1163],
    2,
    0,
    0,
    0
  },
  {
    "one_cmplsi2-1",
    0,
    0,
    &operand_data[1163],
    2,
    0,
    0,
    0
  },
  {
    "one_cmplsi2",
    0,
    (insn_gen_fn) gen_one_cmplsi2,
    &operand_data[1135],
    2,
    0,
    0,
    0
  },
  {
    "one_cmplsi2+1",
    0,
    0,
    &operand_data[1135],
    2,
    0,
    0,
    0
  },
  {
    "one_cmplhi2",
    0,
    (insn_gen_fn) gen_one_cmplhi2,
    &operand_data[1154],
    2,
    0,
    0,
    0
  },
  {
    "one_cmplhi2+1",
    0,
    0,
    &operand_data[1154],
    2,
    0,
    0,
    0
  },
  {
    "one_cmplqi2",
    0,
    (insn_gen_fn) gen_one_cmplqi2,
    &operand_data[1157],
    2,
    0,
    0,
    0
  },
  {
    "one_cmplqi2+1",
    0,
    0,
    &operand_data[1157],
    2,
    0,
    0,
    0
  },
  {
    "ashldi3",
    0,
    (insn_gen_fn) gen_ashldi3,
    &operand_data[490],
    3,
    0,
    1,
    0
  },
  {
    "ashldi3+1",
    0,
    0,
    &operand_data[1206],
    4,
    0,
    0,
    0
  },
  {
    "x86_shift_adj_1-1",
    0,
    0,
    &operand_data[1206],
    3,
    0,
    0,
    0
  },
  {
    "x86_shift_adj_1",
    0,
    (insn_gen_fn) gen_x86_shift_adj_1,
    &operand_data[1210],
    4,
    3,
    1,
    0
  },
  {
    "x86_shift_adj_2",
    0,
    (insn_gen_fn) gen_x86_shift_adj_2,
    &operand_data[1210],
    3,
    0,
    0,
    0
  },
  {
    "ashlsi3",
    0,
    (insn_gen_fn) gen_ashlsi3,
    &operand_data[1214],
    3,
    0,
    0,
    0
  },
  {
    "ashlsi3+1",
    0,
    0,
    &operand_data[1217],
    3,
    0,
    0,
    0
  },
  {
    "ashlhi3",
    0,
    (insn_gen_fn) gen_ashlhi3,
    &operand_data[1220],
    3,
    0,
    0,
    0
  },
  {
    "ashlqi3",
    0,
    (insn_gen_fn) gen_ashlqi3,
    &operand_data[1223],
    3,
    0,
    0,
    0
  },
  {
    "ashrdi3",
    0,
    (insn_gen_fn) gen_ashrdi3,
    &operand_data[490],
    3,
    0,
    1,
    0
  },
  {
    "ashrdi3+1",
    0,
    0,
    &operand_data[1206],
    4,
    0,
    0,
    0
  },
  {
    "x86_shift_adj_3-1",
    0,
    0,
    &operand_data[1206],
    3,
    0,
    0,
    0
  },
  {
    "x86_shift_adj_3",
    0,
    (insn_gen_fn) gen_x86_shift_adj_3,
    &operand_data[1210],
    3,
    0,
    0,
    0
  },
  {
    "ashrsi3",
    0,
    (insn_gen_fn) gen_ashrsi3,
    &operand_data[1214],
    3,
    0,
    0,
    0
  },
  {
    "ashrhi3",
    0,
    (insn_gen_fn) gen_ashrhi3,
    &operand_data[1220],
    3,
    0,
    0,
    0
  },
  {
    "ashrqi3",
    0,
    (insn_gen_fn) gen_ashrqi3,
    &operand_data[1223],
    3,
    0,
    0,
    0
  },
  {
    "lshrdi3",
    0,
    (insn_gen_fn) gen_lshrdi3,
    &operand_data[490],
    3,
    0,
    1,
    0
  },
  {
    "lshrdi3+1",
    0,
    0,
    &operand_data[1206],
    4,
    0,
    0,
    0
  },
  {
    "lshrsi3-1",
    0,
    0,
    &operand_data[1206],
    3,
    0,
    0,
    0
  },
  {
    "lshrsi3",
    0,
    (insn_gen_fn) gen_lshrsi3,
    &operand_data[1214],
    3,
    0,
    0,
    0
  },
  {
    "lshrhi3",
    0,
    (insn_gen_fn) gen_lshrhi3,
    &operand_data[1220],
    3,
    0,
    0,
    0
  },
  {
    "lshrqi3",
    0,
    (insn_gen_fn) gen_lshrqi3,
    &operand_data[1223],
    3,
    0,
    0,
    0
  },
  {
    "rotlsi3",
    0,
    (insn_gen_fn) gen_rotlsi3,
    &operand_data[1214],
    3,
    0,
    0,
    0
  },
  {
    "rotlhi3",
    0,
    (insn_gen_fn) gen_rotlhi3,
    &operand_data[1220],
    3,
    0,
    0,
    0
  },
  {
    "rotlqi3",
    0,
    (insn_gen_fn) gen_rotlqi3,
    &operand_data[1223],
    3,
    0,
    0,
    0
  },
  {
    "rotrsi3",
    0,
    (insn_gen_fn) gen_rotrsi3,
    &operand_data[1214],
    3,
    0,
    0,
    0
  },
  {
    "rotrhi3",
    0,
    (insn_gen_fn) gen_rotrhi3,
    &operand_data[1220],
    3,
    0,
    0,
    0
  },
  {
    "rotrqi3",
    0,
    (insn_gen_fn) gen_rotrqi3,
    &operand_data[1223],
    3,
    0,
    0,
    0
  },
  {
    "extv",
    0,
    (insn_gen_fn) gen_extv,
    &operand_data[1226],
    4,
    0,
    0,
    0
  },
  {
    "extzv",
    0,
    (insn_gen_fn) gen_extzv,
    &operand_data[1230],
    4,
    0,
    0,
    0
  },
  {
    "insv",
    0,
    (insn_gen_fn) gen_insv,
    &operand_data[1231],
    4,
    0,
    0,
    0
  },
  {
    "seq",
    0,
    (insn_gen_fn) gen_seq,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sne",
    0,
    (insn_gen_fn) gen_sne,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sgt",
    0,
    (insn_gen_fn) gen_sgt,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sgtu",
    0,
    (insn_gen_fn) gen_sgtu,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "slt",
    0,
    (insn_gen_fn) gen_slt,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sltu",
    0,
    (insn_gen_fn) gen_sltu,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sge",
    0,
    (insn_gen_fn) gen_sge,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sgeu",
    0,
    (insn_gen_fn) gen_sgeu,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sle",
    0,
    (insn_gen_fn) gen_sle,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sleu",
    0,
    (insn_gen_fn) gen_sleu,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sunordered",
    0,
    (insn_gen_fn) gen_sunordered,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sordered",
    0,
    (insn_gen_fn) gen_sordered,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "suneq",
    0,
    (insn_gen_fn) gen_suneq,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sunge",
    0,
    (insn_gen_fn) gen_sunge,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sungt",
    0,
    (insn_gen_fn) gen_sungt,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sunle",
    0,
    (insn_gen_fn) gen_sunle,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sunlt",
    0,
    (insn_gen_fn) gen_sunlt,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "sltgt",
    0,
    (insn_gen_fn) gen_sltgt,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "beq",
    0,
    (insn_gen_fn) gen_beq,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bne",
    0,
    (insn_gen_fn) gen_bne,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bgt",
    0,
    (insn_gen_fn) gen_bgt,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bgtu",
    0,
    (insn_gen_fn) gen_bgtu,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "blt",
    0,
    (insn_gen_fn) gen_blt,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bltu",
    0,
    (insn_gen_fn) gen_bltu,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bge",
    0,
    (insn_gen_fn) gen_bge,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bgeu",
    0,
    (insn_gen_fn) gen_bgeu,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "ble",
    0,
    (insn_gen_fn) gen_ble,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bleu",
    0,
    (insn_gen_fn) gen_bleu,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bunordered",
    0,
    (insn_gen_fn) gen_bunordered,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bordered",
    0,
    (insn_gen_fn) gen_bordered,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "buneq",
    0,
    (insn_gen_fn) gen_buneq,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bunge",
    0,
    (insn_gen_fn) gen_bunge,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bungt",
    0,
    (insn_gen_fn) gen_bungt,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bunle",
    0,
    (insn_gen_fn) gen_bunle,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bunlt",
    0,
    (insn_gen_fn) gen_bunlt,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bltgt",
    0,
    (insn_gen_fn) gen_bltgt,
    &operand_data[552],
    1,
    1,
    0,
    0
  },
  {
    "bltgt+1",
    0,
    0,
    &operand_data[1235],
    5,
    0,
    0,
    0
  },
  {
    "casesi-1",
    0,
    0,
    &operand_data[1235],
    6,
    0,
    0,
    0
  },
  {
    "casesi",
    0,
    (insn_gen_fn) gen_casesi,
    &operand_data[1241],
    5,
    10,
    0,
    0
  },
  {
    "doloop_end",
    0,
    (insn_gen_fn) gen_doloop_end,
    &operand_data[1244],
    5,
    0,
    0,
    0
  },
  {
    "doloop_end+1",
    0,
    0,
    &operand_data[1248],
    3,
    0,
    0,
    0
  },
  {
    "doloop_end+2",
    0,
    0,
    &operand_data[1251],
    4,
    0,
    0,
    0
  },
  {
    "call_pop-1",
    0,
    0,
    &operand_data[1255],
    4,
    0,
    0,
    0
  },
  {
    "call_pop",
    0,
    (insn_gen_fn) gen_call_pop,
    &operand_data[1259],
    4,
    0,
    0,
    0
  },
  {
    "call",
    0,
    (insn_gen_fn) gen_call,
    &operand_data[1259],
    2,
    0,
    0,
    0
  },
  {
    "call_value_pop",
    0,
    (insn_gen_fn) gen_call_value_pop,
    &operand_data[1263],
    5,
    0,
    0,
    0
  },
  {
    "call_value",
    0,
    (insn_gen_fn) gen_call_value,
    &operand_data[1263],
    3,
    0,
    0,
    0
  },
  {
    "untyped_call",
    0,
    (insn_gen_fn) gen_untyped_call,
    &operand_data[1244],
    3,
    0,
    0,
    0
  },
  {
    "return",
    0,
    (insn_gen_fn) gen_return,
    &operand_data[0],
    0,
    0,
    0,
    0
  },
  {
    "prologue",
    0,
    (insn_gen_fn) gen_prologue,
    &operand_data[0],
    0,
    0,
    0,
    0
  },
  {
    "epilogue",
    0,
    (insn_gen_fn) gen_epilogue,
    &operand_data[0],
    0,
    0,
    0,
    0
  },
  {
    "sibcall_epilogue",
    0,
    (insn_gen_fn) gen_sibcall_epilogue,
    &operand_data[0],
    0,
    0,
    0,
    0
  },
  {
    "eh_return",
    0,
    (insn_gen_fn) gen_eh_return,
    &operand_data[1130],
    2,
    0,
    0,
    0
  },
  {
    "eh_return+1",
    0,
    0,
    &operand_data[967],
    1,
    0,
    0,
    0
  },
  {
    "ffssi2",
    0,
    (insn_gen_fn) gen_ffssi2,
    &operand_data[922],
    2,
    0,
    0,
    0
  },
  {
    "ffssi2+1",
    0,
    0,
    &operand_data[1268],
    4,
    0,
    0,
    0
  },
  {
    "movstrsi-1",
    0,
    0,
    &operand_data[1272],
    4,
    0,
    0,
    0
  },
  {
    "movstrsi",
    0,
    (insn_gen_fn) gen_movstrsi,
    &operand_data[1276],
    4,
    0,
    0,
    0
  },
  {
    "strmovsi",
    0,
    (insn_gen_fn) gen_strmovsi,
    &operand_data[985],
    2,
    6,
    0,
    0
  },
  {
    "strmovhi",
    0,
    (insn_gen_fn) gen_strmovhi,
    &operand_data[985],
    2,
    6,
    0,
    0
  },
  {
    "strmovqi",
    0,
    (insn_gen_fn) gen_strmovqi,
    &operand_data[985],
    2,
    6,
    0,
    0
  },
  {
    "clrstrsi",
    0,
    (insn_gen_fn) gen_clrstrsi,
    &operand_data[1277],
    3,
    0,
    0,
    0
  },
  {
    "strsetsi",
    0,
    (insn_gen_fn) gen_strsetsi,
    &operand_data[985],
    2,
    2,
    0,
    0
  },
  {
    "strsethi",
    0,
    (insn_gen_fn) gen_strsethi,
    &operand_data[971],
    2,
    2,
    0,
    0
  },
  {
    "strsetqi",
    0,
    (insn_gen_fn) gen_strsetqi,
    &operand_data[978],
    2,
    2,
    0,
    0
  },
  {
    "cmpstrsi",
    0,
    (insn_gen_fn) gen_cmpstrsi,
    &operand_data[1280],
    5,
    0,
    0,
    0
  },
  {
    "cmpintqi",
    0,
    (insn_gen_fn) gen_cmpintqi,
    &operand_data[975],
    1,
    4,
    0,
    0
  },
  {
    "strlensi",
    0,
    (insn_gen_fn) gen_strlensi,
    &operand_data[1285],
    4,
    0,
    0,
    0
  },
  {
    "strlensi+1",
    0,
    0,
    &operand_data[1289],
    9,
    0,
    0,
    0
  },
  {
    "movsicc-1",
    0,
    0,
    &operand_data[1289],
    9,
    0,
    0,
    0
  },
  {
    "movsicc",
    0,
    (insn_gen_fn) gen_movsicc,
    &operand_data[1298],
    4,
    0,
    0,
    0
  },
  {
    "movhicc",
    0,
    (insn_gen_fn) gen_movhicc,
    &operand_data[1302],
    4,
    0,
    0,
    0
  },
  {
    "movsfcc",
    0,
    (insn_gen_fn) gen_movsfcc,
    &operand_data[1306],
    4,
    0,
    0,
    0
  },
  {
    "movdfcc",
    0,
    (insn_gen_fn) gen_movdfcc,
    &operand_data[1310],
    4,
    0,
    0,
    0
  },
  {
    "movxfcc",
    0,
    (insn_gen_fn) gen_movxfcc,
    &operand_data[1314],
    4,
    0,
    0,
    0
  },
  {
    "movtfcc",
    0,
    (insn_gen_fn) gen_movtfcc,
    &operand_data[1318],
    4,
    0,
    0,
    0
  },
  {
    "allocate_stack",
    0,
    (insn_gen_fn) gen_allocate_stack,
    &operand_data[1322],
    2,
    1,
    1,
    0
  },
  {
    "builtin_setjmp_receiver",
    0,
    (insn_gen_fn) gen_builtin_setjmp_receiver,
    &operand_data[552],
    1,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+1",
    0,
    0,
    &operand_data[1324],
    4,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+2",
    0,
    0,
    &operand_data[1328],
    3,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+3",
    0,
    0,
    &operand_data[1329],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+4",
    0,
    0,
    &operand_data[1130],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+5",
    0,
    0,
    &operand_data[1130],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+6",
    0,
    0,
    &operand_data[1331],
    4,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+7",
    0,
    0,
    &operand_data[1335],
    3,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+8",
    0,
    0,
    &operand_data[1338],
    3,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+9",
    0,
    0,
    &operand_data[1341],
    3,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+10",
    0,
    0,
    &operand_data[1344],
    3,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+11",
    0,
    0,
    &operand_data[1336],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+12",
    0,
    0,
    &operand_data[1342],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+13",
    0,
    0,
    &operand_data[1345],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+14",
    0,
    0,
    &operand_data[1347],
    3,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+15",
    0,
    0,
    &operand_data[1350],
    3,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+16",
    0,
    0,
    &operand_data[1353],
    3,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+17",
    0,
    0,
    &operand_data[1356],
    4,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+18",
    0,
    0,
    &operand_data[456],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+19",
    0,
    0,
    &operand_data[458],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+20",
    0,
    0,
    &operand_data[542],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+21",
    0,
    0,
    &operand_data[1227],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+22",
    0,
    0,
    &operand_data[1360],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+23",
    0,
    0,
    &operand_data[391],
    2,
    0,
    0,
    0
  },
  {
    "builtin_setjmp_receiver+24",
    0,
    0,
    &operand_data[1362],
    4,
    0,
    0,
    0
  },
  {
    "conditional_trap-24",
    0,
    0,
    &operand_data[1362],
    4,
    0,
    0,
    0
  },
  {
    "conditional_trap-23",
    0,
    0,
    &operand_data[1366],
    4,
    0,
    0,
    0
  },
  {
    "conditional_trap-22",
    0,
    0,
    &operand_data[1366],
    4,
    0,
    0,
    0
  },
  {
    "conditional_trap-21",
    0,
    0,
    &operand_data[967],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-20",
    0,
    0,
    &operand_data[1370],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-19",
    0,
    0,
    &operand_data[967],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-18",
    0,
    0,
    &operand_data[1371],
    2,
    0,
    0,
    0
  },
  {
    "conditional_trap-17",
    0,
    0,
    &operand_data[1227],
    2,
    0,
    0,
    0
  },
  {
    "conditional_trap-16",
    0,
    0,
    &operand_data[1337],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-15",
    0,
    0,
    &operand_data[1337],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-14",
    0,
    0,
    &operand_data[1337],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-13",
    0,
    0,
    &operand_data[1337],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-12",
    0,
    0,
    &operand_data[1337],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-11",
    0,
    0,
    &operand_data[1373],
    2,
    0,
    0,
    0
  },
  {
    "conditional_trap-10",
    0,
    0,
    &operand_data[1337],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-9",
    0,
    0,
    &operand_data[1337],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-8",
    0,
    0,
    &operand_data[1373],
    2,
    0,
    0,
    0
  },
  {
    "conditional_trap-7",
    0,
    0,
    &operand_data[1337],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-6",
    0,
    0,
    &operand_data[1375],
    2,
    0,
    0,
    0
  },
  {
    "conditional_trap-5",
    0,
    0,
    &operand_data[1377],
    2,
    0,
    0,
    0
  },
  {
    "conditional_trap-4",
    0,
    0,
    &operand_data[1379],
    2,
    0,
    0,
    0
  },
  {
    "conditional_trap-3",
    0,
    0,
    &operand_data[921],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-2",
    0,
    0,
    &operand_data[972],
    1,
    0,
    0,
    0
  },
  {
    "conditional_trap-1",
    0,
    0,
    &operand_data[1255],
    4,
    0,
    0,
    0
  },
  {
    "conditional_trap",
    0,
    (insn_gen_fn) gen_conditional_trap,
    &operand_data[769],
    2,
    1,
    0,
    0
  },
  {
    "movti",
    0,
    (insn_gen_fn) gen_movti,
    &operand_data[1381],
    2,
    0,
    0,
    0
  },
  {
    "movv4sf",
    0,
    (insn_gen_fn) gen_movv4sf,
    &operand_data[1383],
    2,
    0,
    0,
    0
  },
  {
    "movv4si",
    0,
    (insn_gen_fn) gen_movv4si,
    &operand_data[1385],
    2,
    0,
    0,
    0
  },
  {
    "movv2si",
    0,
    (insn_gen_fn) gen_movv2si,
    &operand_data[1387],
    2,
    0,
    0,
    0
  },
  {
    "movv4hi",
    0,
    (insn_gen_fn) gen_movv4hi,
    &operand_data[1389],
    2,
    0,
    0,
    0
  },
  {
    "movv8qi",
    0,
    (insn_gen_fn) gen_movv8qi,
    &operand_data[1391],
    2,
    0,
    0,
    0
  },
  {
    "movv8qi+1",
    0,
    0,
    &operand_data[1393],
    2,
    0,
    0,
    0
  },
  {
    "movv8qi+2",
    0,
    0,
    &operand_data[1395],
    2,
    0,
    0,
    0
  },
  {
    "movv8qi+3",
    0,
    0,
    &operand_data[1397],
    2,
    0,
    0,
    0
  },
  {
    "sfence-3",
    0,
    0,
    &operand_data[1399],
    2,
    0,
    0,
    0
  },
  {
    "sfence-2",
    0,
    0,
    &operand_data[1401],
    2,
    0,
    0,
    0
  },
  {
    "sfence-1",
    0,
    0,
    &operand_data[1403],
    2,
    0,
    0,
    0
  },
  {
    "sfence",
    0,
    (insn_gen_fn) gen_sfence,
    &operand_data[0],
    0,
    2,
    0,
    0
  },
};


const char *
get_insn_name (code)
     int code;
{
  return insn_data[code].name;
}
